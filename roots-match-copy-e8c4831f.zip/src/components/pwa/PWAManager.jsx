import { useEffect } from 'react';

export default function PWAManager() {
  useEffect(() => {
    // Handle app updates via service worker
    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.ready.then((registration) => {
        registration.addEventListener('updatefound', () => {
          const newWorker = registration.installing;
          newWorker.addEventListener('statechange', () => {
            if (newWorker.state === 'installed' && navigator.serviceWorker.controller) {
              // New content is available
              if (confirm('גרסה חדשה זמינה! האם לרענן את האפליקציה?')) {
                window.location.reload();
              }
            }
          });
        });
      });
    }

    // Add PWA-specific optimizations
    const addPWAStyles = () => {
      // Prevent zoom on input focus (iOS)
      const viewportMeta = document.querySelector('meta[name="viewport"]');
      if (!viewportMeta) {
        const meta = document.createElement('meta');
        meta.name = 'viewport';
        meta.content = 'width=device-width, initial-scale=1, maximum-scale=1, user-scalable=0';
        document.getElementsByTagName('head')[0].appendChild(meta);
      }
    };

    addPWAStyles();
  }, []);

  return null; // This component doesn't render anything
}