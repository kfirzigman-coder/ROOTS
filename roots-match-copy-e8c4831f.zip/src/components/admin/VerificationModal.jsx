import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';

export default function VerificationModal({ isOpen, onClose, request, user, onAction }) {
  if (!request && !user) return null;

  const displayUser = user || request?.user;
  const verificationPhoto = request?.photo_url;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="w-[95vw] max-w-md h-[90vh] p-0 flex flex-col" dir="rtl">
        <DialogHeader className="p-4 border-b flex-shrink-0">
          <DialogTitle className="text-lg">בדיקת בקשת אימות</DialogTitle>
          <DialogDescription className="text-sm">
            בדוק את התמונה שהועלתה ואשר או דחה את הבקשה.
          </DialogDescription>
        </DialogHeader>
        
        <ScrollArea className="flex-1 overflow-y-auto">
          <div className="p-4 space-y-4">
            <div className="bg-gray-50 rounded-lg p-3">
              <h3 className="font-semibold text-sm mb-2">פרטי המשתמש:</h3>
              <div className="space-y-1 text-sm">
                <p><strong>שם:</strong> {displayUser?.full_name || displayUser?.chosen_name}</p>
                <p><strong>אימייל:</strong> {displayUser?.email}</p>
              </div>
            </div>
            
            {verificationPhoto && (
              <div>
                <h3 className="font-semibold text-sm mb-2">תמונת אימות:</h3>
                <p className="text-xs text-gray-600 mb-3">
                  המשתמש התבקש להצטלם עם סימן 'וי' (✌️).
                </p>
                <div className="border rounded-lg overflow-hidden bg-gray-100">
                  <img 
                    src={verificationPhoto} 
                    alt="Verification" 
                    className="w-full h-auto object-contain max-h-96"
                  />
                </div>
              </div>
            )}
            
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
              <p className="text-xs text-yellow-800">
                <strong>בדוק:</strong> האם המשתמש מחזיק סימן וי ברור? האם הפנים תואמות לתמונות הפרופיל?
              </p>
            </div>
          </div>
        </ScrollArea>
        
        <DialogFooter className="p-4 border-t flex-shrink-0">
          <div className="flex flex-col space-y-3 w-full">
            {request && (
              <div className="flex gap-3 w-full">
                <Button 
                  variant="destructive" 
                  onClick={() => onAction(request, 'rejected')}
                  className="flex-1 text-sm py-3 font-medium"
                >
                  ❌ דחה בקשה
                </Button>
                <Button 
                  className="flex-1 bg-green-600 hover:bg-green-700 text-sm py-3 font-medium" 
                  onClick={() => onAction(request, 'approved')}
                >
                  ✅ אשר פרופיל
                </Button>
              </div>
            )}
            <Button 
              variant="outline" 
              onClick={onClose}
              className="w-full text-sm py-2"
            >
              ביטול
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}