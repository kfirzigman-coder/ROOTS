
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { X, MapPin, Heart, Star, CheckCircle, User, Calendar, Home, Camera } from 'lucide-react';

const ProfileDetailModal = ({ user, isOpen, onClose }) => {
  if (!user) return null;

  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <AnimatePresence mode="wait">
      {isOpen && (
        <motion.div
          key="profile-modal"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={handleBackdropClick}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ type: "spring", stiffness: 300, damping: 25 }}
            className="bg-gradient-to-br from-[#F7F4FB] to-[#ECE3F5] rounded-3xl shadow-2xl max-w-md w-full max-h-[85vh] border border-purple-100 overflow-hidden flex flex-col"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="relative bg-gradient-to-r from-[#7B3FA3] to-[#E7B6E1] p-6 text-white rounded-t-3xl flex-shrink-0">
              <button
                onClick={onClose}
                className="absolute top-4 right-4 w-8 h-8 bg-white/20 hover:bg-white/30 rounded-full flex items-center justify-center transition-all duration-200 backdrop-blur-sm"
              >
                <X className="w-5 h-5" />
              </button>
              
              <div className="text-center pt-4">
                <div className="flex items-center justify-center gap-3 mb-2">
                  <h2 className="text-2xl font-bold">
                    {user.chosen_name || user.full_name}
                  </h2>
                  {user.age && <span className="text-xl font-light">{user.age}</span>}
                  {user.verified && (
                    <CheckCircle className="w-5 h-5 text-blue-200 fill-current" />
                  )}
                </div>
                
                {user.location && (
                  <div className="flex items-center justify-center gap-1 text-white/90">
                    <MapPin className="w-4 h-4" />
                    <span className="text-sm">{user.location}</span>
                  </div>
                )}
              </div>
            </div>

            {/* Scrollable Content */}
            <div className="flex-1 overflow-y-auto overflow-x-hidden">
              <style jsx>{`
                .scrollable-content {
                  scrollbar-width: none;
                  -ms-overflow-style: none;
                }
                .scrollable-content::-webkit-scrollbar {
                  display: none;
                }
              `}</style>
              
              <div className="scrollable-content p-6 space-y-6">
                
                {/* Photo Gallery */}
                {user.photos && user.photos.length > 0 && (
                   <div>
                    <div className="flex items-center gap-2 mb-3">
                      <Camera className="w-5 h-5 text-[#7B3FA3]" />
                      <h3 className="font-bold text-[#3F2044] text-lg">גלריה</h3>
                    </div>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {user.photos.map((photo, index) => (
                        <motion.div 
                          key={index}
                          className="aspect-square w-full"
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.05 }}
                        >
                          <img src={photo} alt={`Photo ${index + 1}`} className="w-full h-full object-cover rounded-xl shadow-md border border-purple-100" />
                        </motion.div>
                      ))}
                    </div>
                  </div>
                )}

                {/* Bio Section */}
                {user.bio && (
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <Heart className="w-5 h-5 text-[#7B3FA3]" />
                      <h3 className="font-bold text-[#3F2044] text-lg">אודותיי</h3>
                    </div>
                    <p className="text-gray-700 leading-relaxed bg-white/70 backdrop-blur-sm p-4 rounded-xl border border-purple-100/50 shadow-sm">
                      {user.bio}
                    </p>
                  </div>
                )}

                {/* Interests */}
                {user.interests && user.interests.length > 0 && (
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <Star className="w-5 h-5 text-[#E7B6E1]" />
                      <h3 className="font-bold text-[#3F2044] text-lg">תחומי עניין</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {user.interests.map((interest, index) => (
                        <Badge
                          key={index}
                          className="bg-gradient-to-r from-[#7B3FA3]/10 to-[#E7B6E1]/10 text-[#7B3FA3] border border-[#7B3FA3]/20 px-3 py-2 text-sm font-medium rounded-full hover:from-[#7B3FA3]/20 hover:to-[#E7B6E1]/20 transition-all duration-200"
                        >
                          {interest}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Personal Details */}
                <div>
                  <div className="flex items-center gap-2 mb-3">
                    <User className="w-5 h-5 text-[#7B3FA3]" />
                    <h3 className="font-bold text-[#3F2044] text-lg">פרטים אישיים</h3>
                  </div>
                  
                  <div className="bg-white/70 backdrop-blur-sm rounded-xl p-4 space-y-3 border border-purple-100/50 shadow-sm">
                    {user.generation_in_israel && (
                      <div className="flex justify-between items-center py-2 border-b border-purple-100/50 last:border-b-0">
                        <span className="text-gray-600 font-medium">דור בארץ:</span>
                        <span className="font-semibold text-[#3F2044]">
                          {user.generation_in_israel === 'new_immigrant' ? 'עולה חדש/ה' :
                           user.generation_in_israel === 'first_gen' ? 'דור ראשון' :
                           user.generation_in_israel === 'second_gen' ? 'דור שני' :
                           user.generation_in_israel}
                        </span>
                      </div>
                    )}
                    
                    {user.religion && (
                      <div className="flex justify-between items-center py-2 border-b border-purple-100/50 last:border-b-0">
                        <span className="text-gray-600 font-medium">דת ואמונה:</span>
                        <span className="font-semibold text-[#3F2044]">
                          {user.religion === 'secular' ? 'חילוני' :
                           user.religion === 'traditional' ? 'מסורתי' :
                           user.religion === 'religious' ? 'דתי' :
                           user.religion === 'other' ? 'אחר' : user.religion}
                        </span>
                      </div>
                    )}

                    {user.shabbat_observance && (
                      <div className="flex justify-between items-center py-2 border-b border-purple-100/50 last:border-b-0">
                        <span className="text-gray-600 font-medium">שמירת שבת:</span>
                        <span className="font-semibold text-[#3F2044]">
                          {user.shabbat_observance === 'yes' ? 'כן' :
                           user.shabbat_observance === 'no' ? 'לא' :
                           user.shabbat_observance === 'partially' ? 'חלקית' :
                           user.shabbat_observance}
                        </span>
                      </div>
                    )}

                    {user.kashrut_observance && (
                      <div className="flex justify-between items-center py-2 border-b border-purple-100/50 last:border-b-0">
                        <span className="text-gray-600 font-medium">שמירת כשרות:</span>
                        <span className="font-semibold text-[#3F2044]">
                          {user.kashrut_observance === 'yes' ? 'כן' :
                           user.kashrut_observance === 'no' ? 'לא' :
                           user.kashrut_observance}
                        </span>
                      </div>
                    )}

                    {user.family_plans && (
                      <div className="flex justify-between items-center py-2">
                        <span className="text-gray-600 font-medium">תכנון משפחה:</span>
                        <span className="font-semibold text-[#3F2044]">
                          {user.family_plans === 'open_to_children' ? 'מעוניין/ת בילדים' :
                           user.family_plans === 'has_children_wants_more' ? 'יש ילדים ורוצה עוד' :
                           user.family_plans === 'has_children_no_more' ? 'יש ילדים ולא רוצה עוד' :
                           user.family_plans === 'no_children_no_plans' ? 'אין ילדים ולא מתכנן/ת' :
                           user.family_plans === 'not_relevant' ? 'לא רלוונטי' :
                           user.family_plans}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Relationship Intent */}
                {user.relationship_intent && (
                  <div>
                    <div className="flex items-center gap-2 mb-3">
                      <Heart className="w-5 h-5 text-[#E7B6E1]" />
                      <h3 className="font-bold text-[#3F2044] text-lg">מה מחפש/ת</h3>
                    </div>
                    <div className="bg-gradient-to-r from-[#E7B6E1]/20 to-[#7B3FA3]/10 border border-[#E7B6E1]/30 rounded-xl p-4 backdrop-blur-sm">
                      <span className="font-semibold text-[#7B3FA3] text-lg">
                        {user.relationship_intent}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default ProfileDetailModal;
