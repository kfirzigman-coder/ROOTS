import React, { useState, useRef } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { UploadCloud, Loader2 } from 'lucide-react';
import { UploadFile } from '@/api/integrations';
import { VerificationRequest } from '@/api/entities';
import { User } from '@/api/entities';

export default function VerificationModal({ isOpen, onClose, onVerificationRequested }) {
  const [file, setFile] = useState(null);
  const [preview, setPreview] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState(null);
  const fileInputRef = useRef(null);

  const handleFileChange = (e) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      setPreview(URL.createObjectURL(selectedFile));
      setError(null);
    }
  };

  const handleSubmit = async () => {
    if (!file) {
      setError('נא לבחור תמונה להעלאה.');
      return;
    }

    setIsUploading(true);
    setIsSubmitting(true);
    setError(null);

    try {
      const { file_url } = await UploadFile({ file });
      setIsUploading(false);

      const user = await User.me();
      await VerificationRequest.create({
        user_id: user.id,
        photo_url: file_url,
      });

      onVerificationRequested();
    } catch (err) {
      console.error('Verification submission failed:', err);
      setError('שליחת בקשת האימות נכשלה. נסה שוב.');
    } finally {
      setIsUploading(false);
      setIsSubmitting(false);
    }
  };

  const resetState = () => {
    setFile(null);
    setPreview(null);
    setError(null);
    setIsSubmitting(false);
    setIsUploading(false);
  };
  
  const handleClose = () => {
    if (isSubmitting) return;
    resetState();
    onClose();
  }

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent dir="rtl" className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>אימות פרופיל</DialogTitle>
          <DialogDescription>
            כדי לאמת את הפרופיל שלך, העלה תמונה ברורה שלך עושה את הסימן ✌️ עם היד.
          </DialogDescription>
        </DialogHeader>
        <div className="py-4 space-y-4">
          <div 
            className="w-full h-64 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center bg-gray-50 cursor-pointer"
            onClick={() => !isSubmitting && fileInputRef.current?.click()}
          >
            {preview ? (
              <img src={preview} alt="Verification preview" className="w-full h-full object-contain rounded-lg" />
            ) : (
              <div className="text-center text-gray-500">
                <UploadCloud className="mx-auto h-12 w-12" />
                <p className="mt-2">לחץ כאן כדי לבחור תמונה</p>
                <p className="text-xs">קבצי JPG, PNG, WEBP</p>
              </div>
            )}
          </div>
          <input
            type="file"
            ref={fileInputRef}
            className="hidden"
            accept="image/png, image/jpeg, image/webp"
            onChange={handleFileChange}
            disabled={isSubmitting}
          />
          {error && <p className="text-sm text-red-500 text-center">{error}</p>}
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={handleClose} disabled={isSubmitting}>ביטול</Button>
          <Button onClick={handleSubmit} disabled={!file || isSubmitting}>
            {isSubmitting && <Loader2 className="ml-2 h-4 w-4 animate-spin" />}
            {isSubmitting ? (isUploading ? 'מעלה תמונה...' : 'שולח בקשה...') : 'שלח בקשת אימות'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}