import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Camera, Image, AlertCircle, CheckCircle } from 'lucide-react';
import { useLanguage } from '../language/LanguageContext';

export default function PhotoPermission({ onPermissionGranted, onFileSelect }) {
  const [showPermissionDialog, setShowPermissionDialog] = useState(false);
  const [permissionStatus, setPermissionStatus] = useState('prompt'); // 'prompt', 'granted', 'denied'
  const { language } = useLanguage();

  const requestPhotoPermission = async () => {
    setShowPermissionDialog(true);
    
    try {
      // For camera access
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        stream.getTracks().forEach(track => track.stop()); // Stop the stream immediately
        setPermissionStatus('granted');
      }
      
      // Create file input for photo selection
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.multiple = true;
      
      input.onchange = (e) => {
        const files = Array.from(e.target.files);
        if (files.length > 0) {
          onFileSelect(files);
          setShowPermissionDialog(false);
          onPermissionGranted();
        }
      };
      
      input.click();
      
    } catch (error) {
      console.error('Photo permission error:', error);
      setPermissionStatus('denied');
      
      // Even if camera permission is denied, we can still allow file selection
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.multiple = true;
      
      input.onchange = (e) => {
        const files = Array.from(e.target.files);
        if (files.length > 0) {
          onFileSelect(files);
          setShowPermissionDialog(false);
          onPermissionGranted();
        }
      };
      
      input.click();
    }
  };

  const selectFromGallery = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.multiple = true;
    
    input.onchange = (e) => {
      const files = Array.from(e.target.files);
      if (files.length > 0) {
        onFileSelect(files);
        onPermissionGranted();
      }
    };
    
    input.click();
  };

  return (
    <>
      {/* Photo Selection Buttons */}
      <div className="space-y-3">
        <Button
          onClick={requestPhotoPermission}
          className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white py-3 rounded-xl shadow-lg"
        >
          <Camera className="w-5 h-5 mr-2" />
          {language === 'he' ? 'צלם תמונה חדשה' : 'Take New Photo'}
        </Button>
        
        <Button
          onClick={selectFromGallery}
          variant="outline"
          className="w-full border-purple-300 text-purple-600 hover:bg-purple-50 py-3 rounded-xl"
        >
          <Image className="w-5 h-5 mr-2" />
          {language === 'he' ? 'בחר מהגלריה' : 'Choose from Gallery'}
        </Button>
      </div>

      {/* Permission Dialog */}
      <AnimatePresence>
        {showPermissionDialog && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center z-50 p-4"
            onClick={() => setShowPermissionDialog(false)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="bg-white rounded-2xl p-6 max-w-sm w-full shadow-2xl"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="text-center">
                {permissionStatus === 'granted' && (
                  <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle className="w-8 h-8 text-green-600" />
                  </div>
                )}
                
                {permissionStatus === 'denied' && (
                  <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <AlertCircle className="w-8 h-8 text-red-600" />
                  </div>
                )}
                
                {permissionStatus === 'prompt' && (
                  <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Camera className="w-8 h-8 text-purple-600" />
                  </div>
                )}

                <h3 className="text-lg font-bold text-gray-900 mb-2">
                  {permissionStatus === 'granted' && (language === 'he' ? 'הרשאה ניתנה!' : 'Permission Granted!')}
                  {permissionStatus === 'denied' && (language === 'he' ? 'הרשאה נדחתה' : 'Permission Denied')}
                  {permissionStatus === 'prompt' && (language === 'he' ? 'בקשת הרשאה' : 'Permission Request')}
                </h3>

                <p className="text-gray-600 mb-6 text-sm">
                  {permissionStatus === 'granted' && (language === 'he' 
                    ? 'עכשיו תוכל לצלם תמונות או לבחור מהגלריה.'
                    : 'You can now take photos or choose from gallery.'
                  )}
                  {permissionStatus === 'denied' && (language === 'he' 
                    ? 'אין אפשרות לגשת למצלמה. תוכל עדיין לבחור תמונות מהגלריה.'
                    : 'Cannot access camera. You can still choose photos from gallery.'
                  )}
                  {permissionStatus === 'prompt' && (language === 'he' 
                    ? 'RootsMatch מבקש גישה למצלמה כדי לאפשר לך לצלם תמונות פרופיל.'
                    : 'RootsMatch requests camera access to let you take profile photos.'
                  )}
                </p>

                <Button
                  onClick={() => setShowPermissionDialog(false)}
                  className="w-full bg-purple-600 hover:bg-purple-700 text-white py-2 rounded-xl"
                >
                  {language === 'he' ? 'הבנתי' : 'Got it'}
                </Button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}