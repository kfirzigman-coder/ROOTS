import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { MapPin, Navigation, Users, Heart } from 'lucide-react';
import { useLanguage } from '../language/LanguageContext';
import { t } from '../language/translations';
import { User } from '@/api/entities';

export default function LocationPermission({ onPermissionGranted, onSkip }) {
  const [isRequesting, setIsRequesting] = useState(false);
  const [error, setError] = useState(null);
  const { language } = useLanguage();

  const requestLocationPermission = async () => {
    setIsRequesting(true);
    setError(null);

    try {
      if (!navigator.geolocation) {
        throw new Error(language === 'he' ? 'הדפדפן לא תומך בשירותי מיקום' : 'Browser does not support geolocation');
      }

      const position = await new Promise((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(
          resolve,
          reject,
          {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 300000 // 5 minutes
          }
        );
      });

      const { latitude, longitude } = position.coords;
      
      // Update user location in database
      await User.updateMyUserData({
        latitude,
        longitude,
        location: language === 'he' ? 'ישראל' : 'Israel' // Default location name
      });

      onPermissionGranted({ latitude, longitude });

    } catch (error) {
      console.error('Location permission error:', error);
      
      let errorMessage;
      if (error.code === 1) {
        errorMessage = language === 'he' 
          ? 'אישור המיקום נדחה. תוכל לאפשר מיקום מההגדרות של הדפדפן.'
          : 'Location permission denied. You can enable location from browser settings.';
      } else if (error.code === 2) {
        errorMessage = language === 'he' 
          ? 'לא ניתן לקבוע את המיקום. אנא ודא שהמיקום מופעל במכשיר.'
          : 'Location unavailable. Please ensure location is enabled on your device.';
      } else if (error.code === 3) {
        errorMessage = language === 'he' 
          ? 'זמן הקשר לקביעת המיקום פג. אנא נסה שוב.'
          : 'Location request timeout. Please try again.';
      } else {
        errorMessage = language === 'he' 
          ? 'שגיאה בקביעת המיקום. אנא נסה שוב.'
          : 'Error determining location. Please try again.';
      }
      
      setError(errorMessage);
    } finally {
      setIsRequesting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 flex flex-col items-center justify-center p-6" dir={language === 'he' ? 'rtl' : 'ltr'}>
      <motion.div
        initial={{ opacity: 0, y: 50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center max-w-md"
      >
        {/* Location Icon Animation */}
        <motion.div
          className="w-24 h-24 mx-auto mb-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center shadow-2xl"
          animate={{ 
            scale: [1, 1.1, 1],
            rotate: [0, 5, -5, 0]
          }}
          transition={{ 
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        >
          <MapPin className="w-12 h-12 text-white" />
        </motion.div>

        <motion.h1
          className="text-3xl font-bold text-gray-900 mb-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          {language === 'he' ? 'נתחיל למצוא אנשים בקרבתך' : 'Let\'s find people near you'}
        </motion.h1>

        <motion.p
          className="text-gray-600 mb-8 leading-relaxed"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          {language === 'he' 
            ? 'RootsMatch משתמש במיקום שלך כדי להציג לך אנשים מתאימים בסביבה. המיקום שלך לא יוצג בפרופיל.'
            : 'RootsMatch uses your location to show you compatible people nearby. Your exact location is never shown in your profile.'
          }
        </motion.p>

        {/* Benefits List */}
        <motion.div
          className="space-y-4 mb-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          {[
            {
              icon: <Users className="w-5 h-5" />,
              text: language === 'he' ? 'מצא אנשים בקרבתך' : 'Find people nearby'
            },
            {
              icon: <Heart className="w-5 h-5" />,
              text: language === 'he' ? 'התאמות מדויקות יותר' : 'More accurate matches'
            },
            {
              icon: <Navigation className="w-5 h-5" />,
              text: language === 'he' ? 'פגישות קלות יותר' : 'Easier to meet up'
            }
          ].map((benefit, index) => (
            <motion.div
              key={index}
              className="flex items-center gap-3 text-gray-700 bg-white/70 backdrop-blur-sm rounded-xl p-3 shadow-sm"
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.5 + index * 0.1 }}
            >
              <div className="text-purple-600">{benefit.icon}</div>
              <span className="font-medium">{benefit.text}</span>
            </motion.div>
          ))}
        </motion.div>

        {error && (
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-red-50 border border-red-200 text-red-700 p-4 rounded-xl mb-6"
          >
            <p className="text-sm">{error}</p>
          </motion.div>
        )}

        {/* Action Buttons */}
        <motion.div
          className="space-y-4"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
        >
          <Button
            onClick={requestLocationPermission}
            disabled={isRequesting}
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white py-4 text-lg font-semibold rounded-full shadow-xl disabled:opacity-50"
          >
            {isRequesting ? (
              <div className="flex items-center gap-2">
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                {language === 'he' ? 'מאתר מיקום...' : 'Locating...'}
              </div>
            ) : (
              <>
                <MapPin className="w-5 h-5 mr-2" />
                {language === 'he' ? 'אפשר גישה למיקום' : 'Enable Location Access'}
              </>
            )}
          </Button>

          <Button
            variant="outline"
            onClick={onSkip}
            className="w-full border-gray-300 text-gray-600 hover:bg-gray-50 py-3 rounded-full"
          >
            {language === 'he' ? 'דלג לעכשיו' : 'Skip for now'}
          </Button>
        </motion.div>

        <motion.p
          className="text-xs text-gray-500 mt-6 leading-relaxed"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.8 }}
        >
          {language === 'he' 
            ? 'תוכל לשנות הרשאות מיקום בכל עת דרך הגדרות הדפדפן או האפליקציה.'
            : 'You can change location permissions anytime through browser or app settings.'
          }
        </motion.p>
      </motion.div>
    </div>
  );
}