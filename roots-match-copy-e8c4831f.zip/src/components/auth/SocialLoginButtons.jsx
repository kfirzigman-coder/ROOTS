import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { User } from '@/api/entities';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useLanguage } from '../language/LanguageContext';

export default function SocialLoginButtons() {
  const [loading, setLoading] = useState(null);
  const navigate = useNavigate();
  const { language } = useLanguage();

  const handleSocialLogin = async (provider) => {
    setLoading(provider);
    try {
      // For now, all social logins redirect to welcome
      // In real implementation, this would handle actual OAuth
      await new Promise(resolve => setTimeout(resolve, 1500)); // Simulate loading
      navigate(createPageUrl('WelcomeIntro'));
    } catch (error) {
      console.error(`${provider} login error:`, error);
    }
    setLoading(null);
  };

  const socialButtons = [
    {
      provider: 'google',
      text: language === 'he' ? 'המשך עם Google' : 'Continue with Google',
      icon: '🌐',
      bgColor: 'bg-white text-gray-900 hover:bg-gray-50',
      borderColor: 'border-white/20'
    },
    {
      provider: 'apple',
      text: language === 'he' ? 'המשך עם Apple' : 'Continue with Apple',
      icon: '🍎',
      bgColor: 'bg-black text-white hover:bg-gray-900',
      borderColor: 'border-gray-700'
    },
    {
      provider: 'facebook',
      text: language === 'he' ? 'המשך עם Facebook' : 'Continue with Facebook',
      icon: '📘',
      bgColor: 'bg-blue-600 text-white hover:bg-blue-700',
      borderColor: 'border-blue-500'
    }
  ];

  return (
    <div className="space-y-3">
      {socialButtons.map((social) => (
        <Button
          key={social.provider}
          onClick={() => handleSocialLogin(social.provider)}
          disabled={loading === social.provider}
          className={`w-full py-4 text-lg font-semibold rounded-full shadow-lg transition-all duration-300 border ${social.bgColor} ${social.borderColor}`}
        >
          {loading === social.provider ? (
            <div className="w-6 h-6 border-2 border-current border-t-transparent rounded-full animate-spin"></div>
          ) : (
            <>
              <span className="text-2xl mr-3">{social.icon}</span>
              {social.text}
            </>
          )}
        </Button>
      ))}
    </div>
  );
}