import React from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Globe } from 'lucide-react';
import { useLanguage } from './LanguageContext';
import { t } from './translations';

export default function LanguageSelector({ showLabel = true }) {
  const { language, changeLanguage } = useLanguage();

  return (
    <div className="flex items-center gap-2">
      {showLabel && <Globe className="w-4 h-4 text-gray-600" />}
      <Select value={language} onValueChange={changeLanguage}>
        <SelectTrigger className="w-[120px]">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="he">
            <div className="flex items-center gap-2">
              <span className="text-lg">🇮🇱</span>
              <span>{t('hebrew', language)}</span>
            </div>
          </SelectItem>
          <SelectItem value="am">
            <div className="flex items-center gap-2">
              <span className="text-lg">🇪🇹</span>
              <span>{t('amharic', language)}</span>
            </div>
          </SelectItem>
        </SelectContent>
      </Select>
    </div>
  );
}