
import React, { useState, useCallback, useMemo, useRef } from 'react';
import { motion, useMotionValue, useTransform } from 'framer-motion';
import { MapPin, CheckCircle, Info, ArrowUp, Heart, X } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

const ProfileCard = ({ user, onSwipe, isTopCard, onOpenDetails }) => {
  const [currentPhotoIndex, setCurrentPhotoIndex] = useState(0);

  // FIX: Moved all hooks to the top level of the component, before any early returns.
  const x = useMotionValue(0);
  const rotate = useTransform(x, [-300, 300], [-20, 20]);
  const likeOpacity = useTransform(x, [30, 100], [0, 1]);
  const passOpacity = useTransform(x, [-100, -30], [1, 0]);
  const likeScale = useTransform(likeOpacity, [0, 1], [0.5, 1.2]);
  const passScale = useTransform(passOpacity, [0, 1], [0.5, 1.2]);

  // FIX: Add a ref to get a stable reference to the DOM element.
  const cardRef = useRef(null);

  const handleTap = useCallback((e) => {
    // FIX: Guard against null user or ref, and use the ref instead of event target.
    if (!isTopCard || !user || !cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const tapX = e.clientX - rect.left;
    const third = rect.width / 3;

    if (tapX < third) { // Left third
      setCurrentPhotoIndex(prev => Math.max(0, prev - 1));
    } else if (tapX > third * 2) { // Right third
      setCurrentPhotoIndex(prev => Math.min((user.photos?.length || 1) - 1, prev + 1));
    }
    // The middle third now does nothing, so the modal only opens from the dedicated Info button.
  }, [isTopCard, user]); // Removed onOpenDetails from dependencies as it's no longer called here.

  const handleDragEnd = useCallback(async (event, info) => {
    if (!isTopCard) return;
    const { offset, velocity } = info;
    const swipeThreshold = 100;

    let swipeDirection = null;
    if (offset.x > swipeThreshold || velocity.x > 300) {
      swipeDirection = 'like';
    } else if (offset.x < -swipeThreshold || velocity.x < -300) {
      swipeDirection = 'pass';
    }
    
    if (swipeDirection) {
      onSwipe(swipeDirection);
    } else {
      x.set(0);
    }
  }, [isTopCard, onSwipe, x]);

  const photoIndicators = useMemo(() => {
    if (!user?.photos || user.photos.length <= 1) return null;
    return (
      <div className="absolute top-2 left-2 right-2 z-10 flex gap-1 p-1">
        {user.photos.map((_, index) => (
          <div
            key={index}
            className="h-1 flex-1 rounded-full bg-white/50 backdrop-blur-sm"
          >
            <motion.div 
              className="h-full rounded-full bg-white"
              initial={{width: "0%"}}
              animate={{width: index === currentPhotoIndex ? "100%" : "0%"}}
              transition={{duration: 0.3, ease: "easeInOut"}}
            />
          </div>
        ))}
      </div>
    );
  }, [user?.photos, currentPhotoIndex]);

  // FIX: Moved the early return to after all hooks have been called.
  if (!user) return null;

  const displayPhoto = user.photos?.[currentPhotoIndex] || 'https://via.placeholder.com/400';

  return (
    <motion.div
      // FIX: Attach the ref to the motion component.
      ref={cardRef}
      className="w-full h-full bg-gray-200 rounded-3xl shadow-2xl overflow-hidden relative cursor-pointer"
      style={{ x, rotate }}
      drag={isTopCard ? "x" : false}
      dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
      dragElastic={0.6}
      onDragEnd={handleDragEnd}
      onTap={handleTap} // Changed from onClick to onTap for better compatibility with framer-motion drag
    >
      <div className="w-full h-full relative">
        <motion.div
          key={displayPhoto}
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${displayPhoto})` }}
          initial={{ opacity: 0.8 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.3 }}
        />
        {photoIndicators}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/30 to-transparent" />
        
        {/* Swipe Icons */}
        <motion.div
          className="absolute top-1/3 left-8 text-green-400"
          style={{ opacity: likeOpacity, scale: likeScale }}
        >
            <Heart className="w-24 h-24 stroke-[3]" />
        </motion.div>
        <motion.div
          className="absolute top-1/3 right-8 text-rose-500"
          style={{ opacity: passOpacity, scale: passScale }}
        >
            <X className="w-24 h-24 stroke-[3]" />
        </motion.div>

        {/* User Info */}
        <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-5 text-white">
           <div className="flex items-end justify-between gap-2 sm:gap-4">
              <div className="flex-1 min-w-0">
                <div className="flex items-baseline gap-2 mb-1">
                  <h2 className="text-2xl sm:text-3xl font-bold [text-shadow:_0_2px_8px_rgba(0,0,0,0.8)] truncate">
                    {user.chosen_name || user.full_name},
                  </h2>
                  <span className="text-xl sm:text-2xl font-light">{user.age}</span>
                </div>

                {user.location && (
                  <div className="flex items-center gap-1.5 text-white/80 mb-2">
                    <MapPin className="w-4 h-4" />
                    <span className="text-sm sm:text-base">{user.location}</span>
                  </div>
                )}
              </div>
              <div
                className="w-10 h-10 sm:w-12 sm:h-12 bg-white/20 hover:bg-white/30 rounded-full backdrop-blur-sm flex items-center justify-center transition-all duration-200 cursor-pointer active:scale-90 flex-shrink-0"
                onClick={(e) => {
                  e.stopPropagation(); // מונע מהלחיצה על הכרטיס להתבצע
                  if (onOpenDetails) onOpenDetails();
                }}
              >
                <Info className="w-5 h-5 sm:w-6 sm:h-6 text-white"/>
              </div>
           </div>
          
           {user.bio && <p className="text-white/95 text-sm sm:text-base line-clamp-2 my-2 sm:my-3 pt-2 sm:pt-3 border-t border-white/20">{user.bio}</p>}

          <div className="flex flex-wrap gap-2">
            {user.interests?.slice(0, 3).map((interest) => (
              <Badge key={interest} variant="secondary" className="bg-white/20 text-white border-none backdrop-blur-sm px-2.5 py-1 text-xs sm:text-sm">
                {interest}
              </Badge>
            ))}
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default ProfileCard;
