import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Crown, Gem } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function AdCard({ onSwipe, isTopCard }) {
  const navigate = useNavigate();

  return (
    <motion.div
      className="w-full h-full bg-gradient-to-br from-purple-600 to-pink-500 rounded-3xl shadow-2xl overflow-hidden relative flex flex-col items-center justify-center text-white p-8"
      drag={isTopCard ? "x" : false}
      dragConstraints={{ left: 0, right: 0, top: 0, bottom: 0 }}
      dragElastic={0.6}
      onDragEnd={(e, { offset }) => {
        if (Math.abs(offset.x) > 100) {
          onSwipe('dismiss');
        }
      }}
    >
      <div className="absolute -top-16 -right-16 w-48 h-48 bg-white/10 rounded-full" />
      <div className="absolute -bottom-20 -left-12 w-56 h-56 bg-white/10 rounded-full" />
      
      <div className="relative z-10 text-center">
        <Gem className="w-16 h-16 mx-auto mb-4 text-yellow-300" />
        <h2 className="text-3xl font-bold text-center mb-3">
          שדרג ל-RootsMatch+
        </h2>
        <p className="text-center text-lg opacity-90 mb-8 max-w-xs">
          קבל לייקים ללא הגבלה, חזרות לאחור, וראה מי כבר אוהב אותך!
        </p>
        <Button 
          onClick={() => navigate(createPageUrl('Premium'))}
          className="bg-white text-purple-600 hover:bg-gray-100 font-bold py-3 px-8 rounded-full text-lg shadow-lg transform hover:scale-105 transition-transform"
        >
          שדרג עכשיו
        </Button>
      </div>
    </motion.div>
  );
}