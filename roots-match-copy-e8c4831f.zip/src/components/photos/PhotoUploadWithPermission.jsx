import React, { useState } from 'react';
import PhotoPermission from '../permissions/PhotoPermission';
import { UploadFile } from '@/api/integrations';
import { Loader2 } from 'lucide-react';
import { useLanguage } from '../language/LanguageContext';

export default function PhotoUploadWithPermission({ onPhotosUploaded, maxPhotos = 6 }) {
  const [isUploading, setIsUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const { language } = useLanguage();

  const handleFileSelect = async (files) => {
    setIsUploading(true);
    setUploadProgress(0);
    
    try {
      const filesToUpload = files.slice(0, maxPhotos);
      const uploadPromises = filesToUpload.map(async (file, index) => {
        const result = await UploadFile({ file });
        setUploadProgress(((index + 1) / filesToUpload.length) * 100);
        return result.file_url;
      });
      
      const uploadedUrls = await Promise.all(uploadPromises);
      onPhotosUploaded(uploadedUrls);
      
    } catch (error) {
      console.error('Error uploading photos:', error);
      alert(language === 'he' ? 'שגיאה בהעלאת התמונות' : 'Error uploading photos');
    } finally {
      setIsUploading(false);
      setUploadProgress(0);
    }
  };

  const handlePermissionGranted = () => {
    console.log('Photo permission granted');
  };

  if (isUploading) {
    return (
      <div className="flex flex-col items-center justify-center p-8 bg-purple-50 rounded-2xl border-2 border-purple-200">
        <Loader2 className="w-8 h-8 text-purple-600 animate-spin mb-4" />
        <p className="text-purple-700 font-medium mb-2">
          {language === 'he' ? 'מעלה תמונות...' : 'Uploading photos...'}
        </p>
        <div className="w-full bg-purple-200 rounded-full h-2 mb-2">
          <div 
            className="bg-purple-600 h-2 rounded-full transition-all duration-300"
            style={{ width: `${uploadProgress}%` }}
          ></div>
        </div>
        <p className="text-sm text-purple-600">{Math.round(uploadProgress)}%</p>
      </div>
    );
  }

  return (
    <PhotoPermission
      onPermissionGranted={handlePermissionGranted}
      onFileSelect={handleFileSelect}
    />
  );
}