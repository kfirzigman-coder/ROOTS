import React, { useEffect } from 'react';
import { Card } from '@/components/ui/card';

export default function AdBanner() {
  useEffect(() => {
    try {
      (window.adsbygoogle = window.adsbygoogle || []).push({});
    } catch (e) {
      console.error("AdSense error: ", e);
    }
  }, []);

  return (
    <div className="p-2 mb-4">
      <Card className="bg-gray-100 border-gray-200 shadow-sm flex items-center justify-center min-h-[100px]">
        <ins className="adsbygoogle"
             style={{ display: 'block', width: '100%', height: '100px' }}
             data-ad-client="ca-pub-8053131093193899"
             // TODO: החלף את המזהה הבא במזהה יחידת המודעות שלך מחשבון AdSense
             data-ad-slot="YOUR_AD_SLOT_ID_HERE"
             data-ad-format="auto"
             data-full-width-responsive="true"></ins>
      </Card>
    </div>
  );
}