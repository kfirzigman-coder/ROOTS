import React from 'react';
import { motion } from 'framer-motion';
import { Heart, X, Star } from 'lucide-react';

export default function SwipeIndicator({ type, visible }) {
  const config = {
    like: {
      icon: Heart,
      text: 'LIKE',
      color: 'text-green-500',
      bg: 'bg-green-500/20',
      border: 'border-green-500'
    },
    pass: {
      icon: X,
      text: 'PASS',
      color: 'text-red-500',
      bg: 'bg-red-500/20',
      border: 'border-red-500'
    },
    superlike: {
      icon: Star,
      text: 'SUPER LIKE',
      color: 'text-blue-500',
      bg: 'bg-blue-500/20',
      border: 'border-blue-500'
    }
  };

  const { icon: Icon, text, color, bg, border } = config[type] || config.like;

  return (
    <motion.div
      initial={{ scale: 0, opacity: 0 }}
      animate={{ 
        scale: visible ? 1 : 0, 
        opacity: visible ? 1 : 0 
      }}
      transition={{ 
        type: "spring", 
        stiffness: 500, 
        damping: 30 
      }}
      className={`
        absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2
        ${bg} ${border} border-4 rounded-2xl px-8 py-4
        flex items-center gap-3 shadow-2xl z-10
      `}
    >
      <Icon className={`w-8 h-8 ${color} ${type === 'superlike' ? 'fill-current' : ''}`} />
      <span className={`text-2xl font-bold ${color}`}>{text}</span>
    </motion.div>
  );
}