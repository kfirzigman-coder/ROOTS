import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { CheckCircle, Gift } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function PaymentConfirmation({ planName, price, period, onDone }) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5, type: 'spring' }}
      className="text-center p-8 bg-white rounded-2xl shadow-2xl max-w-md mx-auto"
    >
      <div className="w-20 h-20 bg-gradient-to-r from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
        <CheckCircle className="w-10 h-10 text-white" />
      </div>

      <h2 className="text-2xl font-bold text-gray-900 mb-3">התשלום הושלם בהצלחה!</h2>
      <p className="text-gray-600 mb-6">
        {`ברוך הבא ל-RootsMatch פרימיום! תוכנית ${planName} שלך פעילה כעת.`}
      </p>

      <div className="p-6 bg-purple-50 rounded-xl border border-purple-200 mb-8">
        <div className="flex items-center justify-center gap-3">
          <Gift className="w-6 h-6 text-purple-600" />
          <p className="font-semibold text-purple-800">כל תכונות הפרימיום זמינות לך!</p>
        </div>
      </div>
      
      <Button 
        onClick={onDone}
        size="lg" 
        className="w-full bg-gradient-to-r from-purple-500 to-pink-500 text-white font-semibold"
      >
        חזור לגילויים
      </Button>
    </motion.div>
  );
}