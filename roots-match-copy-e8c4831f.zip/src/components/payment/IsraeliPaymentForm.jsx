
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { CreditCard, Lock, Shield, AlertCircle } from 'lucide-react';
import { processIsraeliPayment } from '@/api/functions';

// Luhn Algorithm for credit card validation
const isValidCreditCard = (cardNumber) => {
  const sanitized = cardNumber.replace(/\D/g, '');
  if (!/^\d+$/.test(sanitized)) return false;

  let sum = 0;
  let shouldDouble = false;
  for (let i = sanitized.length - 1; i >= 0; i--) {
    let digit = parseInt(sanitized.charAt(i));
    if (shouldDouble) {
      if ((digit *= 2) > 9) digit -= 9;
    }
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  return (sum % 10) === 0 && sanitized.length >= 13 && sanitized.length <= 19;
};

export default function IsraeliPaymentForm({ planId, planName, amount, onSuccess, onError }) {
  const [formData, setFormData] = useState({
    customerName: '',
    customerEmail: '',
    citizenId: '',
    creditCard: '',
    expiryMonth: '',
    expiryYear: '',
    cvv: ''
  });
  const [processing, setProcessing] = useState(false);
  const [cardError, setCardError] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    
    // Format credit card number (add spaces every 4 digits)
    if (name === 'creditCard') {
      const sanitized = value.replace(/\s/g, '');
      const formatted = sanitized.replace(/(\d{4})/g, '$1 ').trim();
      setFormData(prev => ({ ...prev, [name]: formatted }));
      
      // Validate on the fly once length is sufficient
      if (sanitized.length >= 13) {
        if (isValidCreditCard(sanitized)) {
          setCardError(null);
        } else {
          setCardError('מספר כרטיס האשראי אינו תקין');
        }
      } else {
        setCardError(null);
      }
      return;
    }
    
    // Format citizen ID (limit to 9 digits)
    if (name === 'citizenId') {
      const digits = value.replace(/\D/g, '').slice(0, 9);
      setFormData(prev => ({ ...prev, [name]: digits }));
      return;
    }
    
    // Format CVV (limit to 3-4 digits)
    if (name === 'cvv') {
      const digits = value.replace(/\D/g, '').slice(0, 4);
      setFormData(prev => ({ ...prev, [name]: digits }));
      return;
    }
    
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setProcessing(true);

    try {
      const response = await processIsraeliPayment({
        ...formData,
        planId, // Add planId here
        planName,
        amount,
        creditCard: formData.creditCard.replace(/\s/g, '') // Remove spaces
      });

      if (response.data?.success) {
        onSuccess(response.data);
      } else {
        onError(response.data?.error || 'שגיאה בעיבוד התשלום');
      }
    } catch (error) {
      console.error('Payment error:', error);
      onError('שגיאה בעיבוד התשלום: ' + error.message);
    } finally {
      setProcessing(false);
    }
  };

  const isFormValid = () => {
    return formData.customerName.trim() && 
           formData.customerEmail.trim() && 
           formData.citizenId.length === 9 && 
           formData.creditCard.replace(/\s/g, '').length >= 13 &&
           !cardError && // Check for validation error
           formData.expiryMonth && 
           formData.expiryYear && 
           formData.cvv.length >= 3;
  };

  return (
    <Card className="w-full max-w-md mx-auto" dir="rtl">
      <CardHeader className="text-center">
        <CardTitle className="flex items-center justify-center gap-2">
          <CreditCard className="w-6 h-6" />
          פרטי תשלום
        </CardTitle>
        <div className="flex items-center justify-center gap-2 text-sm text-gray-600">
          <Lock className="w-4 h-4" />
          <span>תשלום מאובטח ומוצפן</span>
        </div>
      </CardHeader>
      
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Customer Details */}
          <div className="space-y-4">
            <div>
              <Label htmlFor="customerName">שם מלא *</Label>
              <Input
                id="customerName"
                name="customerName"
                value={formData.customerName}
                onChange={handleInputChange}
                placeholder="הכנס שם מלא"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="customerEmail">כתובת אימייל *</Label>
              <Input
                id="customerEmail"
                name="customerEmail"
                type="email"
                value={formData.customerEmail}
                onChange={handleInputChange}
                placeholder="example@email.com"
                required
              />
            </div>
            
            <div>
              <Label htmlFor="citizenId">תעודת זהות *</Label>
              <Input
                id="citizenId"
                name="citizenId"
                value={formData.citizenId}
                onChange={handleInputChange}
                placeholder="123456789"
                maxLength="9"
                required
                // Add numeric input mode
                type="tel"
                inputMode="numeric"
              />
            </div>
          </div>

          <div className="border-t pt-4">
            <h3 className="font-semibold mb-4 flex items-center gap-2">
              <Shield className="w-4 h-4" />
              פרטי כרטיס אשראי
            </h3>
            
            <div className="space-y-4">
              <div>
                <Label htmlFor="creditCard">מספר כרטיס אשראי *</Label>
                <Input
                  id="creditCard"
                  name="creditCard"
                  value={formData.creditCard}
                  onChange={handleInputChange}
                  placeholder="1234 5678 9012 3456"
                  maxLength="19"
                  className={cardError ? 'border-red-500' : ''}
                  required
                  // Add numeric input mode
                  type="tel"
                  inputMode="numeric"
                />
                {cardError && (
                    <div className="flex items-center text-red-600 text-sm mt-2">
                        <AlertCircle className="w-4 h-4 ml-1" />
                        {cardError}
                    </div>
                )}
              </div>
              
              <div className="flex gap-2">
                <div className="flex-1">
                  <Label htmlFor="expiryMonth">חודש תוקף *</Label>
                  <Select value={formData.expiryMonth} onValueChange={(value) => setFormData(prev => ({...prev, expiryMonth: value}))}>
                    <SelectTrigger>
                      <SelectValue placeholder="חודש" />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({length: 12}, (_, i) => (
                        <SelectItem key={i+1} value={String(i+1).padStart(2, '0')}>
                          {String(i+1).padStart(2, '0')}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="flex-1">
                  <Label htmlFor="expiryYear">שנת תוקף *</Label>
                  <Select value={formData.expiryYear} onValueChange={(value) => setFormData(prev => ({...prev, expiryYear: value}))}>
                    <SelectTrigger>
                      <SelectValue placeholder="שנה" />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({length: 10}, (_, i) => {
                        const year = new Date().getFullYear() + i;
                        return (
                          <SelectItem key={year} value={String(year)}>
                            {year}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="w-20">
                  <Label htmlFor="cvv">CVV *</Label>
                  <Input
                    id="cvv"
                    name="cvv"
                    value={formData.cvv}
                    onChange={handleInputChange}
                    placeholder="123"
                    maxLength="4"
                    required
                    // Add numeric input mode
                    type="tel"
                    inputMode="numeric"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="pt-4">
            <div className="bg-purple-50 p-4 rounded-lg mb-4">
              <div className="flex justify-between items-center">
                <span className="font-semibold">סכום לתשלום:</span>
                <span className="text-2xl font-bold text-purple-600">₪{amount}</span>
              </div>
              <div className="text-sm text-gray-600 mt-1">
                {planName}
              </div>
            </div>
            
            <Button 
              type="submit" 
              className="w-full bg-green-600 hover:bg-green-700 text-white font-bold py-3"
              disabled={!isFormValid() || processing}
            >
              {processing ? 'מעבד תשלום...' : `שלם ₪${amount}`}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
