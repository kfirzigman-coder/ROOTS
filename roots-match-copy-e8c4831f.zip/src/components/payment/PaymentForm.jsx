import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { CreditCard, Lock, Calendar, User } from 'lucide-react';

export default function PaymentForm({ onSubmit, price, processing }) {
  const [cardDetails, setCardDetails] = useState({
    number: '',
    name: '',
    expiry: '',
    cvc: ''
  });
  const [paymentMethod, setPaymentMethod] = useState('card');

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    let formattedValue = value;

    if (name === 'number') {
      formattedValue = value.replace(/\D/g, '').replace(/(\d{4})/g, '$1 ').trim();
    } else if (name === 'expiry') {
      formattedValue = value.replace(/\D/g, '').replace(/(\d{2})(\d)/, '$1 / $2').slice(0, 7);
    }
    
    setCardDetails(prev => ({...prev, [name]: formattedValue }));
  };
  
  const handleSubmit = (e) => {
    e.preventDefault();
    onSubmit(cardDetails);
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Payment method selection */}
      <div>
        <Label className="mb-2 block">אמצעי תשלום</Label>
        <div className="grid grid-cols-3 gap-2">
          <Button type="button" onClick={() => setPaymentMethod('card')} variant={paymentMethod === 'card' ? 'default' : 'outline'} className={`flex-1 ${paymentMethod === 'card' ? 'bg-purple-600 text-white' : ''}`}>כרטיס</Button>
          <Button type="button" onClick={() => setPaymentMethod('apple')} variant={paymentMethod === 'apple' ? 'default' : 'outline'} className={`flex-1 ${paymentMethod === 'apple' ? 'bg-purple-600 text-white' : ''}`}>Apple Pay</Button>
          <Button type="button" onClick={() => setPaymentMethod('google')} variant={paymentMethod === 'google' ? 'default' : 'outline'} className={`flex-1 ${paymentMethod === 'google' ? 'bg-purple-600 text-white' : ''}`}>Google Pay</Button>
        </div>
      </div>

      {/* Card Details */}
      {paymentMethod === 'card' && (
        <div className="space-y-4">
          <div>
            <Label htmlFor="number">מספר כרטיס</Label>
            <div className="relative">
              <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input 
                id="number"
                name="number"
                value={cardDetails.number}
                onChange={handleInputChange}
                placeholder="0000 0000 0000 0000"
                maxLength="19"
                className="pl-10"
                required
              />
            </div>
          </div>
          
          <div>
            <Label htmlFor="name">שם על הכרטיס</Label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <Input
                id="name"
                name="name"
                value={cardDetails.name}
                onChange={handleInputChange}
                placeholder="ישראל ישראלי"
                className="pl-10"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="expiry">תוקף (MM/YY)</Label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  id="expiry"
                  name="expiry"
                  value={cardDetails.expiry}
                  onChange={handleInputChange}
                  placeholder="MM / YY"
                  className="pl-10"
                  required
                />
              </div>
            </div>
            <div>
              <Label htmlFor="cvc">CVC</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <Input
                  id="cvc"
                  name="cvc"
                  value={cardDetails.cvc}
                  onChange={handleInputChange}
                  placeholder="123"
                  maxLength="3"
                  className="pl-10"
                  required
                />
              </div>
            </div>
          </div>
        </div>
      )}

      <Button
        type="submit"
        size="lg"
        className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-semibold"
        disabled={processing}
      >
        {processing ? (
          <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
        ) : (
          <>
            <Lock className="w-4 h-4 mr-2" />
            שלם עכשיו ₪{price}
          </>
        )}
      </Button>
    </form>
  );
}