import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Tag, Zap } from 'lucide-react';
import { useLanguage } from '../language/LanguageContext';

export default function PlanSummary({ planName, price, period }) {
  const { language } = useLanguage();
  if (!planName) return null;

  const isBoost = planName?.toLowerCase().includes('boost') || planName?.includes('בוסט');
  const totalPrice = parseFloat(price).toFixed(2);

  const renderSubscriptionSummary = () => {
    const getMultiplier = () => {
      if (planName?.includes('6')) return 6;
      if (planName?.includes('12') || planName?.includes('שנה')) return 12;
      return 1;
    };
    
    const multiplier = getMultiplier();
    const originalMonthlyPrice = 36.90;
    const originalPrice = (originalMonthlyPrice * multiplier).toFixed(2);
    const savedAmount = (originalPrice - totalPrice).toFixed(2);

    return (
      <>
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">סיכום הזמנה</h3>
            <p className="font-medium text-purple-700">{planName}</p>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-gray-900">₪{totalPrice}</p>
            <p className="text-sm text-gray-600">{period}</p>
          </div>
        </div>
        {multiplier > 1 && parseFloat(savedAmount) > 0 && (
          <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg flex items-center gap-2">
            <Tag className="w-4 h-4 text-green-600" />
            <p className="text-sm text-green-800 font-medium">
              {language === 'he' ? `חסכת ₪${savedAmount}` : `₪${savedAmount} ቆጥበዋል`}
            </p>
          </div>
        )}
      </>
    );
  };

  const renderBoostSummary = () => {
    const description = language === 'he' 
        ? 'הפרופיל שלך יוצג בראש התור למשך 30 דקות כדי לקבל יותר חשיפה והתאמות.' 
        : 'መገለጫዎ ለ30 ደቂቃዎች በቅድሚያ ይታያል፣ ይህም የበለጠ ተመልካች እና ግጥሚያዎችን እንዲያገኙ ይረዳዎታል።';
    return (
      <>
        <div className="flex justify-between items-start">
          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-2">סיכום הזמנה</h3>
            <div className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-yellow-500 fill-current" />
                <p className="font-medium text-purple-700">{planName}</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-2xl font-bold text-gray-900">₪{totalPrice}</p>
            <p className="text-sm text-gray-600">{period}</p>
          </div>
        </div>
        <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-sm text-yellow-800 font-medium">
              {description}
            </p>
        </div>
      </>
    )
  }

  return (
    <Card className="bg-purple-50/50 border-purple-200 shadow-md mb-6">
      <CardContent className="p-6">
        {isBoost ? renderBoostSummary() : renderSubscriptionSummary()}
      </CardContent>
    </Card>
  );
}