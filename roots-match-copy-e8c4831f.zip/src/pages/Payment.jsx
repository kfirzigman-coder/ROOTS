import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { createPageUrl } from '@/utils';
import { ArrowLeft } from "lucide-react";

// Updated import for Israeli payment functions as per outline
import { createIsraeliPayment } from "@/api/functions";
// New import for IsraeliPaymentForm component
import IsraeliPaymentForm from '../components/payment/IsraeliPaymentForm';

// Mocks for user and User API. In a real application, these would come from
// a proper authentication context (e.g., AuthProvider, useAuth hook)
// and an API service/utility for user data.
const User = {
  updateMyUserData: async (data) => {
    console.log('Mock: User data updated:', data);
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 500));
    return { success: true };
  }
};
// End mocks

export default function Payment() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams(); // Use useSearchParams hook
  const [isProcessing, setIsProcessing] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [error, setError] = useState(null);
  const [showPaymentForm, setShowPaymentForm] = useState(false);

  // State variables for plan details
  const [planId, setPlanId] = useState('');
  const [planName, setPlanName] = useState('');
  const [price, setPrice] = useState(0);
  const [period, setPeriod] = useState('');
  const [paymentType, setPaymentType] = useState('israeli');

  useEffect(() => {
    setPlanId(searchParams.get('planId') || '');
    setPlanName(searchParams.get('planName') || '');
    setPrice(parseFloat(searchParams.get('price') || '0'));
    setPeriod(searchParams.get('period') || '');
    setPaymentType(searchParams.get('paymentType') || 'israeli');
  }, [searchParams]);


  const testPayment = async () => {
    console.log('Testing payment creation...');
    setError(null);
    setIsProcessing(true);

    try {
      const response = await createIsraeliPayment({
        planName: 'בדיקה',
        amount: 10,
        customerName: 'לקוח בדיקה',
        customerEmail: 'test@example.com'
      });

      console.log('Test response:', response);

      if (response.data?.success) {
        alert(`הצלחה! מערכת התשלומים מוכנה.\n\n✅ API מוגדר נכון\n✅ Company ID: ${response.data.company_id}\n✅ מוכן לתשלומים\n\nעכשיו תוכל להמשיך לתשלום האמיתי.`);
        setShowPaymentForm(true);
      } else {
        setError(response.data?.error || 'שגיאה לא ידועה בבדיקה');
        alert('שגיאה: ' + (response.data?.error || 'שגיאה לא ידועה'));
      }
    } catch (error) {
      console.error('Test error:', error);
      setError('שגיאה בבדיקה: ' + error.message);
      alert(`שגיאה בבדיקה: ${error.message}\n\nפרטים נוספים זמינים בקונסול של הדפדפן (F12)`);
    } finally {
      setIsProcessing(false);
    }
  };

  const handlePaymentSuccess = async (paymentDetails) => {
    console.log('Payment successful:', paymentDetails);
    setPaymentSuccess(true);
    setError(null);
    try {
      await User.updateMyUserData({ is_premium: true });
      console.log('User premium status updated after successful payment.');
    } catch (updateError) {
      console.error('Failed to update user premium status:', updateError);
    }
  };

  const handlePaymentError = (errorMessage) => {
    console.error('Payment failed:', errorMessage);
    setError(errorMessage);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 flex items-center justify-center p-4" dir="rtl">
      <div className="absolute top-4 left-4 z-10">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate(createPageUrl('Discover'))}
          className="rounded-full bg-white/80 backdrop-blur-sm hover:bg-white shadow-lg"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
      </div>

      <div className="w-full max-w-md">
        {paymentSuccess ? (
          <div className="text-center p-8 bg-white rounded-2xl shadow-lg">
            <div className="text-6xl mb-4">🎉</div>
            <h1 className="text-2xl font-bold text-green-600 mb-4">תשלום בוצע בהצלחה!</h1>
            <p className="text-gray-600 mb-6">תודה על הרכישה. תוכל עכשיו ליהנות מהשירותים המתקדמים.</p>
            <Button onClick={() => navigate(createPageUrl('Discover'))} className="bg-purple-600 hover:bg-purple-700">
              חזור לאפליקציה
            </Button>
          </div>
        ) : showPaymentForm ? (
          <div className="space-y-4">
            <div className="flex items-center gap-4">
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => navigate(createPageUrl('Discover'))}
                className="flex items-center gap-2 text-gray-600 hover:text-gray-800"
              >
                <ArrowLeft className="w-4 h-4" />
                חזור לגילוי
              </Button>
              <h2 className="text-lg font-semibold text-gray-800">השלמת תשלום</h2>
            </div>
            
            <IsraeliPaymentForm
              planId={planId}
              planName={planName}
              amount={price}
              onSuccess={handlePaymentSuccess}
              onError={handlePaymentError}
            />
          </div>
        ) : (
          <div className="bg-white p-6 rounded-2xl shadow-lg">
            <div className="flex items-center justify-between mb-6">
              <h1 className="text-2xl font-bold">תשלום מאובטח</h1>
              <Button 
                variant="ghost" 
                size="sm"
                onClick={() => navigate(createPageUrl('Discover'))}
                className="text-gray-500 hover:text-gray-700"
              >
                ← חזור לגילוי
              </Button>
            </div>

            {planName && (
              <div className="bg-purple-50 p-4 rounded-xl mb-6">
                <h2 className="font-semibold text-lg">{planName}</h2>
                <p className="text-gray-600">{period}</p>
                <p className="text-2xl font-bold text-purple-600 mt-2">₪{price}</p>
              </div>
            )}

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-xl mb-4">
                {error}
              </div>
            )}

            <div className="space-y-4">
              <Button
                onClick={testPayment}
                className="w-full bg-blue-600 hover:bg-blue-700"
                disabled={isProcessing}
              >
                {isProcessing ? 'בודק חיבור...' : '🧪 בדוק חיבור למערכת התשלומים'}
              </Button>

              <Button
                onClick={() => setShowPaymentForm(true)}
                className="w-full bg-green-600 hover:bg-green-700"
                disabled={!planName || !price}
              >
                💳 המשך לתשלום
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}