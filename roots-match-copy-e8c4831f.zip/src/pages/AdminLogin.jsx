
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogDescription, DialogTitle, DialogFooter, DialogHeader } from '@/components/ui/dialog';
import { Shield, Eye, EyeOff, Lock, Fingerprint, CheckCircle, AlertCircle, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useLanguage } from '../components/language/LanguageContext';

export default function AdminLogin() {
  const [credentials, setCredentials] = useState({
    username: '',
    password: '',
    adminCode: ''
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [attempts, setAttempts] = useState(0);
  const [isBlocked, setIsBlocked] = useState(false);
  const [showDevInfo, setShowDevInfo] = useState(false);
  const [showBiometricModal, setShowBiometricModal] = useState(false);
  const [biometricStatus, setBiometricStatus] = useState('idle'); // idle, scanning, success, error
  const [biometricError, setBiometricError] = useState('');
  const [showSetupBiometricModal, setShowSetupBiometricModal] = useState(false);
  const [isSettingUpBiometric, setIsSettingUpBiometric] = useState(false);
  
  const navigate = useNavigate();
  const { language } = useLanguage();

  // קודי מנהל מאובטחים
  const ADMIN_CREDENTIALS = {
    username: 'admin@rootsmatch',
    password: 'RootsMatch2025!',
    adminCode: 'ETH777'
  };

  const MAX_ATTEMPTS = 3;
  const BLOCK_TIME = 5 * 60 * 1000; // 5 דקות

  const performSuccessfulLogin = () => {
    const adminUser = {
      email: 'admin@rootsmatch.com',
      full_name: 'מנהל RootsMatch',
      role: 'admin',
      id: 'admin_user_001',
      verified: true,
      login_time: new Date().toISOString()
    };

    localStorage.setItem('demo_user', JSON.stringify(adminUser));
    localStorage.setItem('demo_logged_in', 'true');
    localStorage.setItem('admin_session', JSON.stringify({
      loginTime: Date.now(),
      sessionId: Math.random().toString(36).substring(7)
    }));

    navigate(createPageUrl('AdminDashboard'));
  };

  const handlePasswordLogin = async (e) => {
    e.preventDefault();
    
    if (isBlocked) {
      setError('הגישה חסומה זמנית. נסה שוב מאוחר יותר.');
      return;
    }

    if (attempts >= MAX_ATTEMPTS) {
      setIsBlocked(true);
      setError('חרגת ממספר הניסיונות המותר. הגישה חסומה ל-5 דקות.');
      setTimeout(() => {
        setIsBlocked(false);
        setAttempts(0);
        setError('');
      }, BLOCK_TIME);
      return;
    }

    setIsLoading(true);
    setError('');

    // המתנה קצרה לסימולציה של בדיקת שרת
    await new Promise(resolve => setTimeout(resolve, 1000));

    // בדיקת פרטי התחברות
    if (
      credentials.username === ADMIN_CREDENTIALS.username &&
      credentials.password === ADMIN_CREDENTIALS.password &&
      credentials.adminCode === ADMIN_CREDENTIALS.adminCode
    ) {
      // התחברות מוצלחת
      const biometricCredential = localStorage.getItem('adminBiometricCredential');
      if (!biometricCredential && isBiometricSupported()) {
        // אם אין אימות ביומטרי שמור והמכשיר תומך, הצג הצעה להגדרה
        setShowSetupBiometricModal(true);
      } else {
        // אם יש כבר אימות או שהמכשיר לא תומך, פשוט התחבר
        performSuccessfulLogin();
      }
    } else {
      // התחברות נכשלה
      const newAttempts = attempts + 1;
      setAttempts(newAttempts);
      setError(`פרטי התחברות שגויים. ניסיון ${newAttempts} מתוך ${MAX_ATTEMPTS}`);
      
      if (newAttempts >= MAX_ATTEMPTS) {
        setIsBlocked(true);
        setError('חרגת ממספר הניסיונות המותר. הגישה חסומה ל-5 דקות.');
        setTimeout(() => {
          setIsBlocked(false);
          setAttempts(0);
          setError('');
        }, BLOCK_TIME);
      }
    }
    setIsLoading(false);
  };

  // בדיקה אם הדפדפן תומך בביומטריה ואם זה לא ב-iframe
  const isBiometricSupported = () => {
    try {
      // בדיקה אם זה iframe
      if (window.self !== window.top) {
        return false;
      }
      
      // בדיקה אם הדפדפן תומך ב-WebAuthn
      if (!window.PublicKeyCredential) {
        return false;
      }
      
      // בדיקה אם התמיכה זמינה
      return typeof window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable === 'function';
    } catch (error) {
      console.warn('Error checking biometric support:', error);
      return false;
    }
  };

  // יצירת credential לביומטריה
  const createBiometricCredential = async () => {
    try {
      // בדיקה נוספת לפני יצירה
      if (window.self !== window.top) {
        throw new Error('Biometric authentication not available in iframe');
      }

      const isAvailable = await window.PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable();
      if (!isAvailable) {
        throw new Error('Platform authenticator not available');
      }

      const credential = await navigator.credentials.create({
        publicKey: {
          challenge: window.crypto.getRandomValues(new Uint8Array(32)),
          rp: {
            name: "RootsMatch Admin",
            id: "localhost", // Use localhost for development
          },
          user: {
            id: new TextEncoder().encode("admin@rootsmatch"),
            name: "admin@rootsmatch",
            displayName: "מנהל RootsMatch",
          },
          pubKeyCredParams: [
            { alg: -7, type: "public-key" }, // ES256
            { alg: -257, type: "public-key" } // RS256
          ],
          authenticatorSelection: {
            authenticatorAttachment: "platform",
            userVerification: "required",
            requireResidentKey: false
          },
          timeout: 60000,
          attestation: "none"
        }
      });
      
      if (credential) {
        // שמירת credential ID ב-localStorage
        localStorage.setItem('adminBiometricCredential', credential.id);
        return true;
      }
      return false;
    } catch (error) {
      console.error('שגיאה ביצירת credential ביומטרי:', error);
      throw error;
    }
  };

  // אימות ביומטרי
  const authenticateWithBiometric = async () => {
    try {
      // בדיקה אם זה iframe
      if (window.self !== window.top) {
        throw new Error('Biometric authentication not available in iframe');
      }

      const credentialId = localStorage.getItem('adminBiometricCredential');
      if (!credentialId) {
        throw new Error('No biometric credential found');
      }

      const assertion = await navigator.credentials.get({
        publicKey: {
          challenge: window.crypto.getRandomValues(new Uint8Array(32)),
          allowCredentials: [{
            id: new TextEncoder().encode(credentialId),
            type: 'public-key'
          }],
          userVerification: "required",
          timeout: 60000
        }
      });

      return assertion !== null;
    } catch (error) {
      console.error('שגיאה באימות ביומטרי:', error);
      throw error;
    }
  };
  
  const handleEnableBiometrics = async () => {
    setIsSettingUpBiometric(true);
    try {
      await createBiometricCredential();
    } catch (error) {
        console.error("Biometric setup failed:", error);
        // המשתמש עדיין מחובר, פשוט לא הוגדר אימות ביומטרי
    } finally {
        setIsSettingUpBiometric(false);
        setShowSetupBiometricModal(false);
        performSuccessfulLogin(); // המשך לכניסה בכל מקרה
    }
  };

  const handleBiometricLogin = async () => {
    const hasCredential = localStorage.getItem('adminBiometricCredential');
    if (!hasCredential) {
      setError('יש להתחבר עם סיסמה פעם אחת כדי להפעיל זיהוי ביומטרי.');
      return;
    }
      
    if (!isBiometricSupported()) {
      if (window.self !== window.top) {
        setBiometricError('זיהוי ביומטרי אינו זמין במסגרת זו. פתח את האפליקציה בחלון נפרד.');
      } else {
        setBiometricError('המכשיר שלך לא תומך בזיהוי ביומטרי');
      }
      return;
    }

    setShowBiometricModal(true);
    setBiometricStatus('scanning');
    setBiometricError('');

    try {
      const isAuthenticated = await authenticateWithBiometric();
      
      if (isAuthenticated) {
        setBiometricStatus('success');
        setTimeout(() => {
          setShowBiometricModal(false);
          performSuccessfulLogin();
        }, 1500);
      } else {
        throw new Error('האימות הביומטרי נכשל');
      }
      
    } catch (error) {
      setBiometricStatus('error');
      let errorMessage = 'שגיאה בזיהוי ביומטרי';
      
      if (error.message.includes('iframe')) {
        errorMessage = 'זיהוי ביומטרי אינו זמין במסגרת זו';
      } else if (error.name === 'NotAllowedError') {
        errorMessage = 'הגישה לזיהוי ביומטרי נדחתה';
      } else if (error.name === 'AbortError') {
        errorMessage = 'הזיהוי הביומטרי בוטל';
      } else if (error.name === 'NotSupportedError') {
        errorMessage = 'המכשיר לא תומך בזיהוי ביומטרי';
      } else if (error.message.includes('Platform authenticator not available')) {
        errorMessage = 'הזיהוי הביומטרי אינו זמין כרגע במכשיר שלך';
      }
      
      setBiometricError(errorMessage);
      
      setTimeout(() => {
        setShowBiometricModal(false);
        setBiometricStatus('idle');
      }, 3000);
    }
  };

  const handleInputChange = (field, value) => {
    setCredentials(prev => ({ ...prev, [field]: value }));
    if (error) setError('');
  };

  const getBiometricStatusDisplay = () => {
    switch (biometricStatus) {
      case 'registering':
        return {
          icon: <Fingerprint className="w-20 h-20 text-blue-400 animate-pulse" />,
          title: 'מגדיר זיהוי ביומטרי...',
          subtitle: 'אנא בצע את האימות הביומטרי בפעם הראשונה'
        };
      case 'scanning':
        return {
          icon: <Fingerprint className="w-20 h-20 text-cyan-300 animate-pulse" />,
          title: 'מזהה...',
          subtitle: 'אנא השתמש בחיישן הביומטרי שלך'
        };
      case 'success':
        return {
          icon: <CheckCircle className="w-20 h-20 text-green-400" />,
          title: 'הזיהוי הושלם בהצלחה!',
          subtitle: 'מתחבר למערכת...'
        };
      case 'error':
        return {
          icon: <AlertCircle className="w-20 h-20 text-red-400" />,
          title: 'שגיאה בזיהוי',
          subtitle: biometricError
        };
      default:
        return null;
    }
  };

  return (
    <>
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-red-900 flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="w-full max-w-md"
        >
          <Card className="bg-white/10 backdrop-blur-sm border border-white/20 shadow-2xl">
            <CardHeader className="text-center">
              <motion.div
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                className="w-16 h-16 bg-red-600 rounded-full flex items-center justify-center mx-auto mb-4"
              >
                <Shield className="w-8 h-8 text-white" />
              </motion.div>
              <CardTitle className="text-2xl font-bold text-white">
                כניסת מנהל מערכת
              </CardTitle>
              <p className="text-gray-300 text-sm">
                אזור מוגבל - למנהלים מורשים בלבד
              </p>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <form onSubmit={handlePasswordLogin} className="space-y-4">
                {/* שם משתמש */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-200">
                    שם משתמש
                  </label>
                  <Input
                    type="text"
                    value={credentials.username}
                    onChange={(e) => handleInputChange('username', e.target.value)}
                    className="bg-white/10 border-white/20 text-white placeholder-gray-300"
                    placeholder="הכנס שם משתמש"
                    disabled={isBlocked}
                    required
                  />
                </div>

                {/* סיסמה */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-200">
                    סיסמה
                  </label>
                  <div className="relative">
                    <Input
                      type={showPassword ? "text" : "password"}
                      value={credentials.password}
                      onChange={(e) => handleInputChange('password', e.target.value)}
                      className="bg-white/10 border-white/20 text-white placeholder-gray-300 pr-10"
                      placeholder="הכנס סיסמה"
                      disabled={isBlocked}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300 hover:text-white"
                    >
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* קוד מנהל */}
                <div className="space-y-2">
                  <label className="text-sm font-medium text-gray-200">
                    קוד מנהל
                  </label>
                  <div className="relative">
                    <Input
                      type="text"
                      value={credentials.adminCode}
                      onChange={(e) => handleInputChange('adminCode', e.target.value.toUpperCase())}
                      className="bg-white/10 border-white/20 text-white placeholder-gray-300 pr-10"
                      placeholder="הכנס קוד מנהל"
                      disabled={isBlocked}
                      required
                    />
                    <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-300 w-4 h-4" />
                  </div>
                </div>

                {/* הודעת שגיאה */}
                {error && (
                  <motion.div
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="bg-red-500/20 border border-red-500/30 rounded-lg p-3"
                  >
                    <p className="text-red-200 text-sm text-center">{error}</p>
                  </motion.div>
                )}

                {/* כפתור התחברות */}
                <Button
                  type="submit"
                  disabled={isLoading || isBlocked || !credentials.username || !credentials.password || !credentials.adminCode}
                  className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isLoading ? (
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                      מאמת נתונים...
                    </div>
                  ) : (
                    'התחבר כמנהל'
                  )}
                </Button>
              </form>

              {/* Biometric Login Button */}
              {isBiometricSupported() && (
                <>
                  <div className="relative flex py-2 items-center">
                    <div className="flex-grow border-t border-gray-600"></div>
                    <span className="flex-shrink mx-4 text-gray-400 text-xs">או</span>
                    <div className="flex-grow border-t border-gray-600"></div>
                  </div>
                  <Button
                    variant="outline"
                    onClick={handleBiometricLogin}
                    className="w-full border-white/20 text-gray-300 hover:bg-white/10 hover:text-white flex items-center gap-2 py-3"
                  >
                    <Fingerprint className="w-5 h-5 text-cyan-300" />
                    התחבר עם זיהוי ביומטרי
                  </Button>
                </>
              )}

              {/* הודעה אם זה iframe */}
              {window.self !== window.top && (
                <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-lg p-3">
                  <p className="text-yellow-200 text-xs text-center">
                    💡 לזיהוי ביומטרי, פתח את האפליקציה בחלון נפרד
                  </p>
                </div>
              )}

              {/* אזהרת אבטחה */}
              <div className="bg-yellow-500/20 border border-yellow-500/30 rounded-lg p-3">
                <p className="text-yellow-200 text-xs text-center">
                  ⚠️ כל ניסיונות הכניסה נרשמים ונשלחים למחלקת האבטחה
                </p>
              </div>

              {/* כפתור חזרה */}
              <Button
                variant="outline"
                onClick={() => navigate(createPageUrl('Landing'))}
                className="w-full border-white/20 text-gray-300 hover:bg-white/10 hover:text-white"
              >
                חזרה לעמוד הראשי
              </Button>

              {/* כפתור להצגת פרטי פיתוח */}
              <Button
                variant="ghost"
                onClick={() => setShowDevInfo(!showDevInfo)}
                className="w-full text-blue-300 hover:text-blue-200 text-xs"
              >
                {showDevInfo ? 'הסתר' : 'הצג'} פרטי כניסה למפתח
              </Button>
            </CardContent>
          </Card>

          {/* הוראות למפתח */}
          {showDevInfo && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3 }}
              className="mt-4 bg-blue-500/20 border border-blue-500/30 rounded-lg p-4"
            >
              <h4 className="text-blue-200 font-semibold mb-2">🔧 מידע למפתח:</h4>
              <div className="text-blue-100 text-xs space-y-1">
                <p><strong>שם משתמש:</strong> admin@rootsmatch</p>
                <p><strong>סיסמה:</strong> RootsMatch2025!</p>
                <p><strong>קוד מנהל:</strong> ETH777</p>
                <p className="mt-2 text-cyan-200">
                  <strong>זיהוי ביומטרי:</strong> משתמש בחיישני הסמרטפון האמיתיים
                </p>
              </div>
            </motion.div>
          )}
        </motion.div>
      </div>

      {/* Biometric Authentication Modal */}
      <AnimatePresence>
        {showBiometricModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm flex flex-col items-center justify-center z-50"
          >
            <motion.div
              key={biometricStatus}
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.5, opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="text-center text-white"
            >
              {getBiometricStatusDisplay() && (
                <>
                  <div className="mb-6">
                    {getBiometricStatusDisplay().icon}
                  </div>
                  <h3 className="text-2xl font-bold mb-2">
                    {getBiometricStatusDisplay().title}
                  </h3>
                  <p className="text-gray-300 mb-4">
                    {getBiometricStatusDisplay().subtitle}
                  </p>
                  {biometricStatus === 'error' && (
                    <Button
                      variant="outline"
                      onClick={() => setShowBiometricModal(false)}
                      className="mt-4 border-white/30 text-white hover:bg-white/10"
                    >
                      סגור
                    </Button>
                  )}
                </>
              )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Setup Biometric Modal */}
      <Dialog open={showSetupBiometricModal} onOpenChange={setShowSetupBiometricModal}>
        <DialogContent dir="rtl">
          <DialogHeader>
            <DialogTitle className="text-center text-xl font-bold">הפעלת כניסה מהירה</DialogTitle>
            <DialogDescription className="text-center">
              האם תרצה להפעיל כניסה באמצעות זיהוי ביומטרי (Face ID/טביעת אצבע) לפעמים הבאות?
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-center text-6xl my-4">
            <Fingerprint className="text-cyan-400" />
          </div>
          <DialogFooter className="grid grid-cols-2 gap-3">
            <Button
              variant="outline"
              onClick={() => {
                setShowSetupBiometricModal(false);
                performSuccessfulLogin();
              }}
            >
              אולי בפעם הבאה
            </Button>
            <Button onClick={handleEnableBiometrics} disabled={isSettingUpBiometric}>
              {isSettingUpBiometric ? <Loader2 className="ml-2 h-4 w-4 animate-spin" /> : null}
              {isSettingUpBiometric ? 'מגדיר...' : 'כן, להפעיל'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
