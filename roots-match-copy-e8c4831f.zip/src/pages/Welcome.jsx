import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { User } from '@/api/entities';
import { Heart, Users, Shield, Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useLanguage } from '../components/language/LanguageContext';

export default function Welcome() {
  const { language, changeLanguage } = useLanguage();
  const navigate = useNavigate();

  const handleLogin = async () => {
    try {
      await User.loginWithRedirect(window.location.origin + createPageUrl('Onboarding'));
    } catch (error) {
      console.error('Login failed:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-pink-50 to-orange-50 relative overflow-hidden" dir={language === 'he' ? 'rtl' : 'ltr'}>
      
      {/* Background Effects */}
      <div className="absolute inset-0">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute text-pink-300/40"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [-10, -30, -10],
              opacity: [0.3, 0.8, 0.3],
              scale: [0.8, 1.2, 0.8]
            }}
            transition={{
              duration: 4 + Math.random() * 2,
              repeat: Infinity,
              delay: i * 0.5,
              ease: "easeInOut"
            }}
          >
            <Heart className="w-6 h-6" />
          </motion.div>
        ))}
      </div>

      {/* Language Toggle */}
      <div className="absolute top-8 right-6 z-20">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => changeLanguage(language === 'he' ? 'am' : 'he')}
          className="text-purple-700 hover:bg-white/80 rounded-full px-4 py-2 backdrop-blur-md border border-white/40 bg-white/60 shadow-lg"
        >
          🌍 {language === 'he' ? 'Am' : 'עב'}
        </Button>
      </div>

      <div className="flex items-center justify-center min-h-screen px-6 py-12">
        <div className="max-w-md mx-auto">
          
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            className="bg-white/80 backdrop-blur-lg rounded-3xl shadow-2xl border border-white/30 overflow-hidden text-center p-8"
          >
            
            {/* Logo */}
            <div className="w-24 h-24 mx-auto mb-6 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 p-3 shadow-xl">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/fd93b36f7_WhatsAppImage2025-07-14at012021.jpeg"
                alt="RootsMatch Logo"
                className="w-full h-full object-contain rounded-full bg-white p-1"
              />
            </div>

            {/* Title */}
            <h1 className="text-3xl font-bold mb-2 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              {language === 'he' ? 'ברוכים הבאים ל-RootsMatch' : 'Welcome to RootsMatch'}
            </h1>
            
            <p className="text-gray-600 mb-8">
              {language === 'he' ? 'התחברות שורשית לקהילה האתיופית' : 'A deep connection for the Ethiopian community'}
            </p>

            {/* CTA Button */}
            <Button
              onClick={handleLogin}
              className="w-full h-14 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white text-lg font-bold rounded-2xl shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:scale-105 mb-6"
            >
              {language === 'he' ? 'בואו נתחיל!' : 'Let\'s Start!'}
            </Button>

            {/* Features Grid */}
            <div className="grid grid-cols-2 gap-3">
              {[
                { icon: Heart, text: language === 'he' ? 'אהבה אמיתית' : 'True Love' },
                { icon: Users, text: language === 'he' ? 'קהילה חמה' : 'Warm Community' },
                { icon: Shield, text: language === 'he' ? 'סביבה בטוחה' : 'Safe Environment' },
                { icon: Star, text: language === 'he' ? 'פרופילים איכותיים' : 'Quality Profiles' }
              ].map((feature, index) => (
                <div key={index} className="bg-white/60 p-3 rounded-xl border border-purple-100 shadow-sm">
                  <feature.icon className="w-6 h-6 text-purple-600 mx-auto mb-1" />
                  <p className="text-xs font-medium text-gray-700">{feature.text}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}