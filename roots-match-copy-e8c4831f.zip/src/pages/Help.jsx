import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Mail, MessageSquare, Clock } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useLanguage } from '../components/language/LanguageContext';
import { motion } from 'framer-motion';

export default function Help() {
  const navigate = useNavigate();
  const { language } = useLanguage();

  const helpContentHe = (
    <>
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2 text-purple-900">עזרה ותמיכה – RootsMatch</h1>
        <p className="text-gray-600">
          ברוכים הבאים ל־RootsMatch – אפליקציית ההיכרויות הראשונה שמיועדת במיוחד ליוצאי העדה האתיופית בישראל. אנחנו כאן כדי לעזור לך למצוא קשר אמיתי עם אנשים שמבינים את התרבות, המסורת והלב שלך.
        </p>
      </div>

      <div className="space-y-8">
        <div>
          <h2 className="text-2xl font-bold mb-4 text-purple-800 border-b-2 border-purple-200 pb-2">שאלות נפוצות</h2>
          <div className="space-y-6 mt-4">
            <div>
              <h3 className="text-xl font-semibold mb-2">🧾 איך נרשמים לאפליקציה?</h3>
              <p>פשוט מאוד – בכניסה לאפליקציה בחר "התחבר עם גוגל", מלא את הפרטים שלך, בחר את העדה שלך (אתיופית), ותתחיל לגלוש בפרופילים.</p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">📸 איך עורכים את הפרופיל שלי?</h3>
              <p>לחץ בתפריט התחתון על "הפרופיל שלי" → ואז "עריכת פרופיל". תוכל להעלות תמונה, לכתוב תיאור קצר, לבחור גיל מועדף, ואפילו לציין אם אתה מסורתי/חילוני/דתי.</p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">💬 איך שולחים הודעה?</h3>
              <p>ברגע שיש התאמה (שני הצדדים עשו לייק) – נפתח צ'אט אוטומטי. פשוט לחץ על ההתאמה שלך והתחל שיחה.</p>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">🏆 מה מקבלים בפרימיום?</h3>
              <ul className="list-disc list-inside space-y-1 pl-4">
                <li>רואים מי עשה לך לייק</li>
                <li>הקפצה יומית של הפרופיל</li>
                <li>בלי פרסומות</li>
                <li>סינון מתקדם לפי עיר, גיל ועוד</li>
              </ul>
            </div>
            <div>
              <h3 className="text-xl font-semibold mb-2">🌍 האם אפשר לבחור שפה?</h3>
              <p>כן! ניתן לבחור בין עברית, אמהרית, או אנגלית מתוך ההגדרות באפליקציה.</p>
            </div>
          </div>
        </div>

        <div>
          <h2 className="text-2xl font-bold mb-4 text-purple-800 border-b-2 border-purple-200 pb-2">צריך עזרה?</h2>
          <div className="space-y-4 mt-4">
            <div className="flex items-start gap-4">
              <Mail className="w-6 h-6 text-purple-600 mt-1" />
              <div>
                <h4 className="font-semibold">צור קשר עם צוות RootsMatch:</h4>
                <p>דוא"ל: support@rootsmatch.co.il</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <MessageSquare className="w-6 h-6 text-green-600 mt-1" />
              <div>
                <h4 className="font-semibold">וואטסאפ שירות:</h4>
                <p>050-4041505</p>
              </div>
            </div>
            <div className="flex items-start gap-4">
              <Clock className="w-6 h-6 text-gray-600 mt-1" />
              <div>
                <h4 className="font-semibold">שעות פעילות:</h4>
                <p>ימים א’-ה’, 9:00–17:00</p>
              </div>
            </div>
          </div>
        </div>
        
        <div>
          <h2 className="text-2xl font-bold mb-4 text-purple-800 border-b-2 border-purple-200 pb-2">רוצה לדווח על משתמש?</h2>
          <p className="mt-4">
            בכל פרופיל תמצא כפתור “דיווח”. אפשר לדווח על התנהגות לא ראויה, התחזות, או פגיעה בשיח מכבד.
          </p>
        </div>
      </div>
    </>
  );

  return (
    <div className="min-h-screen bg-gray-50 p-4 sm:p-6" dir={language === 'he' ? 'rtl' : 'ltr'}>
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
        >
            <div className="flex items-center mb-6">
                <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
                  <ArrowLeft className="w-5 h-5" />
                </Button>
                <h1 className="text-xl font-bold ml-4 sm:mr-4">
                    עזרה ותמיכה
                </h1>
            </div>

            <div className="bg-white p-6 sm:p-8 rounded-2xl shadow-sm prose prose-sm sm:prose-base max-w-none">
                {helpContentHe}
            </div>
        </motion.div>
    </div>
  );
}