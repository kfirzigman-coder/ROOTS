import React from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import LocationPermissionComponent from '../components/permissions/LocationPermission';

export default function LocationPermission() {
  const navigate = useNavigate();

  const handlePermissionGranted = (location) => {
    console.log('Location granted:', location);
    navigate(createPageUrl('Discover'), { replace: true });
  };

  const handleSkip = () => {
    navigate(createPageUrl('Discover'), { replace: true });
  };

  return (
    <LocationPermissionComponent 
      onPermissionGranted={handlePermissionGranted}
      onSkip={handleSkip}
    />
  );
}