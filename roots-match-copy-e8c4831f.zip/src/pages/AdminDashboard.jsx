
import React, { useState, useEffect } from 'react';
import { User, VerificationRequest, Match } from '@/api/entities'; // Added Match entity
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Users, UserCheck, Clock, Settings, LogOut, Heart, Star, Shield, AlertTriangle, Activity } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { useLanguage } from '../components/language/LanguageContext';
import { motion } from 'framer-motion';

export default function AdminDashboard() {
  const [stats, setStats] = useState({
    totalUsers: 0,
    pendingVerifications: 0,
    registeredUsers: 0,
    onboardedUsers: 0,
    totalMatches: 0,
    weeklyMatches: 0,
    premiumUsers: 0,
    verifiedUsers: 0,
  });
  const [userList, setUserList] = useState([]); // Kept for potential use in AdminUserManagement, though not displayed here.
  const [loading, setLoading] = useState(true);
  const [currentUser, setCurrentUser] = useState(null); // State to store current admin user
  const navigate = useNavigate();
  const { language } = useLanguage();

  useEffect(() => {
    const checkAdmin = async () => {
      // First, check for the demo admin user in localStorage
      const demoLoggedIn = localStorage.getItem('demo_logged_in');
      const demoUserStr = localStorage.getItem('demo_user');

      if (demoLoggedIn === 'true' && demoUserStr) {
        try {
          const demoUser = JSON.parse(demoUserStr);
          if (demoUser.role === 'admin') {
            setCurrentUser(demoUser); // Set demo user
            fetchStats();
            return;
          }
        } catch (e) {
          // Parsing failed, fall through to check for a real user
          console.error("Failed to parse demo user from localStorage:", e);
        }
      }

      // If no demo admin, check for a real authenticated admin
      try {
        const user = await User.me();
        if (user.role !== 'admin') {
          // Real user, but not admin
          navigate(createPageUrl('Discover'));
        } else {
          // Real admin, proceed.
          setCurrentUser(user); // Set real user
          fetchStats();
        }
      } catch (error) {
        // No one is logged in, redirect to landing
        navigate(createPageUrl('Landing'));
      }
    };
    checkAdmin();
  }, [navigate]);

  const handleAdminLogout = async () => {
    console.log('🚪 Admin logout initiated');
    try {
      // Perform actual logout
      await User.logout();
      
      // Force clear local storage for a clean exit
      localStorage.clear();

      console.log('✅ Admin logout successful');
      
      // Force navigation to welcome page
      window.location.href = createPageUrl('Welcome');
      
    } catch (error) {
      console.error('❌ Admin logout failed:', error);
      
      // Force logout even if API fails
      localStorage.clear();
      window.location.href = createPageUrl('Welcome');
    }
  };

  const fetchStats = async () => {
    try {
      // Get only real users from database
      const users = await User.list('', 1000);
      setUserList(users); // Still populate userList for other components if needed

      const pendingRequests = await VerificationRequest.filter({ status: 'pending' });

      // Calculate real user statistics
      const registeredUsers = users.length;
      const onboardedUsers = users.filter(user => user.onboarding_completed).length;
      const premiumUsers = users.filter(user => user.is_premium).length;
      const verifiedUsers = users.filter(user => user.verified).length;

      // Get real match data
      const matches = await Match.filter({ status: 'matched' }, '', 1000);
      const totalMatches = matches.length;
      
      // Calculate weekly matches (last 7 days)
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      const weeklyMatches = matches.filter(match => 
        new Date(match.matched_at || match.created_date) >= weekAgo
      ).length;

      setStats({
        totalUsers: registeredUsers,
        pendingVerifications: pendingRequests.length,
        registeredUsers: registeredUsers,
        onboardedUsers: onboardedUsers,
        totalMatches: totalMatches,
        weeklyMatches: weeklyMatches,
        // FIX: Ensure premiumUsers is always a number, defaulting to 0
        premiumUsers: premiumUsers || 0,
        verifiedUsers: verifiedUsers,
      });
    } catch (error) {
      console.error('Error fetching stats:', error);
      // Set default values in case of error
      setStats({
        totalUsers: 0,
        pendingVerifications: 0,
        registeredUsers: 0,
        onboardedUsers: 0,
        totalMatches: 0,
        weeklyMatches: 0,
        premiumUsers: 0,
        verifiedUsers: 0,
      });
      setUserList([]);
    }
    setLoading(false);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 pb-32" dir={language === 'he' ? 'rtl' : 'ltr'}>
      <style jsx>{`
        .admin-dashboard {
          padding-bottom: calc(2rem + env(safe-area-inset-bottom));
        }
      `}</style>
      
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-gradient-to-r from-red-600 to-red-700 text-white p-6 shadow-lg"
      >
        <div className="max-w-4xl mx-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8" />
              <div>
                <h1 className="text-2xl font-bold">לוח בקרה מנהל</h1>
                <p className="text-red-100">ניהול מערכת RootsMatch</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-red-100">מחובר כמנהל</p>
              <p className="font-semibold">{currentUser?.email}</p>
            </div>
          </div>
        </div>
      </motion.div>

      <div className="max-w-4xl mx-auto p-6 admin-dashboard">
        <h1 className="text-3xl font-bold mb-6 text-gray-800">ניהול מערכת</h1>

        {/* User Statistics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8"
        >
          <Card className="border-0 shadow-lg bg-gradient-to-br from-blue-50 to-blue-100">
            <CardContent className="p-6 text-center">
              <Users className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-blue-900">{stats.totalUsers}</h3>
              <p className="text-blue-700">סה״כ משתמשים</p>
              <p className="text-xs text-blue-600 mt-1">
                רשומים: {stats.registeredUsers} | השלימו הרשמה: {stats.onboardedUsers}
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-green-50 to-green-100">
            <CardContent className="p-6 text-center">
              <Heart className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-green-900">{stats.totalMatches}</h3>
              <p className="text-green-700">סה״כ התאמות</p>
              <p className="text-xs text-green-600 mt-1">
                פעילות השבוע: {stats.weeklyMatches}
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-purple-50 to-purple-100">
            <CardContent className="p-6 text-center">
              <Star className="w-12 h-12 text-purple-600 mx-auto mb-4" />
              {/* FIX: Explicitly handle number type for display */}
              <h3 className="text-2xl font-bold text-purple-900">{stats.premiumUsers ?? 0}</h3>
              <p className="text-purple-700">משתמשי פרימיום</p>
              <p className="text-xs text-purple-600 mt-1">
                שיעור הסבה: {stats.totalUsers > 0 ? (((stats.premiumUsers ?? 0) / stats.totalUsers) * 100).toFixed(1) : 0}%
              </p>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-gradient-to-br from-orange-50 to-orange-100">
            <CardContent className="p-6 text-center">
              <Shield className="w-12 h-12 text-orange-600 mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-orange-900">{stats.verifiedUsers}</h3>
              <p className="text-orange-700">משתמשים מאומתים</p>
              <p className="text-xs text-orange-600 mt-1">
                ממתינים לאימות: {stats.pendingVerifications}
              </p>
            </CardContent>
          </Card>
        </motion.div>

        {/* Quick Actions (now simplified/relocated) */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8"
        >
          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-800">ניהול משתמשים</h3>
                <Users className="w-6 h-6 text-gray-600" />
              </div>
              <p className="text-gray-600 mb-4">נהל משתמשים, אמת פרופילים ובדוק דוחות</p>
              <Button
                onClick={() => navigate(createPageUrl('AdminUserManagement'))}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white"
              >
                פתח ניהול משתמשים
              </Button>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-800">הגדרות מערכת</h3>
                <Settings className="w-6 h-6 text-gray-600" />
              </div>
              <p className="text-gray-600 mb-4">קבע הגדרות כלליות ונהל את האפליקציה</p>
              <Button
                onClick={() => navigate(createPageUrl('AdminSettings'))}
                className="w-full bg-purple-600 hover:bg-purple-700 text-white"
              >
                פתח הגדרות
              </Button>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg hover:shadow-xl transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-800">בדיקת מערכת</h3>
                <AlertTriangle className="w-6 h-6 text-gray-600" />
              </div>
              <p className="text-gray-600 mb-4">בדוק שהמערכת עובדת תקין למשתמשים</p>
              <Button
                onClick={() => {
                  // Force add some test data
                  localStorage.setItem('forceNextMatch', 'true');
                  alert('הבדיקה הבאה תיצור התאמה מובטחת!');
                }}
                className="w-full bg-green-600 hover:bg-green-700 text-white"
              >
                הפעל בדיקה
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        {/* System Status */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.6 }}
          className="mb-8"
        >
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-gray-800">
                <Activity className="w-5 h-5 text-gray-600" />
                סטטוס מערכת
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="font-medium text-gray-700">מסד נתונים</span>
                  </div>
                  <span className="text-green-700 text-sm">פעיל</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                    <span className="font-medium text-gray-700">שרת האפליקציה</span>
                  </div>
                  <span className="text-green-700 text-sm">פעיל</span>
                </div>
                <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                    <span className="font-medium text-gray-700">משתמשים פעילים כרגע</span>
                  </div>
                  <span className="text-blue-700 text-sm">{Math.max(1, Math.floor(stats.totalUsers * 0.1))}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Quick User Access Instead of Long Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.8 }}
          className="mb-8"
        >
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-gray-800">
                <Users className="w-5 h-5 text-gray-600" />
                ניהול משתמשים מהיר
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-gradient-to-r from-blue-50 to-blue-100 p-4 rounded-xl">
                  <h3 className="font-semibold text-blue-900 mb-2">משתמשים רשומים</h3>
                  <p className="text-2xl font-bold text-blue-700 mb-3">{stats.totalUsers}</p>
                  <Button 
                    onClick={() => navigate(createPageUrl('AdminUserManagement'))}
                    className="w-full bg-blue-600 hover:bg-blue-700"
                  >
                    כניסה לניהול משתמשים
                  </Button>
                </div>

                <div className="bg-gradient-to-r from-orange-50 to-orange-100 p-4 rounded-xl">
                  <h3 className="font-semibold text-orange-900 mb-2">בקשות אימות</h3>
                  <p className="text-2xl font-bold text-orange-700 mb-3">{stats.pendingVerifications}</p>
                  <Button 
                    onClick={() => navigate(createPageUrl('AdminUserManagement'))}
                    className="w-full bg-orange-600 hover:bg-orange-700"
                    disabled={stats.pendingVerifications === 0}
                  >
                    {stats.pendingVerifications > 0 ? 'טפל בבקשות' : 'אין בקשות ממתינות'}
                  </Button>
                </div>
              </div>

              <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between text-sm text-gray-600">
                  <span>השלימו הרשמה: {stats.onboardedUsers}</span>
                  <span>מאומתים: {stats.verifiedUsers}</span>
                  <span>פרימיום: {stats.premiumUsers}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* System Actions */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.0 }}
          className="mb-8"
        >
          <Card className="border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-gray-800">
                <Settings className="w-5 h-5 text-gray-600" />
                פעולות מערכת
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button 
                  onClick={() => {
                    localStorage.setItem('forceNextMatch', 'true');
                    alert('הבדיקה הבאה תיצור התאמה מובטחת!');
                  }}
                  className="h-16 bg-green-600 hover:bg-green-700 text-white flex flex-col items-center justify-center"
                >
                  <AlertTriangle className="w-6 h-6 mb-1" />
                  <span>יצירת התאמה לבדיקה</span>
                </Button>

                <Button 
                  onClick={() => navigate(createPageUrl('AdminSettings'))}
                  className="h-16 bg-purple-600 hover:bg-purple-700 text-white flex flex-col items-center justify-center"
                >
                  <Settings className="w-6 h-6 mb-1" />
                  <span>הגדרות מערכת</span>
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Logout Button - Properly Spaced and Accessible */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.2 }}
          className="mt-12 text-center"
        >
          <div className="bg-white p-6 rounded-3xl shadow-lg border border-red-100">
            <h3 className="text-lg font-bold text-gray-800 mb-4">סיום עבודה</h3>
            <Button 
              onClick={async () => {
                console.log('🖱️ Logout button clicked');
                
                // Show confirmation
                const confirmed = window.confirm('האם אתה בטוח שברצונך להתנתק ממצב מנהל?');
                
                if (confirmed) {
                  console.log('✅ User confirmed logout');
                  await handleAdminLogout();
                } else {
                  console.log('❌ User cancelled logout');
                }
              }}
              size="lg" 
              variant="destructive" 
              className="w-full max-w-sm mx-auto h-16 text-lg font-bold shadow-lg rounded-2xl bg-red-600 hover:bg-red-700 border-2 border-red-500 transition-all duration-200 active:scale-95"
            >
              <LogOut className="ml-2 h-6 w-6" />
              התנתק ממצב מנהל
            </Button>
            <p className="text-sm text-gray-500 mt-3">
              לחץ כאן כדי לחזור למצב משתמש רגיל
            </p>
          </div>
        </motion.div>

        {/* Extra Bottom Spacing */}
        <div className="h-20"></div>
      </div>
    </div>
  );
}
