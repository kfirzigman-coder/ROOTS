
import React, { useState, useEffect, useMemo, useRef } from 'react';
import { User, PublicProfile, VerificationRequest } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Camera, Edit3, Loader2, X, Star, CheckCheck, PersonStanding, Tag, ShieldCheck, HeartHandshake, CheckCircle, ClipboardList, PenSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from '../components/language/LanguageContext';
import { UploadFile } from '@/api/integrations';
import VerificationModal from '../components/profile/VerificationModal';

// Profile Completion Ring Component
const ProfileCompletionRing = ({ completion, size, strokeWidth }) => {
  const radius = 48; // This radius is for a 100x100 viewBox
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (completion / 100) * circumference;

  return (
    <div className={`relative flex items-center justify-center`} style={{ width: size, height: size }}>
      <svg className="absolute top-0 left-0 w-full h-full" viewBox="0 0 100 100">
        <circle className="text-white/20" strokeWidth={strokeWidth} stroke="currentColor" fill="transparent" r={radius} cx="50" cy="50" />
        <motion.circle
          className="text-white"
          strokeWidth={strokeWidth}
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          stroke="currentColor"
          fill="transparent"
          r={radius}
          cx="50"
          cy="50"
          style={{ transform: 'rotate(-90deg)', transformOrigin: '50% 50%' }}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset }}
          transition={{ duration: 1, delay: 0.5 }}
        />
      </svg>
      <div className="absolute text-white font-bold text-lg">
        {completion === 100 ? (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ type: 'spring', stiffness: 260, damping: 20, delay: 1 }}
            className="flex items-center justify-center"
          >
            <CheckCircle className="w-8 h-8" />
          </motion.div>
        ) : (
          `${completion}%`
        )}
      </div>
    </div>
  );
};


// Profile Header with Progress Ring
const ProfileHeader = ({ user, completion, onEditClick }) => {
  return (
    <motion.div
      className="relative h-60 w-full overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8 }}
    >
      <div className="absolute inset-0 bg-gradient-to-br from-[#7B3FA3] to-[#E7B6E1] z-0"/>
      <div className="absolute inset-0 bg-black/10 z-0"/>

      <div className="relative z-10 flex flex-col items-center justify-center h-full text-white pt-8">
        <motion.div
          className="relative"
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2, type: 'spring', stiffness: 200 }}
        >
          <div className="relative">
            <ProfileCompletionRing completion={completion} size={140} strokeWidth={4} />
            <img
              src={user.photos?.[0] || 'https://via.placeholder.com/150'}
              alt="Profile"
              className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[110px] h-[110px] object-cover rounded-full border-2 border-white/50"
            />
          </div>
          <motion.div
            initial={{ scale: 0, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="absolute -bottom-1 -right-1"
          >
             <Button size="icon" onClick={onEditClick} className="w-10 h-10 bg-white/30 backdrop-blur-md text-white rounded-full hover:bg-white/40">
                <Edit3 className="w-5 h-5" />
            </Button>
          </motion.div>
        </motion.div>

        <motion.h1
          className="text-2xl font-bold mt-3"
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          {user.chosen_name || user.full_name}
        </motion.h1>

        <motion.div
           initial={{ y: 20, opacity: 0 }}
           animate={{ y: 0, opacity: 1 }}
           transition={{ delay: 0.5 }}
           className="text-sm font-medium text-white/80"
        >
          {completion === 100 ? (
            <div className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              <span>פרופיל מושלם! ⭐</span>
            </div>
          ) : (
            `השלם את הפרופיל לחשיפה מרבית (${completion}%)`
          )}
        </motion.div>
      </div>
    </motion.div>
  );
};

// Reusable Section Card
const Section = React.forwardRef(({ title, icon: Icon, children, className }, ref) => (
  <motion.div
    ref={ref}
    className={`bg-white/80 backdrop-blur-lg rounded-3xl shadow-lg border border-purple-100/30 overflow-hidden ${className}`}
    initial={{ opacity: 0, y: 30 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, type: 'spring' }}
  >
    <div className="p-5 border-b border-purple-100/50">
      <div className="flex items-center gap-3">
        <Icon className="w-5 h-5 text-[#3F2044]" />
        <h2 className="text-lg font-bold text-[#3F2044]">{title}</h2>
      </div>
    </div>
    <div className="p-5">{children}</div>
  </motion.div>
));

// New TodoItem component for the checklist
const TodoItem = ({ icon: Icon, title, description, onClick }) => (
  <motion.div
    layout
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -20 }}
    onClick={onClick}
    className="flex items-start gap-4 p-4 bg-purple-50 hover:bg-purple-100/70 rounded-2xl cursor-pointer border border-purple-200/80 transition-all duration-200"
  >
    <div className="bg-white p-3 rounded-full shadow-sm">
      <Icon className="w-5 h-5 text-[#7B3FA3]" />
    </div>
    <div>
      <h3 className="font-bold text-gray-800">{title}</h3>
      <p className="text-sm text-gray-600">{description}</p>
    </div>
  </motion.div>
);


export default function Profile() {
  const [user, setUser] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [editData, setEditData] = useState({});
  const [loading, setLoading] = useState(true);
  const [isUploadingPhoto, setIsUploadingPhoto] = useState(false);
  const [isVerificationModalOpen, setIsVerificationModalOpen] = useState(false);
  const [verificationStatus, setVerificationStatus] = useState('unverified'); // 'unverified', 'pending', 'verified'
  const [profileTodos, setProfileTodos] = useState([]);

  const { language } = useLanguage();

  const sectionsRef = {
    about: useRef(null),
    photos: useRef(null),
    basics: useRef(null),
    interests: useRef(null),
  };

  const scrollToSection = (id) => {
    // A small delay to allow the UI to enter edit mode before scrolling
    setTimeout(() => {
        sectionsRef[id]?.current?.scrollIntoView({
            behavior: 'smooth',
            block: 'center'
        });
    }, 100);
  };

  const getProfileTodos = (data) => {
    if (!data) return [];
    const todos = [];

    if (!data.photos || data.photos.length < 2) {
      todos.push({
        id: 'photos',
        icon: Camera,
        title: 'העלה לפחות 2 תמונות',
        description: 'פרופילים עם יותר תמונות מקבלים יותר תשומת לב.',
        action: () => { setIsEditing(true); scrollToSection('photos'); }
      });
    }

    if (!data.bio || data.bio.length < 40) {
      todos.push({
        id: 'about',
        icon: PenSquare,
        title: 'כתוב קצת על עצמך',
        description: 'ספר לאחרים מי אתה ומה הופך אותך למיוחד.',
        action: () => { setIsEditing(true); scrollToSection('about'); }
      });
    }

    if (!data.interests || data.interests.length < 3) {
      todos.push({
        id: 'interests',
        icon: Tag,
        title: 'הוסף 3 תחומי עניין',
        description: 'עזור לאלגוריתם שלנו למצוא לך התאמות טובות יותר.',
        action: () => { setIsEditing(true); scrollToSection('interests'); }
      });
    }

    if (!data.relationship_intent) {
        todos.push({
          id: 'basics',
          icon: HeartHandshake,
          title: 'מה הכוונות שלך?',
          description: 'ציין אם אתה מחפש קשר רציני, קליל או חברים.',
          action: () => { setIsEditing(true); scrollToSection('basics'); }
        });
    }

    if (!data.age || !data.location || !data.religion) {
        todos.push({
            id: 'basics_demographics',
            icon: PersonStanding,
            title: 'מלא פרטים בסיסיים',
            description: 'גיל, מיקום ודת עוזרים למצוא התאמות טובות יותר.',
            action: () => { setIsEditing(true); scrollToSection('basics'); }
        });
    }

    if (!data.generation_in_israel || !data.shabbat_observance || !data.kashrut_observance || !data.family_plans) {
        todos.push({
            id: 'basics_lifestyle',
            icon: Tag, // Reusing Tag icon for lifestyle for now, could be new if needed
            title: 'מלא פרטי אורח חיים',
            description: 'דור בארץ, שבת, כשרות ותוכניות משפחה משלימים את הפרופיל.',
            action: () => { setIsEditing(true); scrollToSection('basics'); }
        });
    }

    return todos;
  };

  const calculateProfileCompletion = (data) => {
    if (!data) return 0;
    let score = 0;
    if (data.photos?.length >= 2) score += 25;
    if (data.bio?.length >= 40) score += 20;
    if (data.age && data.location && data.religion) score += 15; // Added religion
    if (data.interests?.length >= 3) score += 15;
    if (data.relationship_intent) score += 10;
    if (data.generation_in_israel && data.shabbat_observance && data.kashrut_observance && data.family_plans) score += 15; // Added new fields
    // Max score possible from existing fields = 25+20+15+15+10+15 = 100
    // If future fields are added, ensure this doesn't exceed 100.
    return Math.min(score, 100);
  };

  const profileCompletion = useMemo(() => calculateProfileCompletion(isEditing ? editData : user), [user, editData, isEditing]);

  useEffect(() => {
    loadUserProfile();
  }, []);

  const loadUserProfile = async () => {
    setLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      setEditData({
        ...currentUser,
        religion: currentUser.religion || '',
        relationship_intent: currentUser.relationship_intent || '',
        generation_in_israel: currentUser.generation_in_israel || '',
        shabbat_observance: currentUser.shabbat_observance || '',
        kashrut_observance: currentUser.kashrut_observance || '',
        family_plans: currentUser.family_plans || '',
      });
      setProfileTodos(getProfileTodos(currentUser));

      // Check verification status
      if (currentUser.verified) {
        setVerificationStatus('verified');
      } else {
        try {
          const requests = await VerificationRequest.filter({ user_id: currentUser.id, status: 'pending' });
          if (requests.length > 0) {
            setVerificationStatus('pending');
          } else {
            setVerificationStatus('unverified');
          }
        } catch (e) {
          console.error("Could not check verification status", e);
          setVerificationStatus('unverified');
        }
      }

    } catch (error) {
      console.error('Error loading profile:', error);
    }
    setLoading(false);
  };

  const handleSave = async () => {
    // Simple validation
    if (!editData.bio || editData.bio.length < 20) {
      alert("נא לכתוב משהו על עצמך");
      return;
    }

    setLoading(true);
    try {
      // Update user data
      await User.updateMyUserData(editData);

      // Update public profile
      const publicProfileData = {
        user_id: user.id,
        chosen_name: editData.chosen_name || user.chosen_name,
        age: editData.age || 25,
        bio: editData.bio,
        photos: editData.photos || [],
        location: editData.location || '',
        interests: editData.interests || [],
        generation_in_israel: editData.generation_in_israel,
        religion: editData.religion,
        shabbat_observance: editData.shabbat_observance,
        kashrut_observance: editData.kashrut_observance,
        family_plans: editData.family_plans,
        last_active: new Date().toISOString(),
      };

      const existingProfiles = await PublicProfile.filter({ user_id: user.id });

      if (existingProfiles.length > 0) {
        await PublicProfile.update(existingProfiles[0].id, publicProfileData);
      } else {
        await PublicProfile.create(publicProfileData);
      }

      alert('נשמר! ✅');
      setIsEditing(false);
      loadUserProfile();

    } catch (error) {
      alert('שגיאה בשמירה, נסה שוב');
    }
    setLoading(false);
  };

  const handlePhotoUpload = async (e) => {
    const files = Array.from(e.target.files).slice(0, 6 - (editData.photos?.length || 0));
    if (files.length === 0) return;

    setIsUploadingPhoto(true);
    try {
      const uploadPromises = files.map(file => UploadFile({ file }));
      const uploads = await Promise.all(uploadPromises);
      const newPhotoUrls = uploads.map(upload => upload.file_url);

      setEditData(prev => ({
        ...prev,
        photos: [...(prev.photos || []), ...newPhotoUrls]
      }));
    } catch (error) {
      console.error('Error uploading photos:', error);
      alert('Error uploading photos');
    }
    setIsUploadingPhoto(false);
  };

  const removePhoto = (index) => {
    setEditData(prev => ({
      ...prev,
      photos: prev.photos?.filter((_, i) => i !== index) || []
    }));
  };

  const toggleInterest = (interest) => {
    setEditData(prev => ({
      ...prev,
      interests: (prev.interests?.includes(interest)
        ? prev.interests.filter(item => item !== interest)
        : [...(prev.interests || []), interest]
      ).slice(0, 8)
    }));
  };

  const interestOptions = ['מוזיקה', 'ספורט', 'אוכל', 'טיולים', 'קריאה', 'סרטים', 'טכנולוגיה', 'אמנות', 'בישול', 'טבע', 'משחקים', 'פוטוגרפיה'];

  if (loading && !user) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-[#F7F4FB] to-[#ECE3F5]">
        <Loader2 className="w-12 h-12 text-[#7B3FA3] animate-spin" />
      </div>
    );
  }

  const currentDisplayUser = isEditing ? editData : user;

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F7F4FB] to-[#ECE3F5] pb-32">
      <ProfileHeader user={currentDisplayUser} completion={profileCompletion} onEditClick={() => setIsEditing(!isEditing)} />

      <main className="p-4 space-y-4 -mt-10 relative z-10">

        {profileTodos.length > 0 && !isEditing && (
            <Section title="צעדים להשלמת הפרופיל" icon={ClipboardList}>
                <div className="space-y-3">
                    <AnimatePresence>
                        {profileTodos.map(todo => (
                            <TodoItem key={todo.id} {...todo} onClick={todo.action} />
                        ))}
                    </AnimatePresence>
                </div>
            </Section>
        )}

        <Section ref={sectionsRef.about} title="אודותיי" icon={PersonStanding}>
          {isEditing ? (
            <div className="space-y-2">
              <Textarea
                value={editData.bio || ''}
                onChange={(e) => setEditData(p => ({...p, bio: e.target.value}))}
                placeholder="כמה שורות שמרגישות כמוך."
                maxLength={280}
                className="min-h-[120px] rounded-2xl border-purple-200 focus:border-[#7B3FA3] focus:ring-[#7B3FA3]"
              />
              <p className="text-xs text-gray-500 text-right mt-1">{editData.bio?.length || 0} / 280</p>
            </div>
          ) : (
            <p className="text-gray-700 text-base leading-relaxed">{user.bio || 'ספר/י לאחרים מה הופך אותך...למי שאת/ה.'}</p>
          )}
        </Section>

        <Section ref={sectionsRef.photos} title="תמונות" icon={Camera}>
          <div className="grid grid-cols-3 gap-3">
            {(isEditing ? editData.photos : user.photos)?.map((photo, index) => (
              <div key={index} className="relative group aspect-square">
                <img src={photo} alt={`Photo ${index + 1}`} className="w-full h-full object-cover rounded-2xl" />
                {isEditing && (
                  <Button size="icon" variant="destructive" onClick={() => removePhoto(index)} className="absolute top-1.5 right-1.5 h-7 w-7 opacity-0 group-hover:opacity-100 rounded-full">
                    <X className="w-4 h-4" />
                  </Button>
                )}
              </div>
            ))}
            {isEditing && (editData.photos?.length || 0) < 6 && (
              <label htmlFor="photo-upload" className="cursor-pointer aspect-square border-2 border-dashed border-purple-300 rounded-2xl flex items-center justify-center bg-purple-50 hover:bg-purple-100">
                {isUploadingPhoto ? <Loader2 className="animate-spin text-purple-400" /> : <Camera className="w-8 h-8 text-purple-400" />}
                <input id="photo-upload" type="file" accept="image/*" multiple className="hidden" onChange={handlePhotoUpload} />
              </label>
            )}
          </div>
          {!isEditing && user.photos?.length < 3 && <p className="text-sm text-purple-700 mt-4 p-3 bg-purple-100/50 rounded-xl">פרופילים עם 3 תמונות לפחות מקבלים פי 2 יותר התאמות.</p>}
        </Section>

        <Section ref={sectionsRef.basics} title="מידע בסיסי" icon={HeartHandshake}>
          <div className="space-y-4">
            <div>
              <label className="font-semibold text-gray-700 text-sm">גיל</label>
              {isEditing ? <Input type="number" value={editData.age || ''} onChange={(e) => setEditData(p => ({...p, age: e.target.value}))} className="mt-1 rounded-xl"/> : <p className="text-gray-800 text-base">{user.age}</p>}
            </div>
            <div>
              <label className="font-semibold text-gray-700 text-sm">מיקום</label>
              {isEditing ? <Input value={editData.location || ''} onChange={(e) => setEditData(p => ({...p, location: e.target.value}))} className="mt-1 rounded-xl"/> : <p className="text-gray-800 text-base">{user.location}</p>}
            </div>
             <div>
              <label className="font-semibold text-gray-700 text-sm">דת ואמונה</label>
              {isEditing ? (
                <Select value={editData.religion || ''} onValueChange={(value) => setEditData(p => ({...p, religion: value}))}>
                  <SelectTrigger className="mt-1 rounded-xl"><SelectValue placeholder="בחר דת ואמונה" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="secular">חילוני</SelectItem>
                    <SelectItem value="traditional">מסורתי</SelectItem>
                    <SelectItem value="religious">דתי</SelectItem>
                    <SelectItem value="other">אחר</SelectItem>
                  </SelectContent>
                </Select>
              ) : (
                <p className="text-gray-800 text-base">
                  {user.religion === 'secular' ? 'חילוני' :
                   user.religion === 'traditional' ? 'מסורתי' :
                   user.religion === 'religious' ? 'דתי' :
                   user.religion === 'other' ? 'אחר' : user.religion}
                </p>
              )}
            </div>
            <div>
              <label className="font-semibold text-gray-700 text-sm">דור בארץ</label>
              {isEditing ? (
                <Select value={editData.generation_in_israel || ''} onValueChange={(value) => setEditData(p => ({...p, generation_in_israel: value}))}>
                  <SelectTrigger className="mt-1 rounded-xl"><SelectValue placeholder="בחר דור" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new_immigrant">עולה חדש/ה</SelectItem>
                    <SelectItem value="first_gen">דור ראשון בארץ</SelectItem>
                    <SelectItem value="second_gen">דור שני ומעלה</SelectItem>
                  </SelectContent>
                </Select>
              ) : (
                <p className="text-gray-800 text-base">
                  {user.generation_in_israel === 'new_immigrant' ? 'עולה חדש/ה' :
                   user.generation_in_israel === 'first_gen' ? 'דור ראשון בארץ' :
                   user.generation_in_israel === 'second_gen' ? 'דור שני ומעלה' :
                   user.generation_in_israel}
                </p>
              )}
            </div>
            <div>
              <label className="font-semibold text-gray-700 text-sm">שמירת שבת</label>
              {isEditing ? (
                <Select value={editData.shabbat_observance || ''} onValueChange={(value) => setEditData(p => ({...p, shabbat_observance: value}))}>
                  <SelectTrigger className="mt-1 rounded-xl"><SelectValue placeholder="בחר סטטוס" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="yes">כן</SelectItem>
                    <SelectItem value="no">לא</SelectItem>
                    <SelectItem value="partially">חלקית</SelectItem>
                  </SelectContent>
                </Select>
              ) : (
                 <p className="text-gray-800 text-base">
                  {user.shabbat_observance === 'yes' ? 'כן' :
                   user.shabbat_observance === 'no' ? 'לא' :
                   user.shabbat_observance === 'partially' ? 'חלקית' :
                   user.shabbat_observance}
                 </p>
              )}
            </div>
            <div>
              <label className="font-semibold text-gray-700 text-sm">כשרות</label>
              {isEditing ? (
                <Select value={editData.kashrut_observance || ''} onValueChange={(value) => setEditData(p => ({...p, kashrut_observance: value}))}>
                  <SelectTrigger className="mt-1 rounded-xl"><SelectValue placeholder="בחר סטטוס" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="yes">כן</SelectItem>
                    <SelectItem value="no">לא</SelectItem>
                  </SelectContent>
                </Select>
              ) : (
                 <p className="text-gray-800 text-base">
                  {user.kashrut_observance === 'yes' ? 'כן' :
                   user.kashrut_observance === 'no' ? 'לא' :
                   user.kashrut_observance}
                 </p>
              )}
            </div>
            <div>
              <label className="font-semibold text-gray-700 text-sm">תכנון משפחה</label>
              {isEditing ? (
                <Select value={editData.family_plans || ''} onValueChange={(value) => setEditData(p => ({...p, family_plans: value}))}>
                  <SelectTrigger className="mt-1 rounded-xl"><SelectValue placeholder="בחר סטטוס" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open_to_children">מעוניין/ת בילדים</SelectItem>
                    <SelectItem value="has_children_wants_more">יש ילדים ורוצה עוד</SelectItem>
                    <SelectItem value="has_children_no_more">יש ילדים ולא רוצה עוד</SelectItem>
                    <SelectItem value="no_children_no_plans">אין ילדים ולא מתכנן/ת</SelectItem>
                    <SelectItem value="not_relevant">לא רלוונטי</SelectItem>
                  </SelectContent>
                </Select>
              ) : (
                <p className="text-gray-800 text-base">
                  {user.family_plans === 'open_to_children' ? 'מעוניין/ת בילדים' :
                   user.family_plans === 'has_children_wants_more' ? 'יש ילדים ורוצה עוד' :
                   user.family_plans === 'has_children_no_more' ? 'יש ילדים ולא רוצה עוד' :
                   user.family_plans === 'no_children_no_plans' ? 'אין ילדים ולא מתכנן/ת' :
                   user.family_plans === 'not_relevant' ? 'לא רלוונטי' :
                   user.family_plans}
                </p>
              )}
            </div>
             <div>
              <label className="font-semibold text-gray-700 text-sm">מה מחפש/ת</label>
              {isEditing ? (
                <Select value={editData.relationship_intent || ''} onValueChange={(value) => setEditData(p => ({...p, relationship_intent: value}))}>
                  <SelectTrigger className="mt-1 rounded-xl"><SelectValue placeholder="בחר כוונה" /></SelectTrigger>
                  <SelectContent><SelectItem value="Serious">קשר רציני</SelectItem><SelectItem value="Casual">קשר קליל</SelectItem><SelectItem value="New Friends">חברים חדשים</SelectItem></SelectContent>
                </Select>
              ) : <p className="text-gray-800 text-base">{user.relationship_intent}</p>}
            </div>
          </div>
        </Section>

        <Section ref={sectionsRef.interests} title="תחומי עניין" icon={Tag}>
           <div className="flex flex-wrap gap-2">
            {(isEditing ? editData.interests : user.interests)?.map((interest) => (
              <div key={interest} className="bg-purple-100 text-purple-800 px-3 py-1.5 rounded-full text-sm font-medium flex items-center gap-2">
                {interest}
                {isEditing && <button onClick={() => toggleInterest(interest)}><X className="w-3 h-3" /></button>}
              </div>
            ))}
             {isEditing && (
                <div className="w-full mt-4">
                    <h4 className="font-semibold text-sm mb-2 text-gray-600">הוסף תחומי עניין (עד 8):</h4>
                    <div className="flex flex-wrap gap-2">
                        {interestOptions.filter(opt => !editData.interests?.includes(opt)).map(opt => (
                            <button key={opt} onClick={() => toggleInterest(opt)} className="bg-gray-200 hover:bg-gray-300 text-gray-800 px-3 py-1.5 rounded-full text-sm font-medium">
                                + {opt}
                            </button>
                        ))}
                    </div>
                </div>
             )}
          </div>
        </Section>

        <Section title="אמון ובטיחות" icon={ShieldCheck}>
           <p className="text-sm text-gray-600 mb-4">הפגן אמינות וקבל יותר חשיפה עם פרופיל מאומת.</p>
           {verificationStatus === 'verified' && (
             <Button variant="ghost" disabled className="w-full bg-green-50 text-green-700 hover:bg-green-50 border-green-200 rounded-xl cursor-not-allowed">
               <CheckCheck className="w-4 h-4 ml-2" />
               פרופיל מאומת
             </Button>
           )}
           {verificationStatus === 'pending' && (
             <Button variant="ghost" disabled className="w-full bg-yellow-50 text-yellow-700 hover:bg-yellow-50 border-yellow-200 rounded-xl cursor-not-allowed">
               <Loader2 className="w-4 h-4 ml-2 animate-spin" />
               אימות בבדיקה
             </Button>
           )}
           {verificationStatus === 'unverified' && (
              <Button variant="outline" onClick={() => setIsVerificationModalOpen(true)} className="w-full border-[#7B3FA3] text-[#7B3FA3] hover:bg-purple-50 rounded-xl">
                <CheckCheck className="w-4 h-4 ml-2" />
                אמת את הפרופיל שלך
              </Button>
           )}
        </Section>
      </main>

      {isEditing && (
        <div
          className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 p-4 z-[100] shadow-lg"
          style={{ paddingBottom: 'calc(1rem + env(safe-area-inset-bottom))' }}
        >
           <div className="max-w-md mx-auto flex gap-4">
             <Button
               onClick={() => {
                 setIsEditing(false);
                 loadUserProfile();
               }}
               variant="outline"
               className="flex-1 text-[#3F2044] border-[#7B3FA3] rounded-2xl h-12 text-base font-semibold"
             >
                ביטול
              </Button>
              <Button
                onClick={async () => {
                  await handleSave();
                }}
                className="flex-1 bg-[#7B3FA3] hover:bg-[#7B3FA3]/90 text-white rounded-2xl h-12 text-base font-semibold shadow-lg active:scale-95 transition-all duration-200"
                disabled={loading}
              >
                {loading ? (
                  <div className="flex items-center gap-2">
                    <Loader2 className="animate-spin w-5 h-5" />
                    <span>שומר...</span>
                  </div>
                ) : (
                  'שמור שינויים'
                )}
              </Button>
           </div>
        </div>
      )}

      <VerificationModal
        isOpen={isVerificationModalOpen}
        onClose={() => setIsVerificationModalOpen(false)}
        onVerificationRequested={() => {
          setIsVerificationModalOpen(false);
          setVerificationStatus('pending');
        }}
      />
    </div>
  );
}
