
import React, { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { motion, AnimatePresence } from 'framer-motion';
import { User } from '@/api/entities';
import { PublicProfile } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Camera, ChevronLeft, Plus, X, Loader2 } from 'lucide-react';
import { useLanguage } from '../components/language/LanguageContext';
import { t } from '../components/language/translations'; // Assuming 't' function handles translations

// Helper component for photo upload with proper permission handling
const PhotoUploadWithPermission = ({ onFilesSelected, maxPhotos = 1 }) => {
  const fileInputRef = useRef(null);
  const { language } = useLanguage();
  const [showPermissionDialog, setShowPermissionDialog] = useState(false);

  const handleFileChange = async (event) => {
    const selectedFiles = Array.from(event.target.files);
    const filesToProcess = selectedFiles.slice(0, maxPhotos);

    if (filesToProcess.length > 0) {
      onFilesSelected(filesToProcess);
    }
    // Clear the input value so that selecting the same file again triggers onChange
    event.target.value = '';
  };

  const handleClick = () => {
    // Show permission explanation before opening file picker
    setShowPermissionDialog(true);
  };

  const handlePermissionAccepted = () => {
    setShowPermissionDialog(false);
    fileInputRef.current.click();
  };

  return (
    <>
      <input
        type="file"
        multiple={maxPhotos > 1}
        accept="image/*"
        ref={fileInputRef}
        onChange={handleFileChange}
        className="hidden"
      />
      <Button
        onClick={handleClick}
        className="w-full bg-purple-500 hover:bg-purple-600 text-white font-semibold py-2 px-4 rounded-xl text-base"
      >
        {language === 'he' ? 'בחר תמונות' : 'ምስሎች ምረጥ'}
      </Button>
      
      {/* Permission Dialog */}
      {showPermissionDialog && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl p-6 max-w-sm w-full" dir={language === 'he' ? 'rtl' : 'ltr'}>
            <h3 className="text-lg font-bold mb-3">
              {language === 'he' ? 'גישה לגלריה' : 'የማዕከል መዳረሻ'}
            </h3>
            <p className="text-gray-600 mb-4">
              {language === 'he' 
                ? 'RootsMatch זקוק לגישה לגלריה שלך כדי להעלות תמונות פרופיל. התמונות יישמרו בצורה מאובטחת וישמשו רק להצגת הפרופיל שלך.'
                : 'RootsMatch የእርስዎን የማዕከል መዳረሻ የመገለጫ ፎቶዎችን ለመስቀል ይፈልጋል። ፎቶዎች በአስተማማኝ ሁኔታ ይቀመጣሉ እና ለመገለጫዎ ብቻ ያገለግላሉ።'
              }
            </p>
            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowPermissionDialog(false)}
                className="flex-1"
              >
                {language === 'he' ? 'ביטול' : 'ይቅር'}
              </Button>
              <Button
                onClick={handlePermissionAccepted}
                className="flex-1 bg-purple-600 hover:bg-purple-700"
              >
                {language === 'he' ? 'אישור' : 'ፍቀድ'}
              </Button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};


// New helper component for consistent step layout
const OnboardingStepLayout = ({ title, subtitle, children }) => {
  return (
    <motion.div key={title} initial={{ opacity: 0, x: 50 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -50 }} transition={{ duration: 0.3 }} className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900 mb-2">{title}</h2>
        <p className="text-gray-600">{subtitle}</p>
      </div>
      {children}
    </motion.div>
  );
};

// New helper component for consistent option buttons
const OptionButton = ({ onClick, selected, children }) => {
  return (
    <Button
      variant={selected ? "default" : "outline"}
      onClick={onClick}
      className={`w-full justify-start h-auto py-3 px-4 text-base rounded-xl ${selected ? 'bg-purple-600 text-white' : 'text-gray-900 border-gray-300 hover:bg-gray-100'}`}
    >
      {children}
    </Button>
  );
};

// New helper component for Input with a label
const LabeledInput = ({ label, ...props }) => {
  // language is not directly used here, but could be passed if needed for label text direction etc.
  return (
    <div>
      {label && <label className="block text-lg font-bold mb-2 text-gray-900">{label}</label>}
      <Input {...props} className="text-lg py-4 border-2 border-purple-200 rounded-xl focus:border-purple-500" />
    </div>
  );
};


// Step components (extracted from original render functions)
const NameAgeStep = ({ data, onUpdate, t, language }) => (
  <OnboardingStepLayout title={t('onboarding_name_age_title', language)} subtitle={t('onboarding_name_age_subtitle', language)}>
    <div className="text-6xl mb-4 text-center">👋</div>
    <Input
      name="chosen_name"
      placeholder={t('onboarding_name_placeholder', language)}
      value={data.chosen_name}
      onChange={(e) => onUpdate('chosen_name', e.target.value)}
      className="text-lg py-4 border-2 border-purple-200 rounded-xl focus:border-purple-500 text-center"
    />
    <Input
      name="age"
      type="number"
      placeholder={t('onboarding_age_placeholder', language)}
      value={data.age}
      onChange={(e) => onUpdate('age', e.target.value)}
      className="text-lg py-4 border-2 border-purple-200 rounded-xl focus:border-purple-500 text-center"
    />
  </OnboardingStepLayout>
);

const BioStep = ({ data, onUpdate, t, language }) => (
  <OnboardingStepLayout title={t('onboarding_bio_title', language)} subtitle={t('onboarding_bio_subtitle', language)}>
    <div className="text-6xl mb-4 text-center">📝</div>
    <Textarea
      name="bio"
      placeholder={t('onboarding_bio_placeholder', language)}
      value={data.bio}
      onChange={(e) => onUpdate('bio', e.target.value)}
      rows={5}
      className="text-lg py-4 border-2 border-purple-200 rounded-xl focus:border-purple-500 resize-none"
    />
    <p className="text-sm text-gray-500 text-right">
      {data.bio.length} {t('onboarding_bio_char_count', language)}
    </p>
  </OnboardingStepLayout>
);

const PhotosStep = ({ data, handlePhotosSelected, removePhoto, t, language }) => (
  <OnboardingStepLayout title={t('onboarding_photos_title', language)} subtitle={t('onboarding_photos_subtitle', language)}>
    <div className="text-6xl mb-4 text-center">📸</div>
    {/* Photo Upload Grid */}
    <div className="grid grid-cols-2 gap-4">
      {/* Main Photo (slot 0) */}
      <div className="col-span-2 aspect-[4/5] relative">
        {data.photos.length > 0 ? (
          <div className="relative w-full h-full">
            <img 
              src={data.photos[0]} 
              alt="Main photo"
              className="w-full h-full object-cover rounded-2xl"
            />
            <button
              onClick={() => removePhoto(0)}
              className="absolute top-2 right-2 w-8 h-8 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        ) : (
          <div className="w-full h-full border-2 border-dashed border-purple-300 rounded-2xl flex flex-col items-center justify-center bg-purple-50 hover:bg-purple-100 transition-colors">
            <Camera className="w-16 h-16 text-purple-400 mb-4" />
            <p className="text-purple-600 font-medium text-lg mb-2">
              {t('onboarding_photos_main', language)}
            </p>
            <div className="space-y-2 w-full px-4">
              <PhotoUploadWithPermission
                onFilesSelected={handlePhotosSelected}
                maxPhotos={6 - data.photos.length}
              />
            </div>
          </div>
        )}
      </div>
      
      {/* Additional Photos (slots 1-5) */}
      {Array.from({length: 5}, (_, i) => (
        <div key={i + 1} className="aspect-square relative">
          {data.photos[i + 1] ? (
            <div className="relative w-full h-full">
              <img 
                src={data.photos[i + 1]} 
                alt={`Photo ${i + 2}`}
                className="w-full h-full object-cover rounded-2xl"
              />
              <button
                onClick={() => removePhoto(i + 1)}
                className="absolute top-1 right-1 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center hover:bg-red-600"
              >
                <X className="w-3 h-3" />
              </button>
            </div>
          ) : (
            <div className="w-full h-full border-2 border-dashed border-gray-300 rounded-2xl flex items-center justify-center bg-gray-50 hover:bg-gray-100 transition-colors">
              <div className="text-center">
                <Plus className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <PhotoUploadWithPermission
                  onFilesSelected={handlePhotosSelected}
                  maxPhotos={1}
                />
              </div>
            </div>
          )}
        </div>
      ))}
    </div>
    
    <div className="text-center p-4 bg-yellow-50 rounded-2xl border border-yellow-200">
      <p className="text-yellow-800 text-sm">
        {t('onboarding_photos_tip', language)}
      </p>
    </div>
  </OnboardingStepLayout>
);

const InterestsStep = ({ data, toggleInterest, t, language }) => {
  const allInterests = [
    { value: 'music', labelKey: 'interest_music' },
    { value: 'sports', labelKey: 'interest_sports' },
    { value: 'food', labelKey: 'interest_food' },
    { value: 'travel', labelKey: 'interest_travel' },
    { value: 'reading', labelKey: 'interest_reading' },
    { value: 'movies', labelKey: 'interest_movies' },
    { value: 'tech', labelKey: 'interest_tech' },
    { value: 'art', labelKey: 'interest_art' },
    { value: 'cooking', labelKey: 'interest_cooking' },
    { value: 'nature', labelKey: 'interest_nature' },
    { value: 'gaming', labelKey: 'interest_gaming' },
    { value: 'photography', labelKey: 'interest_photography' },
  ];

  return (
    <OnboardingStepLayout title={t('onboarding_interests_title', language)} subtitle={t('onboarding_interests_subtitle', language)}>
      <div className="text-6xl mb-4 text-center">🎨</div>
      <div className="flex flex-wrap gap-3 justify-center">
        {allInterests.map(interest => (
          <Button
            key={interest.value}
            variant={data.interests.includes(interest.value) ? "default" : "outline"}
            onClick={() => toggleInterest(interest.value)}
            className={`h-auto py-2 px-4 rounded-full text-base ${data.interests.includes(interest.value) ? 'bg-purple-600 text-white' : 'border-gray-300 text-gray-900 hover:bg-gray-100'}`}
          >
            {t(interest.labelKey, language)}
          </Button>
        ))}
      </div>
      <p className="text-sm text-gray-500 text-center">
        {language === 'he' 
          ? `בחרת ${data.interests.length} מתוך 3 נדרשים`
          : `${data.interests.length} of 3 required selected` // Assuming Amharic translation for now.
        }
      </p>
    </OnboardingStepLayout>
  );
};

const FamilyStep = ({ data, onUpdate, t, language }) => (
  <OnboardingStepLayout title={t('onboarding_family_title', language)} subtitle={t('onboarding_family_subtitle', language)}>
    <div className="text-6xl mb-4 text-center">👨‍👩‍👧‍👦</div>
    <div className="space-y-6">
      <LabeledInput label={t('onboarding_family_father', language)} value={data.family_father_name || ''} onChange={(e) => onUpdate('family_father_name', e.target.value)} />
      <LabeledInput label={t('onboarding_family_mother', language)} value={data.family_mother_name || ''} onChange={(e) => onUpdate('family_mother_name', e.target.value)} />
      <LabeledInput label={t('onboarding_family_grandparent', language)} value={data.family_grandparent_name || ''} onChange={(e) => onUpdate('family_grandparent_name', e.target.value)} />
      
      <div>
        <h3 className="text-xl font-bold mb-4">{t('onboarding_family_generation', language)}</h3>
        <div className="space-y-3">
          {[
            { key: 'new_immigrant', label: t('onboarding_gen_new', language) },
            { key: 'first_gen', label: t('onboarding_gen_first', language) },
            { key: 'second_gen', label: 'דור שני בישראל' } // Assuming this should be Hebrew literal as per outline
          ].map(option => (
            <OptionButton key={option.key} onClick={() => onUpdate('generation_in_israel', option.key)} selected={data.generation_in_israel === option.key}>
              {option.label}
            </OptionButton>
          ))}
        </div>
      </div>
    </div>
  </OnboardingStepLayout>
);

const ReligionFamilyStep = ({ data, onUpdate, t, language }) => (
  <OnboardingStepLayout title={t('onboarding_religion_title', language)} subtitle={t('onboarding_religion_subtitle', language)}>
    <div className="text-6xl mb-4 text-center">🙏</div>
    <div className="space-y-8">
      {/* Religion */}
      <div>
          <h3 className="text-xl font-bold mb-4">{t('onboarding_religion_faith', language)}</h3>
          <div className="space-y-3">
              {[
                  { value: 'secular', labelKey: 'onboarding_faith_secular' },
                  { value: 'traditional', labelKey: 'onboarding_faith_traditional' },
                  { value: 'religious', labelKey: 'onboarding_faith_religious' },
                  { value: 'other', labelKey: 'onboarding_faith_other' }
              ].map(option => (
                  <OptionButton key={option.value} onClick={() => onUpdate('religion', option.value)} selected={data.religion === option.value}>
                      {t(option.labelKey, language)}
                  </OptionButton>
              ))}
          </div>
      </div>
      {/* Shabbat Observance */}
      <div>
          <h3 className="text-xl font-bold mb-4">{t('onboarding_religion_shabbat', language)}</h3>
          <div className="space-y-3">
              {[
                  { value: 'yes', labelKey: 'yes' }, { value: 'no', labelKey: 'no' }, { value: 'partially', labelKey: 'partially' }
              ].map(option => (
                  <OptionButton key={option.value} onClick={() => onUpdate('shabbat_observance', option.value)} selected={data.shabbat_observance === option.value}>
                      {t(option.labelKey, language)}
                  </OptionButton>
              ))}
          </div>
      </div>
      {/* Kashrut Observance */}
      <div>
          <h3 className="text-xl font-bold mb-4">{t('onboarding_religion_kashrut', language)}</h3>
          <div className="space-y-3">
              {[
                  { value: 'yes', labelKey: 'yes' }, { value: 'no', labelKey: 'no' }
              ].map(option => (
                  <OptionButton key={option.value} onClick={() => onUpdate('kashrut_observance', option.value)} selected={data.kashrut_observance === option.value}>
                      {t(option.labelKey, language)}
                  </OptionButton>
              ))}
          </div>
      </div>
      
      {/* Family Plans */}
      <div>
        <h3 className="text-xl font-bold mb-4">תכנון משפחה</h3>
        <div className="space-y-3">
          {[
            { key: 'open_to_children', label: 'מעוניין/ת בילדים' },
            { key: 'has_children_wants_more', label: 'יש ילדים ורוצה עוד' },
            { key: 'has_children_no_more', label: 'יש ילדים ולא רוצה עוד' },
            { key: 'no_children_no_plans', label: 'אין ילדים ולא מתכנן/ת' },
            { key: 'not_relevant', label: 'לא רלוונטי כרגע' }
          ].map(option => (
            <OptionButton key={option.key} onClick={() => onUpdate('family_plans', option.key)} selected={data.family_plans === option.key}>
              {option.label}
            </OptionButton>
          ))}
        </div>
      </div>
    </div>
  </OnboardingStepLayout>
);


export default function Onboarding() {
  const navigate = useNavigate();
  const { language } = useLanguage();
  const [step, setStep] = useState(1);
  const totalSteps = 6;
  const [userData, setUserData] = useState({
    chosen_name: '',
    age: '', // Age is now a direct input
    bio: '',
    photos: [], // Array of photo URLs (for display)
    interests: [], // Array of strings
    
    // New personal questions
    family_father_name: '',
    family_mother_name: '',
    family_grandparent_name: '',
    generation_in_israel: '', // e.g., 'new_immigrant', 'first_gen', 'second_gen'
    religion: '', // e.g., 'secular', 'traditional', 'religious', 'other'
    shabbat_observance: '', // e.g., 'yes', 'no', 'partially'
    kashrut_observance: '', // e.g., 'yes', 'no'
    family_plans: '', // e.g., 'yes', 'not_now', 'maybe' -- NOW has new options.
  });
  const [photoFiles, setPhotoFiles] = useState([]); // Array of actual File objects for upload
  const [isUploading, setIsUploading] = useState(false); // General loading for final submission

  // Modified handleInputChange to pass directly to handleSelect
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    handleSelect(name, value);
  };

  // Generic handler for updating state by field name
  const handleSelect = (field, value) => {
    setUserData(prev => ({ ...prev, [field]: value }));
  };

  const toggleInterest = (interest) => {
    setUserData(prev => ({
      ...prev,
      interests: prev.interests.includes(interest)
        ? prev.interests.filter(item => item !== interest)
        : [...prev.interests, interest]
    }));
  };

  // New handler for files received from PhotoUploadWithPermission component
  const handlePhotosSelected = (files) => {
    // Determine how many slots are remaining, up to a total of 6 photos
    const currentPhotoCount = photoFiles.length;
    const remainingSlots = 6 - currentPhotoCount;
    const filesToProcess = files.slice(0, remainingSlots);

    if (filesToProcess.length === 0) return;
    
    // Store actual File objects for upload later
    setPhotoFiles(prev => [...prev, ...filesToProcess]);

    // Create immediate previews for the UI
    const newPhotoPreviews = filesToProcess.map(file => URL.createObjectURL(file));
    setUserData(prev => ({ 
      ...prev, 
      photos: [...prev.photos, ...newPhotoPreviews]
    }));
  };
  
  const removePhoto = (index) => {
    // Revoke object URL to free up memory
    if (userData.photos[index]) {
      URL.revokeObjectURL(userData.photos[index]);
    }

    // Remove from both the file list and the preview list
    const newPhotoFiles = photoFiles.filter((_, i) => i !== index);
    const newPhotoPreviews = userData.photos.filter((_, i) => i !== index);
    setPhotoFiles(newPhotoFiles);
    setUserData(prev => ({ ...prev, photos: newPhotoPreviews }));
  };
  
  const isStepComplete = () => {
    switch (step) {
        case 1: 
            const ageNum = parseInt(userData.age, 10);
            return userData.chosen_name && userData.chosen_name.length > 0 && 
                   userData.age && !isNaN(ageNum) && ageNum >= 18; // Age must be a number and at least 18
        case 2: return userData.bio && userData.bio.length >= 20; // Bio needs to be more descriptive
        case 3: return userData.photos.length >= 2;
        case 4: return userData.interests.length >= 3;
        case 5:
            return userData.family_father_name.length > 0 && 
                   userData.family_mother_name.length > 0 && 
                   userData.family_grandparent_name.length > 0 && 
                   userData.generation_in_israel.length > 0;
        case 6:
            return userData.religion.length > 0 && 
                   userData.shabbat_observance.length > 0 && 
                   userData.kashrut_observance.length > 0 && 
                   userData.family_plans.length > 0;
        default: return false;
    }
  };

  const handleContinue = async () => {
    if (!isStepComplete()) {
      // Show Hebrew error message instead of generic key
      const errorMessages = {
        1: 'נא למלא את השם והגיל',
        2: 'נא לכתוב לפחות 20 תווים על עצמך',
        3: 'נא להעלות לפחות 2 תמונות',
        4: 'נא לבחור לפחות 3 תחומי עניין',
        5: 'נא למלא את כל הפרטים המשפחתיים',
        6: 'נא למלא את כל הפרטים הדתיים ותכנון המשפחה'
      };
      alert(errorMessages[step] || 'נא להשלים את כל השדות');
      return;
    }

    if (step < totalSteps) {
      setStep(prev => prev + 1);
    } else {
      // Final step, process and save
      setIsUploading(true);
      try {
        // Upload actual File objects
        const uploadPromises = photoFiles.map(file => UploadFile({ file }));
        const uploadedPhotos = await Promise.all(uploadPromises);
        const photoUrls = uploadedPhotos.map(res => res.file_url);

        // Revoke all created object URLs to free up memory
        userData.photos.forEach(url => URL.revokeObjectURL(url));

        // Combine new userData with necessary default profile fields
        const finalUserData = { 
            // Core onboarding fields
            chosen_name: userData.chosen_name,
            full_name: userData.chosen_name, // Assuming full_name is same as chosen_name for now
            age: parseInt(userData.age, 10), // Ensure age is stored as a number
            bio: userData.bio,
            photos: photoUrls, // Use uploaded URLs
            interests: userData.interests,

            // New personal questions
            family_father_name: userData.family_father_name,
            family_mother_name: userData.family_mother_name,
            family_grandparent_name: userData.family_grandparent_name,
            generation_in_israel: userData.generation_in_israel,
            religion: userData.religion,
            shabbat_observance: userData.shabbat_observance,
            kashrut_observance: userData.kashrut_observance,
            family_plans: userData.family_plans,

            // Preserve other existing default fields from original Onboarding logic
            gender: 'male', // Default, or add a step for this if needed later
            interested_in: 'female', // Default, or add a step for this if needed later
            // Removed birth_date as age is direct input
            
            // Cultural preferences (all set to true by default for better matching)
            cultural_preferences: {
              traditional_food: true,
              ethiopian_music: true,
              cultural_events: true,
              language_amharic: true,
              religious_practices: true
            },
            
            // Relationship goals
            relationship_goals: 'serious', // Default to serious relationship
            
            // Premium and benefits
            is_premium: false,
            premium_expires_at: null,
            super_likes_remaining: 3, // Start with 3 super likes
            boosts_remaining: 0,
            benefits_last_reset_at: new Date().toISOString(),
            boost_active_until: null,
            
            // Discovery preferences
            distance_preference: 25,
            age_preference_min: 18,
            age_preference_max: 61,
            
            // Privacy settings (default to visible/discoverable)
            show_age: true,
            show_distance: true,
            discovery_enabled: true, // Ensure this is set to true for user data
            
            // Notifications (all enabled by default)
            notifications_matches: true,
            notifications_messages: true,
            notifications_likes: true,
            
            // Location (will be filled later in LocationPermission or automatically)
            location: '', // Placeholder, expected to be filled later
            latitude: null,
            longitude: null,
            
            // Status
            last_active: new Date().toISOString(),
            verified: false,
            onboarding_completed: true // Mark onboarding as completed
        };
        
        await User.updateMyUserData(finalUserData);

        // --- Create/Update PublicProfile ---
        const currentUser = await User.me(); 
        const currentUserId = currentUser.id;

        const publicProfileData = {
          user_id: currentUserId,
          chosen_name: finalUserData.chosen_name,
          age: finalUserData.age,
          bio: finalUserData.bio,
          photos: finalUserData.photos,
          location: finalUserData.location, // Will likely be updated later by LocationPermission
          interests: finalUserData.interests,
          latitude: finalUserData.latitude,
          longitude: finalUserData.longitude,
          generation_in_israel: finalUserData.generation_in_israel,
          religion: finalUserData.religion,
          shabbat_observance: finalUserData.shabbat_observance,
          kashrut_observance: finalUserData.kashrut_observance,
          family_plans: finalUserData.family_plans,
          verified: false, // Default as per outline
          is_premium: false, // Default as per outline
          last_active: new Date().toISOString(), // Default as per outline
          likes_received: 0,
          super_likes_received: 0,
        };

        // Check if a PublicProfile already exists for this user and update, otherwise create
        const existingProfiles = await PublicProfile.filter({ user_id: currentUserId });
        if (existingProfiles.length > 0) {
          await PublicProfile.update(existingProfiles[0].id, publicProfileData);
        } else {
          await PublicProfile.create(publicProfileData);
        }
        // --- End PublicProfile implementation ---

        navigate(createPageUrl('Discover'), { replace: true }); // Navigate to Discover after full onboarding
      } catch (error) {
        console.error("Failed to complete onboarding:", error);
        alert('שגיאה בשמירה. אנא נסה שוב.');
      } finally {
        setIsUploading(false);
      }
    }
  };

  // Removed renderOptionButtons as OptionButton component handles this
  // Removed stepAnimation as it's now embedded in OnboardingStepLayout

  // --- Step Content Render Functions --- (now use components)

  const renderStepContent = () => {
    switch(step) {
        case 1: return <NameAgeStep data={userData} onUpdate={handleSelect} t={t} language={language} />;
        case 2: return <BioStep data={userData} onUpdate={handleSelect} t={t} language={language} />;
        case 3: return <PhotosStep data={userData} handlePhotosSelected={handlePhotosSelected} removePhoto={removePhoto} t={t} language={language} />;
        case 4: return <InterestsStep data={userData} toggleInterest={toggleInterest} t={t} language={language} />;
        case 5: return <FamilyStep data={userData} onUpdate={handleSelect} t={t} language={language} />;
        case 6: return <ReligionFamilyStep data={userData} onUpdate={handleSelect} t={t} language={language} />;
        default: return null;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-4 flex flex-col" dir={language === 'he' ? 'rtl' : 'ltr'}>
      {/* Header */}
      <header className="flex items-center gap-4 py-4">
        {step > 1 && (
          <Button variant="ghost" size="icon" onClick={() => setStep(s => s - 1)} className="text-gray-700">
            <ChevronLeft className="w-6 h-6" />
          </Button>
        )}
        <Progress value={(step / totalSteps) * 100} className="w-full bg-purple-200 h-2 rounded-full" indicatorClassName="bg-gradient-to-r from-purple-500 to-pink-500" />
      </header>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col justify-center py-8 overflow-auto">
        <AnimatePresence mode="wait">
          {renderStepContent()}
        </AnimatePresence>
      </main>

      {/* Footer / Continue Button */}
      <footer className="mt-auto py-4">
        <Button
          onClick={handleContinue}
          disabled={!isStepComplete() || isUploading}
          className="w-full px-8 py-4 text-lg font-semibold bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white rounded-full shadow-xl disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 flex items-center justify-center"
        >
          {isUploading ? (
            <Loader2 className="w-6 h-6 animate-spin" />
          ) : (
            <>
              {step === totalSteps ? t('onboarding_finish', language) : t('continue', language)}
              <ChevronLeft className={`w-5 h-5 ml-2 transform ${language === 'he' ? 'rotate-180' : ''}`} />
            </>
          )}
        </Button>
      </footer>
    </div>
  );
}
