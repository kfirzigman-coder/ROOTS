

import React, { useState, useEffect, useMemo } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { User as UserIcon, Settings, Crown, Shield, Loader2, Compass, MessageCircle, Flame, Heart } from "lucide-react";
import { LanguageProvider, useLanguage } from "./components/language/LanguageContext";
import { t } from "./components/language/translations";
import { User } from "@/api/entities";
import PWAManager from "./components/pwa/PWAManager";
import PWAInstaller from "./components/pwa/PWAInstaller";

const FullScreenLoader = () => (
  <div className="fixed inset-0 bg-purple-50 flex flex-col items-center justify-center z-[100]">
    <img
      src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/fd93b36f7_WhatsAppImage2025-07-14at012021.jpeg"
      alt="RootsMatch Logo"
      className="w-24 h-24 object-contain mb-6 animate-pulse"
    />
    <div className="flex items-center gap-2">
      <Loader2 className="w-5 h-5 text-purple-600 animate-spin" />
      <p className="text-purple-700">טוען...</p>
    </div>
  </div>
);

const LayoutContent = ({ children, currentPageName }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { language } = useLanguage();
  const [currentUser, setCurrentUser] = useState(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const manifestContent = {
      "name": "RootsMatch - התחברות שורשית",
      "short_name": "RootsMatch",
      "description": "אפליקציית היכרויות לקהילה האתיופית בישראל",
      "start_url": "/",
      "display": "standalone",
      "background_color": "#F5F1FE",
      "theme_color": "#8B5CF6",
      "orientation": "portrait-primary",
      "categories": ["social", "lifestyle"],
      "lang": "he",
      "dir": "rtl",
      "icons": [
        {
          "src": "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/fd93b36f7_WhatsAppImage2025-07-14at012021.jpeg",
          "sizes": "192x192",
          "type": "image/jpeg",
          "purpose": "any maskable"
        },
        {
          "src": "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/fd93b36f7_WhatsAppImage2025-07-14at012021.jpeg",
          "sizes": "512x512",
          "type": "image/jpeg",
          "purpose": "any maskable"
        }
      ]
    };

    const manifestBlob = new Blob([JSON.stringify(manifestContent)], {type: 'application/json'});
    const manifestURL = URL.createObjectURL(manifestBlob);

    const manifestLink = document.createElement('link');
    manifestLink.rel = 'manifest';
    manifestLink.href = manifestURL;
    document.head.appendChild(manifestLink);

    // --- AdSense Script Start (More Robust) ---
    // Add the script only if it doesn't already exist
    if (!document.getElementById('adsense-script')) {
        const adsenseScript = document.createElement('script');
        adsenseScript.id = 'adsense-script';
        adsenseScript.async = true;
        adsenseScript.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-8776953620649627";
        adsenseScript.crossOrigin = "anonymous";
        document.head.appendChild(adsenseScript);
    }
    // --- AdSense Script End ---

    const themeColorMeta = document.createElement('meta');
    themeColorMeta.name = 'theme-color';
    themeColorMeta.content = '#8B5CF6';
    document.head.appendChild(themeColorMeta);

    const appleMobileWebAppCapable = document.createElement('meta');
    appleMobileWebAppCapable.name = 'apple-mobile-web-app-capable';
    appleMobileWebAppCapable.content = 'yes';
    document.head.appendChild(appleMobileWebAppCapable);

    const appleMobileWebAppStatusBar = document.createElement('meta');
    appleMobileWebAppStatusBar.name = 'apple-mobile-web-app-status-bar-style';
    appleMobileWebAppStatusBar.content = 'default';
    document.head.appendChild(appleMobileWebAppStatusBar);

    const appleMobileWebAppTitle = document.createElement('meta');
    appleMobileWebAppTitle.name = 'apple-mobile-web-app-title';
    appleMobileWebAppTitle.content = 'RootsMatch';
    document.head.appendChild(appleMobileWebAppTitle);
    
    // REMOVED faulty Service Worker registration code
    
    return () => {
      URL.revokeObjectURL(manifestURL);
      // The AdSense script is intentionally not removed on unmount.
    };
  }, []);

  const protectedPages = useMemo(() => [
    'Discover', 'Matches', 'Profile', 'Settings', 'Premium', 'Payment',
    'AdminDashboard', 'AdminUserManagement', 'AdminSettings', 'Chat'
  ], []);
  const publicOnlyPages = ['AdminLogin'];
  
  const fullScreenPages = [
    ...publicOnlyPages, 'Onboarding', 'LocationPermission',
    'Payment', 'Welcome', 'Terms', 'Help', 'Chat'
  ];

  // FIX: Simplified and corrected header/footer visibility logic
  const shouldHideHeader = ['Discover', 'Premium', ...fullScreenPages].includes(currentPageName);
  const shouldShowBottomNav = !fullScreenPages.includes(currentPageName);


  useEffect(() => {
    const processAuth = async () => {
      if (location.key === 'default') {
        setLoading(true);
      }
      try {
        const user = await User.me();
        setCurrentUser(user);
      } catch (e) {
        setCurrentUser(null);
      } finally {
        setLoading(false);
      }
    };
    processAuth();
  }, [location.pathname, location.key]);

  useEffect(() => {
    if (loading) return;

    if (currentUser) {
      // Changed: Simplified onboarding check. LocationPermission might be accessed even if onboarding not complete.
      if (!currentUser.onboarding_completed && currentPageName !== 'Onboarding') {
          navigate(createPageUrl('Onboarding'), { replace: true });
          return;
      }

      if (currentUser.onboarding_completed && !currentUser.latitude && !currentUser.longitude && currentPageName === 'Discover') {
        navigate(createPageUrl('LocationPermission'), { replace: true });
        return;
      }

      // Logged in users shouldn't see welcome page
      // Changed: Removed 'Login' from the check.
      if (currentPageName === 'Welcome') {
        navigate(createPageUrl('Discover'), { replace: true });
      }
    } else {
      // Non-logged in users get redirected to Welcome
      if (protectedPages.includes(currentPageName)) {
        navigate(createPageUrl('Welcome'), { replace: true });
      }
    }
  }, [loading, currentUser, currentPageName, navigate, protectedPages]);

  // Simplified instant navigation handler
  const handleNavigation = (url) => {
    navigate(url);
  };

  const showLoader = loading ||
                     (!currentUser && protectedPages.includes(currentPageName)) ||
                     (currentUser && (publicOnlyPages.includes(currentPageName) || ['Welcome', 'Login'].includes(currentPageName))); // Ensured 'Login' is included for loader logic

  if (showLoader) {
    return <FullScreenLoader />;
  }

  return (
    <div 
      className="h-screen bg-white flex flex-col" // Changed min-h-screen to h-screen
      dir={language === 'he' ? 'rtl' : 'ltr'}
      style={{
        paddingTop: 'env(safe-area-inset-top)',
        paddingBottom: 'env(safe-area-inset-bottom)'
      }}
    >
      <PWAManager />
      <style>{`
          :root {
            --brand-purple-dark: #4C2A4C;
            --brand-purple-medium: #8A4E8B;
            --brand-purple-light: #C7A5C9;
            --brand-purple-bg: #F5F1FE;
            --brand-purple-accent: #A174A4;
            --tinder-red: #FD3A73;
          }
          body { background-color: white; }
          .tinder-gradient-text { background: linear-gradient(90deg, #FD3A73, #FF655B); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
          .glass-effect { backdrop-filter: blur(10px); background: rgba(255, 255, 255, 0.95); }
          .brand-gradient { background: linear-gradient(135deg, var(--brand-purple-light) 0%, var(--brand-purple-medium) 100%); }
          .cultural-pattern { background-color: var(--brand-purple-bg); }

          /* PWA specific styles */
          @media (display-mode: standalone) {
            body {
              padding-top: env(safe-area-inset-top);
              padding-bottom: env(safe-area-inset-bottom);
            }
          }

          input, textarea {
            -webkit-user-select: text;
            -moz-user-select: text;
            -ms-user-select: text;
            user-select: text;
          }
      `}</style>

      {!shouldHideHeader && (
        <header className="glass-effect border-b border-gray-200/80 px-4 sm:px-6 py-3 sticky top-0 z-50 shrink-0">
          <div className="max-w-md mx-auto flex items-center justify-between">
            <div className="flex items-center gap-2 sm:gap-3">
              <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/fd93b36f7_WhatsAppImage2025-07-14at012021.jpeg" alt="RootsMatch Logo" className="w-10 h-10 object-contain"/>
              <div>
                <h1 className="text-lg sm:text-xl font-bold" style={{color: 'var(--brand-purple-dark)'}}>RootsMatch</h1>
                <p className="text-xs" style={{color: 'var(--brand-purple-medium)'}}>{language === 'he' ? 'התחברות שורשית' : 'ሳንሱ ያለ ግንኙት'}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              {currentUser?.role === 'admin' && (
                <button 
                  onClick={() => handleNavigation(createPageUrl("AdminDashboard"))} 
                  className="flex items-center gap-1 bg-gradient-to-r from-red-500 to-red-600 text-white px-3 py-1.5 rounded-full text-sm font-medium shadow-lg hover:shadow-xl transition-all duration-300"
                  title="ניהול מערכת"
                >
                  <Shield className="w-4 h-4" />
                  <span className="hidden sm:inline">ניהול</span>
                </button>
              )}
              
              <button 
                onClick={() => handleNavigation(createPageUrl("Premium"))} 
                className="flex items-center gap-2 bg-gradient-to-r from-purple-500 to-purple-600 text-white px-3 py-1.5 rounded-full text-sm font-medium shadow-lg hover:shadow-xl transition-all duration-300"
              >
                <Crown className="w-4 h-4" />
                <span className="hidden sm:inline">{t('premium', language)}</span>
              </button>
            </div>
          </div>
        </header>
      )}

      <main className={`flex-1 flex flex-col overflow-y-auto bg-white relative ${shouldShowBottomNav ? 'pb-20' : ''}`}>
        {children}
      </main>

      {shouldShowBottomNav && (
        <nav
          className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200/80 px-2 sm:px-4 py-1 z-50 shrink-0"
          style={{ paddingBottom: 'calc(4px + env(safe-area-inset-bottom))' }}
        >
          <div className="max-w-md mx-auto flex justify-around items-center h-16">
            {[
              { title: t('profile', language), url: createPageUrl("Profile"), icon: UserIcon, key: "profile", pageName: "Profile" },
              { title: t('matches', language), url: createPageUrl("Matches"), icon: MessageCircle, key: "matches", pageName: "Matches" },
              { title: 'RootsMatch', url: createPageUrl("Discover"), icon: Flame, key: "discover", pageName: "Discover" },
              { title: t('premium', language), url: createPageUrl("Premium"), icon: Heart, key: "premium", pageName: "Premium" },
              ...(currentUser?.role === 'admin' ? 
                 [{ title: 'ניהול', url: createPageUrl("AdminDashboard"), icon: Shield, key: "admin", pageName: "AdminDashboard" }] : 
                 [{ title: t('settings', language), url: createPageUrl("Settings"), icon: Settings, key: "settings", pageName: "Settings" }]
              )
            ].map((item) => {
              const isActive = (() => {
                const pageMap = { 
                  "Discover": "discover", 
                  "Matches": "matches", 
                  "Profile": "profile", 
                  "Settings": "settings", 
                  "Premium": "premium",
                  "AdminDashboard": "admin",
                  "AdminUserManagement": "admin",
                  "AdminSettings": "admin",
                };
                return pageMap[currentPageName] === item.key;
              })();
              
              if (item.key === 'discover') {
                return (
                  <button 
                    key={item.key} 
                    onClick={() => handleNavigation(item.url)}
                    className="w-16 sm:w-20 flex justify-center"
                  >
                    <div className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 ${isActive ? 'bg-purple-50' : 'bg-gray-100'}`}>
                       <img src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/fd93b36f7_WhatsAppImage2025-07-14at012021.jpeg" alt="Discover" className="w-10 h-10 object-contain rounded-full" />
                    </div>
                  </button>
                )
              }

              return (
                <button
                  key={item.key}
                  onClick={() => handleNavigation(item.url)}
                  className={`flex flex-col items-center justify-center gap-1 w-16 sm:w-20 h-full transition-colors duration-200 ${
                    isActive ? 'text-purple-500' : 'text-gray-400 hover:text-gray-600'
                  }`}
                >
                  <item.icon className={`w-7 h-7 ${isActive ? 'fill-current' : ''}`} strokeWidth={isActive ? 2 : 1.5} />
                  <span className={`text-[10px] font-bold ${isActive ? 'text-purple-500' : 'text-gray-500'}`}>{item.title}</span>
                </button>
              );
            })}
          </div>
        </nav>
      )}

      <PWAInstaller />
    </div>
  );
};

export default function Layout({ children, currentPageName }) {
  return (
    <LanguageProvider>
      <LayoutContent children={children} currentPageName={currentPageName} />
    </LanguageProvider>
  );
}

