import Layout from "./Layout.jsx";

import Discover from "./Discover";

import Profile from "./Profile";

import Matches from "./Matches";

import Settings from "./Settings";

import Premium from "./Premium";

import Payment from "./Payment";

import Welcome from "./Welcome";

import Onboarding from "./Onboarding";

import LocationPermission from "./LocationPermission";

import AdminDashboard from "./AdminDashboard";

import AdminUserManagement from "./AdminUserManagement";

import Terms from "./Terms";

import Help from "./Help";

import AdminLogin from "./AdminLogin";

import AdminSettings from "./AdminSettings";

import Chat from "./Chat";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Discover: Discover,
    
    Profile: Profile,
    
    Matches: Matches,
    
    Settings: Settings,
    
    Premium: Premium,
    
    Payment: Payment,
    
    Welcome: Welcome,
    
    Onboarding: Onboarding,
    
    LocationPermission: LocationPermission,
    
    AdminDashboard: AdminDashboard,
    
    AdminUserManagement: AdminUserManagement,
    
    Terms: Terms,
    
    Help: Help,
    
    AdminLogin: AdminLogin,
    
    AdminSettings: AdminSettings,
    
    Chat: Chat,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Discover />} />
                
                
                <Route path="/Discover" element={<Discover />} />
                
                <Route path="/Profile" element={<Profile />} />
                
                <Route path="/Matches" element={<Matches />} />
                
                <Route path="/Settings" element={<Settings />} />
                
                <Route path="/Premium" element={<Premium />} />
                
                <Route path="/Payment" element={<Payment />} />
                
                <Route path="/Welcome" element={<Welcome />} />
                
                <Route path="/Onboarding" element={<Onboarding />} />
                
                <Route path="/LocationPermission" element={<LocationPermission />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/AdminUserManagement" element={<AdminUserManagement />} />
                
                <Route path="/Terms" element={<Terms />} />
                
                <Route path="/Help" element={<Help />} />
                
                <Route path="/AdminLogin" element={<AdminLogin />} />
                
                <Route path="/AdminSettings" element={<AdminSettings />} />
                
                <Route path="/Chat" element={<Chat />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}