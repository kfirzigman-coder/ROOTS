
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { User, PublicProfile, Match } from '@/api/entities';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Heart, X, Star, Zap, RotateCcw, Users, Wand2, Crown, MessageCircle, HeartCrack } from 'lucide-react';
import ProfileCard from '../components/cards/ProfileCard';
import AdCard from '../components/cards/AdCard';
import { useLanguage } from '../components/language/LanguageContext';
import { t } from '../components/language/translations';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import ProfileDetailModal from '../components/profile/ProfileDetailModal';

const imageCache = new Map();
const preloadImage = (url) => {
  if (!imageCache.has(url)) {
    imageCache.set(url, 'loading');
    const img = new Image();
    img.onload = () => imageCache.set(url, 'loaded');
    img.onerror = () => imageCache.set(url, 'error');
    img.src = url;
  }
};

const apiCallWithRetry = async (apiCall, maxRetries = 2, delay = 2000) => {
  for (let i = 0; i < maxRetries; i++) {
    try {
      // THIS IS THE FIX: The SDK methods return the data directly, not an object.
      return await apiCall();
    } catch (error) {
      console.warn(`API call failed (attempt ${i + 1}/${maxRetries}):`, error.message);
      if (i === maxRetries - 1) {
        throw error;
      }
      await new Promise(resolve => setTimeout(resolve, delay * (i + 2)));
    }
  }
};

export default function Discover() {
  const [users, setUsers] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showMatchModal, setShowMatchModal] = useState(false);
  const [newMatch, setNewMatch] = useState(null);
  const [selectedProfile, setSelectedProfile] = useState(null);
  const [showProfileModal, setShowProfileModal] = useState(false);

  const { language } = useLanguage();
  const navigate = useNavigate();

  const STACK_SIZE = 3;

  const visibleUsers = useMemo(() => {
    return users.slice(currentIndex, currentIndex + STACK_SIZE);
  }, [users, currentIndex]);
  
  // Simple distance calculation (Haversine formula)
  const calculateDistance = (lat1, lon1, lat2, lon2) => {
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLon/2) * Math.sin(dLon/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c;
  };

  const loadPublicProfiles = useCallback(async (user) => {
    try {
      // FIX: Removed incorrect destructuring. The data array is returned directly.
      const publicProfiles = await apiCallWithRetry(() => PublicProfile.list('-created_date', 100), 2, 3000);
      const userMatches = await apiCallWithRetry(() => Match.filter({ $or: [{ user1_id: user.id }, { user2_id: user.id }] }, '', 100), 2, 3000);

      const interactedUserIds = new Set();
      if (userMatches && Array.isArray(userMatches)) {
          userMatches.forEach((match) => {
            interactedUserIds.add(match.user1_id);
            interactedUserIds.add(match.user2_id);
          });
      }

      const blockedUserIds = new Set(user.blocked_user_ids || []);

      if (!publicProfiles || !Array.isArray(publicProfiles)) {
          console.warn("Public profiles data is not an array or is null/undefined:", publicProfiles);
          setUsers([]);
          setError(t('loadProfilesFailed', language));
          return;
      }

      let filteredProfiles = publicProfiles.filter((profile) => {
        if (profile.user_id === user.id) return false;
        if (interactedUserIds.has(profile.user_id)) return false;
        if (blockedUserIds.has(profile.user_id)) return false;
        if (!profile.chosen_name || !profile.age || !profile.photos?.length) return false;
        if (profile.chosen_name?.toLowerCase().includes('demo') || profile.chosen_name?.toLowerCase().includes('test') || profile.chosen_name?.toLowerCase().includes('בדיקה')) {
          return false;
        }

        const userMinAge = user.age_preference_min || 18;
        const userMaxAge = user.age_preference_max || 61;
        if (profile.age < userMinAge || profile.age > userMaxAge) return false;

        if (user.latitude && user.longitude && profile.latitude && profile.longitude) {
          const distance = calculateDistance(user.latitude, user.longitude, profile.latitude, profile.longitude);
          if (distance > (user.distance_preference || 25)) return false;
        }
        return true;
      });

      const profilesWithAds = [];
      filteredProfiles.forEach((profile, index) => {
        profilesWithAds.push(profile);
        if ((index + 1) % 5 === 0) {
          profilesWithAds.push({ isAd: true, id: `ad_${Date.now()}_${index}`, type: 'premium' });
        }
      });

      if (profilesWithAds.length === 0) {
        setError(t('noProfilesFound', language));
      } else {
        filteredProfiles.forEach((p) => p.photos?.forEach(preloadImage));
        setUsers(profilesWithAds);
        setError(null);
      }
    } catch (e) {
      console.error("❌ Failed to load profiles:", e);
      if (e.message?.includes('Rate limit') || e.message?.includes('429')) {
        setError('יותר מדי בקשות. אנא המתן כמה שניות ונסה שוב.');
      } else {
        setError(t('loadProfilesFailed', language));
      }
      setUsers([]);
    }
  }, [language]);

  useEffect(() => {
    const initialize = async () => {
      setLoading(true);
      setError(null);
      try {
        const user = await User.me();
        if (!user || !user.onboarding_completed) {
          navigate(createPageUrl('Welcome'), { replace: true });
          return;
        }
        setCurrentUser(user);
        await loadPublicProfiles(user);
      } catch (error) {
        console.error('Initialize error:', error);
        setError(t('loadProfilesFailed', language));
      } finally {
        setLoading(false);
      }
    };
    initialize();
  }, [navigate, language, loadPublicProfiles]);

  const checkForMatch = useCallback(async (currentUserId, currentUserProfile, swipedUserId, swipedUserProfile) => {
    try {
      console.log('🔍 Checking for match between:', currentUserId, 'and', swipedUserId);
      
      // FIX: Removed incorrect destructuring. Match.filter returns the array directly.
      const existingMatches = await Match.filter({
        status: 'pending',
        $or: [
          { user1_id: swipedUserId, user2_id: currentUserId },
          { user1_id: currentUserId, user2_id: swipedUserId }
        ]
      });
      
      console.log('📊 Found existing pending matches:', existingMatches?.length || 0);

      if (existingMatches && existingMatches.length > 0) {
        const matchRecord = existingMatches[0];
        
        // --- FIX START ---
        // Ensure both profiles are fully loaded before updating the match.
        // It's safer to re-fetch than rely on potentially stale passed-in objects.
        const [user1ProfileData, user2ProfileData] = await Promise.all([
            PublicProfile.filter({ user_id: matchRecord.user1_id }),
            PublicProfile.filter({ user_id: matchRecord.user2_id })
        ]);
        
        const user1Profile = user1ProfileData[0];
        const user2Profile = user2ProfileData[0];

        if (!user1Profile || !user2Profile) {
            throw new Error("Could not fetch full profiles for match update.");
        }
        // --- FIX END ---

        // FIX: Removed incorrect destructuring. Match.update returns the object directly.
        const updatedMatch = await apiCallWithRetry(() => Match.update(matchRecord.id, { 
            status: 'matched', 
            matched_at: new Date().toISOString(),
            // Add user details for fast loading on matches screen
            user1_name: user1Profile.chosen_name,
            user1_photo: user1Profile.photos?.[0],
            user2_name: user2Profile.chosen_name,
            user2_photo: user2Profile.photos?.[0],
        }), 2, 500);

        if (!updatedMatch || !updatedMatch.id) {
          throw new Error("Failed to update match or received invalid data.");
        }

        console.log('✅ Match updated to "matched" with ID:', updatedMatch.id);
        return { isMatch: true, matchId: updatedMatch.id };
      }
      return { isMatch: false, matchId: null };
    } catch (error) {
      console.error("❌ Error checking for match:", error);
      return { isMatch: false, matchId: null };
    }
  }, []);

  const handleSwipeAction = useCallback(async (action) => {
    if (currentIndex >= users.length) return;

    // Update user's last active status on any interaction
    try {
      await User.updateMyUserData({ last_active: new Date().toISOString() });
    } catch (error) {
      console.warn('⚠️ Could not update last active status:', error);
    }

    const swipedItem = users[currentIndex];
    console.log('👆 Swipe action:', action, 'on:', swipedItem.isAd ? 'Ad Card' : swipedItem.chosen_name);

    setCurrentIndex((prev) => prev + 1);

    if (swipedItem.isAd) {
      console.log('📢 Ad card dismissed');
      return;
    }

    if (!currentUser || !swipedItem) return;
    
    // FIX: Removed incorrect destructuring. PublicProfile.filter returns the array directly.
    const currentUserProfileData = await PublicProfile.filter({user_id: currentUser.id});
    const currentUserProfile = currentUserProfileData?.[0];

    if (!currentUserProfile) {
        console.error("Could not find current user's public profile. Aborting swipe.");
        return;
    }

    // Check for the force match flag from admin tools
    const forceMatch = localStorage.getItem('forceNextMatch') === 'true';
    if (forceMatch) {
      localStorage.removeItem('forceNextMatch'); // Use it only once
    }

    try {
      if (action === 'superlike') {
        const superLikesRemaining = currentUser.super_likes_remaining || 0;
        if (superLikesRemaining <= 0) {
          alert('נגמרו הסופר לייקים! שדרג לפרימיום כדי לקבל עוד.');
          navigate(createPageUrl('Premium'));
          return; // Prevent further action if superlikes are depleted
        }
      }

      if (action === 'like' || action === 'superlike') {
        let actualMatchHappened = false;
        let matchRecordId = null;

        if (forceMatch) {
          console.log('🚀 Forcing a match as per admin request!');
          try {
            // FIX: Removed incorrect destructuring. Match.filter returns array directly.
            const existingMatch = await apiCallWithRetry(() => Match.filter({
              $or: [
                { user1_id: currentUser.id, user2_id: swipedItem.user_id },
                { user1_id: swipedItem.user_id, user2_id: currentUser.id },
              ],
            }), 2, 500);

            let newOrUpdatedMatch;
            const matchData = {
                status: 'matched',
                matched_at: new Date().toISOString(),
                is_super_like: action === 'superlike',
                user1_id: currentUser.id,
                user2_id: swipedItem.user_id,
                user1_name: currentUserProfile.chosen_name,
                user1_photo: currentUserProfile.photos?.[0],
                user2_name: swipedItem.chosen_name,
                user2_photo: swipedItem.photos?.[0],
            };

            if (existingMatch && existingMatch.length > 0) {
              // FIX: The SDK call is already wrapped, just await it.
              newOrUpdatedMatch = await apiCallWithRetry(() => Match.update(existingMatch[0].id, matchData), 2, 500);
            } else {
              newOrUpdatedMatch = await apiCallWithRetry(() => Match.create(matchData), 2, 500);
            }
            
            if (!newOrUpdatedMatch || !newOrUpdatedMatch.id) {
               throw new Error("Forced match creation/update failed or returned invalid data.");
            }

            console.log('🎉 Forced REAL MATCH created/updated with ID:', newOrUpdatedMatch.id);
            matchRecordId = newOrUpdatedMatch.id;
            actualMatchHappened = true;
          } catch (error) {
            console.error("❌ Error processing forced match:", error);
          }
        } else {
          // Regular match logic
          const { isMatch, matchId } = await checkForMatch(currentUser.id, currentUserProfile, swipedItem.user_id, swipedItem);
          matchRecordId = matchId;
          actualMatchHappened = isMatch;

          if (!isMatch) {
            try {
              // FIX: Removed incorrect destructuring.
              const existingPending = await Match.filter({
                status: 'pending',
                user1_id: currentUser.id,
                user2_id: swipedItem.user_id,
              });

              if (!existingPending || existingPending.length === 0) {
                 // FIX: Removed incorrect destructuring.
                 const pendingMatchRecord = await apiCallWithRetry(() => Match.create({
                  user1_id: currentUser.id,
                  user2_id: swipedItem.user_id,
                  status: 'pending',
                  is_super_like: action === 'superlike'
                }), 2, 500);

                if (!pendingMatchRecord?.id) {
                    throw new Error("Failed to create pending match record or received invalid data.");
                }
                console.log('📝 Created new pending match with ID:', pendingMatchRecord.id);
              } else {
                console.log('👍 Pending match already exists. No action needed.');
              }
            } catch (error) {
              console.warn('⚠️ Failed to create or check for pending match record:', error);
            }
          }
        }

        if (actualMatchHappened) {
          setNewMatch({ ...swipedItem, matchId: matchRecordId, isSuperLike: action === 'superlike' });
          setShowMatchModal(true);
        }

        if (action === 'superlike') {
          const newSuperLikesCount = Math.max(0, (currentUser.super_likes_remaining || 0) - 1);
          setCurrentUser((prev) => ({ ...prev, super_likes_remaining: newSuperLikesCount }));
          try {
            await apiCallWithRetry(() => User.updateMyUserData({ super_likes_remaining: newSuperLikesCount }), 2, 500);
          } catch (error) {
            console.warn('⚠️ Failed to update super likes count:', error);
          }
        }

        try {
          const likesField = action === 'superlike' ? 'super_likes_received' : 'likes_received';
          const currentLikes = swipedItem[likesField] || 0;
          // FIX: Removed incorrect destructuring.
          await apiCallWithRetry(() => PublicProfile.update(swipedItem.id, { [likesField]: currentLikes + 1 }), 2, 500);
        } catch (error) {
          console.warn("⚠️ Could not update like count:", error);
        }
      }
    } catch (error) {
      console.error("❌ Error processing REAL swipe:", error);
    }
  }, [currentIndex, users, currentUser, navigate, checkForMatch]);

  const handleSendMessage = useCallback(() => {
    if (!newMatch?.matchId) {
      console.log('❌ No match ID available for REAL chat');
      return;
    }
    console.log('🚀 Navigating to REAL match:', newMatch.matchId, 'with user:', newMatch.chosen_name);
    setShowMatchModal(false);
    
    navigate(createPageUrl(`Chat?matchId=${newMatch.matchId}`));
  }, [newMatch, navigate]);

  const refreshProfiles = useCallback(async () => {
    if (!currentUser) return;
    setLoading(true);
    setError(null);
    setCurrentIndex(0);
    await loadPublicProfiles(currentUser);
    setLoading(false);
  }, [currentUser, loadPublicProfiles]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="w-16 h-16 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="h-full bg-gradient-to-br from-purple-50 to-pink-50 flex flex-col">
       {/* Redesigned Header */}
       <header className="flex items-center justify-between p-2 sm:p-4 bg-white/80 backdrop-blur-lg border-b border-gray-200/60 sticky top-0 z-20">
         <img
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/fd93b36f7_WhatsAppImage2025-07-14at012021.jpeg"
          alt="RootsMatch Logo"
          className="w-10 h-10 object-contain" />

        <div className="flex items-center gap-1 sm:gap-3">
           <Button variant="outline" size="sm" onClick={() => navigate(createPageUrl('Premium'))} className="rounded-full text-yellow-600 border-yellow-400 font-bold hover:bg-yellow-50 shadow-sm px-3 sm:px-4">
                <Crown className="w-4 h-4 sm:mr-2 text-yellow-500" />
                <span className="hidden sm:inline">פרימיום</span>
           </Button>
           <Button size="sm" onClick={() => navigate(createPageUrl('Payment?planId=boost_1&planName=Boost&price=15.90&period=One-time'))} className="rounded-full bg-purple-100 text-purple-700 font-bold hover:bg-purple-200 shadow-sm px-3 sm:px-4">
               <Zap className="w-4 h-4 sm:mr-2 text-purple-500" />
               <span className="hidden sm:inline">בוסט</span>
           </Button>
        </div>
       </header>

      {/* Main Cards Area */}
      <div className="flex-1 flex items-center justify-center p-4">
        <div className="w-full max-w-sm aspect-[10/16] relative">
          <AnimatePresence>
            {/* Out of Profiles View */}
            {!loading && visibleUsers.length === 0 && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="text-center p-6 flex flex-col justify-center items-center h-full bg-white rounded-3xl shadow-xl border border-gray-200"
              >
                <HeartCrack className="w-20 h-20 text-gray-300 mb-6" />
                <h2 className="text-2xl font-bold text-gray-800 mb-3">
                  {error || t('noMoreProfilesTitle', language)}
                </h2>
                <p className="text-gray-500 mb-8 max-w-xs mx-auto">
                  {t('noMoreProfilesDesc', language)}
                </p>
                <div className="flex flex-col gap-3 w-full">
                  <Button onClick={refreshProfiles} size="lg" className="bg-purple-600 hover:bg-purple-700 w-full rounded-xl text-base py-6">
                    <RotateCcw className="w-5 h-5 mr-2" />
                    {t('refreshProfiles', language)}
                  </Button>
                  <Button onClick={() => navigate(createPageUrl('Settings'))} variant="outline" size="lg" className="w-full rounded-xl text-base py-6">
                    <Wand2 className="w-5 h-5 mr-2" />
                    {t('changePreferences', language)}
                  </Button>
                </div>
              </motion.div>
            )}

            {/* Profile Cards */}
            {visibleUsers.map((item, index) => {
              const isTopCard = index === 0;
              const cardKey = item.isAd ? item.id : item.user_id;

              return (
                <motion.div
                  key={cardKey}
                  className="absolute inset-0"
                  style={{ zIndex: STACK_SIZE - index }}
                  initial={{
                    scale: 1 - index * 0.05,
                    y: index * 10,
                    opacity: isTopCard ? 1 : 0.6
                  }}
                  animate={{
                    scale: 1 - index * 0.05,
                    y: index * 10,
                    opacity: 1
                  }}
                  exit={{ x: 500, opacity: 0, transition: { duration: 0.4 } }}
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                >
                  {item.isAd ? (
                    <AdCard onSwipe={handleSwipeAction} isTopCard={isTopCard} />
                  ) : (
                    <ProfileCard
                      user={item}
                      onSwipe={handleSwipeAction}
                      isTopCard={isTopCard}
                      onOpenDetails={() => {
                        setSelectedProfile(item);
                        setShowProfileModal(true);
                      }}
                    />
                  )}
                </motion.div>
              );
            }).reverse()}
          </AnimatePresence>
        </div>
      </div>
      
      {/* Redesigned Action Buttons */}
      <div className="fixed bottom-20 left-0 right-0 px-4 pt-2 pb-2 z-10">
        <div className="flex items-center justify-around max-w-sm mx-auto bg-white/70 backdrop-blur-xl p-3 rounded-full shadow-2xl border border-gray-200/80">
          {[
            // RTL-friendly order: Boost, Like, Superlike, Pass, Rewind
            { action: 'boost', icon: Zap, color: 'text-purple-500' },
            { action: 'like', icon: Heart, color: 'text-green-500 fill-current', size: 'w-8 h-8' },
            { action: 'superlike', icon: Star, color: 'text-blue-500 fill-current' },
            { action: 'pass', icon: X, color: 'text-rose-500', size: 'w-8 h-8' },
            { action: 'rewind', icon: RotateCcw, color: 'text-yellow-500' }
          ].map(({ action, icon: Icon, color, size = 'w-6 h-6' }) => {
            const isDisabled = visibleUsers.length === 0 || (action === 'superlike' && (currentUser?.super_likes_remaining || 0) <= 0);
            return (
              <Button
                key={action}
                onClick={() => action === 'boost' ? navigate(createPageUrl('Premium')) : handleSwipeAction(action)}
                disabled={isDisabled}
                variant="ghost"
                className="w-14 h-14 rounded-full flex items-center justify-center transition-all duration-300 hover:bg-gray-200/50 active:scale-90 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <Icon className={`${size} ${color}`} />
              </Button>
            );
          })}
        </div>
      </div>
      
      {/* Redesigned Match Modal */}
      <AnimatePresence>
        {showMatchModal && newMatch && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-md flex items-center justify-center z-50 p-4"
            onClick={() => setShowMatchModal(false)}
          >
            <motion.div
              initial={{ scale: 0.8, opacity: 0, y: 50 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.8, opacity: 0, y: 50 }}
              transition={{ type: 'spring', stiffness: 400, damping: 25 }}
              className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-3xl p-6 max-w-sm w-full text-center shadow-2xl border border-purple-200 overflow-hidden relative"
              onClick={(e) => e.stopPropagation()}
            >
              {/* Confetti Animation Placeholder */}
              {[...Array(50)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute rounded-full"
                  style={{
                    left: `${Math.random() * 100}%`,
                    top: `${Math.random() * 100}%`,
                    width: `${Math.random() * 8 + 4}px`,
                    height: `${Math.random() * 8 + 4}px`,
                    background: ['#a855f7', '#ec4899', '#fde047', '#4ade80'][i % 4]
                  }}
                  animate={{
                    y: [0, -100, 200],
                    opacity: [1, 1, 0],
                    scale: [1, 1.5, 0]
                  }}
                  transition={{
                    duration: Math.random() * 2 + 1,
                    repeat: Infinity,
                    delay: Math.random() * 1.5
                  }}
                />
              ))}

              <motion.h2 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 }}
                className="text-4xl font-bold mb-2 bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent"
              >
                {newMatch.isSuperLike ? t('superMatchTitle', language) : t('itsAMatch', language)}
              </motion.h2>
              
              <motion.p 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="text-gray-600 mb-6 text-lg"
              >
                {t('matchGreeting', language).replace('{name}', newMatch.chosen_name)}
              </motion.p>

              {/* Profile photos */}
              <motion.div 
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.3 }}
                className="flex justify-center items-center -space-x-6 mb-8"
              >
                <img 
                  src={currentUser?.photos?.[0] || 'https://via.placeholder.com/80'} 
                  alt="You" 
                  className="w-28 h-28 rounded-full object-cover border-4 border-white shadow-lg transform -rotate-12" 
                />
                <img 
                  src={newMatch.photos?.[0] || 'https://via.placeholder.com/80'} 
                  alt={newMatch.chosen_name} 
                  className="w-28 h-28 rounded-full object-cover border-4 border-white shadow-lg transform rotate-12" 
                />
              </motion.div>

              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 }}
                className="space-y-3"
              >
                <Button 
                  onClick={() => handleSendMessage()} 
                  className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-bold py-3 text-base rounded-xl shadow-lg"
                  size="lg"
                >
                  <MessageCircle className="w-5 h-5 mr-2" />
                  {t('sendMessage', language)}
                </Button>
                <Button 
                  variant="ghost" 
                  onClick={() => setShowMatchModal(false)} 
                  className="w-full text-purple-600 hover:bg-purple-100 font-semibold py-3 rounded-xl"
                  size="lg"
                >
                  {t('keepSwiping', language)}
                </Button>
              </motion.div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      <ProfileDetailModal
        user={selectedProfile}
        isOpen={showProfileModal}
        onClose={() => {
          setShowProfileModal(false);
          setSelectedProfile(null);
        }} />
    </div>
  );
}
