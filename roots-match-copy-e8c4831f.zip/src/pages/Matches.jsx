
import React, { useState, useEffect, useCallback } from 'react';
import { User, Match } from '@/api/entities'; // Simplified imports
import { Button } from '@/components/ui/button';
import { Users, RefreshCw } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// A simple, safe function to format last active status from the last message time
const formatLastMessageTime = (lastMessageAt) => {
    if (!lastMessageAt || isNaN(new Date(lastMessageAt).getTime())) return null;

    const now = new Date();
    const lastActive = new Date(lastMessageAt);
    const diffSeconds = Math.floor((now - lastActive) / 1000);

    if (diffSeconds < 60) return 'כעת';
    if (diffSeconds < 3600) return `לפני ${Math.floor(diffSeconds / 60)} ד'`;
    if (diffSeconds < 86400) return `לפני ${Math.floor(diffSeconds / 3600)} ש'`;
    return `לפני ${Math.floor(diffSeconds / 86400)} י'`;
};


export default function Matches() {
    const [matches, setMatches] = useState([]);
    const [loading, setLoading] = useState(true);
    const [currentUser, setCurrentUser] = useState(null);
    const navigate = useNavigate();

    const loadMatches = useCallback(async (user) => {
        if (!user) return;
        setLoading(true);
        try {
            // SIMPLIFIED LOGIC: Fetch only the match records. All needed data is now denormalized.
            const userMatches = await Match.filter({
                status: 'matched',
                $or: [{ user1_id: user.id }, { user2_id: user.id }]
            }, '-last_message_at', 50);

            setMatches(userMatches || []);

        } catch (error) {
            console.error("Failed to load matches:", error);
            setMatches([]); // Clear on error
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        const init = async () => {
            try {
                const user = await User.me();
                if (!user) {
                    navigate(createPageUrl('Welcome'));
                    return;
                }
                setCurrentUser(user);
                await loadMatches(user);
           } catch(e) {
                navigate(createPageUrl('Welcome'));
            }
        };
        init();
    }, [loadMatches, navigate]);

    useEffect(() => {
        if (!currentUser) return;
        // CRITICAL FIX: Changed interval from 1 second to 30 seconds to prevent excessive API calls and improve performance.
        const intervalId = setInterval(() => {
          loadMatches(currentUser);
        }, 30000); // Refresh every 30 seconds
        return () => clearInterval(intervalId);
    }, [currentUser, loadMatches]);
    
    const handleChatClick = (matchId) => {
        if (matchId) {
            navigate(createPageUrl(`Chat?matchId=${matchId}`));
        }
    };

    if (loading) {
        return (
            <div className="flex items-center justify-center h-full bg-gray-50">
                <div className="w-16 h-16 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin" />
            </div>
        );
    }

    return (
        <div className="h-full bg-gray-50 flex flex-col">
            <header className="bg-white border-b p-4 shrink-0 flex justify-between items-center sticky top-0 z-10">
                <h1 className="text-xl font-bold text-center flex-1">התאמות ({matches.length})</h1>
                <Button variant="ghost" size="sm" onClick={() => loadMatches(currentUser)} disabled={loading}>
                    <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
                    רענן
                </Button>
            </header>
            
            <main className="flex-1 overflow-y-auto p-2 pb-24 md:pb-4">
                {matches.length === 0 ? (
                    <div className="text-center pt-12">
                        <Users className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                        <h2 className="text-xl font-bold text-gray-800 mb-2">אין התאמות עדיין</h2>
                        <p className="text-gray-600 mb-6">עשה לייק לאנשים כדי לקבל התאמות!</p>
                        <Button onClick={() => navigate(createPageUrl('Discover'))}>התחל לגלות</Button>
                    </div>
                ) : (
                    <div className="max-w-2xl mx-auto">
                        {matches.map(match => {
                            if (!currentUser) return null;
                            // Determine other user's info directly from the match object
                            const isUser1 = match.user1_id === currentUser.id;
                            const otherUserName = isUser1 ? match.user2_name : match.user1_name;
                            const otherUserPhoto = isUser1 ? match.user2_photo : match.user1_photo;

                            return (
                                <div key={match.id} onClick={() => handleChatClick(match.id)} className="bg-white rounded-lg p-3 mb-2 shadow-sm cursor-pointer hover:shadow-md transition-shadow flex items-center gap-3">
                                    <div className="relative shrink-0">
                                        <img src={otherUserPhoto || 'https://via.placeholder.com/150'} alt={otherUserName} className="w-14 h-14 rounded-full object-cover" />
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="flex justify-between items-center">
                                            <h3 className="font-semibold truncate">{otherUserName}</h3>
                                            {match.last_message_at && (
                                                <p className="text-xs text-gray-500 whitespace-nowrap">{formatLastMessageTime(match.last_message_at)}</p>
                                            )}
                                        </div>
                                        <p className="text-sm text-gray-600 truncate">{match.last_message_content || `התאמה מ-${new Date(match.matched_at).toLocaleDateString('he-IL')}`}</p>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                )}
            </main>
        </div>
    );
}
