import React, { useState, useEffect, useRef } from 'react';
import { User, Match, Message, PublicProfile } from '@/api/entities';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send, ArrowLeft, MoreVertical, Trash2, UserX } from 'lucide-react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

export default function ChatPage() {
    const [currentUser, setCurrentUser] = useState(null);
    const [otherUser, setOtherUser] = useState(null);
    const [currentMatch, setCurrentMatch] = useState(null);
    const [messages, setMessages] = useState([]);
    const [newMessage, setNewMessage] = useState('');
    const [loading, setLoading] = useState(true);
    const [showUnmatchDialog, setShowUnmatchDialog] = useState(false);
    const [showBlockDialog, setShowBlockDialog] = useState(false);
    const messagesEndRef = useRef(null);
    
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();
    const matchId = searchParams.get('matchId');

    useEffect(() => {
        if (!matchId) {
            navigate(createPageUrl('Matches'));
            return;
        }

        const initChat = async () => {
            setLoading(true);
            try {
                const user = await User.me();
                if (!user) {
                    navigate(createPageUrl('Welcome'));
                    return;
                }
                setCurrentUser(user);

                const match = await Match.get(matchId);
                if (!match) throw new Error("Match not found");
                setCurrentMatch(match);

                const otherUserId = match.user1_id === user.id ? match.user2_id : match.user1_id;
                const profile = await PublicProfile.filter({ user_id: otherUserId });
                if (!profile.length) throw new Error("Could not find the other user's profile.");
                setOtherUser(profile[0]);

                const initialMessages = await Message.filter({ match_id: matchId }, 'sent_at', 100);
                const processedMessages = (initialMessages || [])
                    .filter(msg => msg && msg.id && msg.sent_at && !isNaN(new Date(msg.sent_at).getTime()))
                    .sort((a, b) => new Date(a.sent_at).getTime() - new Date(b.sent_at).getTime());
                setMessages(processedMessages);
                
            } catch (error) {
                console.error("Error initializing chat:", error);
                navigate(createPageUrl('Matches'));
            } finally {
                setLoading(false);
            }
        };

        initChat();
    }, [matchId, navigate]);

    useEffect(() => {
        if (loading || !matchId) return;

        const intervalId = setInterval(async () => {
            try {
                const lastMessage = messages[messages.length - 1];
                const lastTimestamp = lastMessage ? lastMessage.sent_at : new Date(0).toISOString();

                const newMessages = await Message.filter({
                    match_id: matchId,
                    sent_at: { $gt: lastTimestamp }
                }, 'sent_at');
                
                if (newMessages.length > 0) {
                    setMessages(prev => {
                        const existingIds = new Set(prev.map(m => m.id));
                        const uniqueNewMessages = newMessages.filter(m => !existingIds.has(m.id));
                        if (uniqueNewMessages.length === 0) return prev;
                        
                        const updated = [...prev, ...uniqueNewMessages];
                        return updated.sort((a, b) => new Date(a.sent_at).getTime() - new Date(b.sent_at).getTime());
                    });
                }
            } catch (error) {
                console.error("Polling for new messages failed:", error);
            }
        }, 3000);

        return () => clearInterval(intervalId);
    }, [loading, matchId, messages]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

       const handleSendMessage = async () => {
          if (!newMessage.trim() || !currentUser || !matchId || !currentMatch) return;

          const tempId = `temp_${Date.now()}`;
          const sentAt = new Date();

          const optimisticMessage = {
            id: tempId,
            match_id: matchId,
            sender_id: currentUser.id,
            content: newMessage.trim(),
            sent_at: sentAt,
            isOptimistic: true,
          };

          setMessages((prev) => [...prev, optimisticMessage]);
          const messageContent = newMessage.trim();
          setNewMessage('');

          try {
            const createdMessage = await Message.create({
              match_id: matchId,
              content: messageContent,
              sender_id: currentUser.id,
              sent_at: sentAt,
              user1_id: currentMatch.user1_id,
              user2_id: currentMatch.user2_id,
            });

            await Match.update(matchId, {
              last_message_content: messageContent,
              last_message_at: sentAt,
              last_message_sender_id: currentUser.id,
            });

            setCurrentMatch((prev) => ({
              ...prev,
              last_message_content: messageContent,
              last_message_at: sentAt,
              last_message_sender_id: currentUser.id,
            }));

            setMessages((prev) =>
              prev.map((m) =>
                m.id === tempId ? { ...createdMessage, isOptimistic: false } : m
              )
            );

            await User.update(currentUser.id, { last_active: new Date() });
          } catch (error) {
            console.error('Failed to send message:', error);
            setMessages((prev) => prev.filter((m) => m.id !== tempId));
          }
        };

    const handleUnmatch = async () => {
        if (!matchId) return;
        try {
            await Match.delete(matchId);
            navigate(createPageUrl('Matches'));
        } catch (error) {
            console.error("Failed to unmatch:", error);
        } finally {
            setShowUnmatchDialog(false);
        }
    };

    const handleBlock = async () => {
        if (!otherUser?.user_id) return;
        try {
            await User.updateMyUserData({ 
                blocked_user_ids: [...(currentUser.blocked_user_ids || []), otherUser.user_id] 
            });
            await handleUnmatch();
        } catch (error) {
            console.error("Failed to block user:", error);
        } finally {
            setShowBlockDialog(false);
        }
    };

    if (loading) {
        return <div className="flex items-center justify-center h-full">טוען צ'אט...</div>;
    }
    
    if (!otherUser) {
        return <div className="flex items-center justify-center h-full">לא ניתן היה לטעון את הצ'אט.</div>;
    }

    return (
        <div className="h-screen w-screen absolute inset-0 flex flex-col bg-gray-50 z-50">
            <header className="bg-white border-b p-3 flex items-center justify-between gap-3 shadow-sm shrink-0 sticky top-0">
                 <div className="flex items-center gap-3">
                    <Button variant="ghost" size="icon" onClick={() => navigate(createPageUrl('Matches'))} className="text-gray-600 hover:bg-gray-100">
                        <ArrowLeft className="w-5 h-5" />
                    </Button>
                    <img src={otherUser.photos?.[0] || 'https://via.placeholder.com/150'} alt={otherUser.chosen_name} className="w-10 h-10 rounded-full object-cover" />
                    <div>
                        <h2 className="font-bold text-gray-900">{otherUser.chosen_name}</h2>
                    </div>
                </div>
                <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon"><MoreVertical className="w-5 h-5" /></Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent>
                        <DropdownMenuItem onClick={() => setShowUnmatchDialog(true)} className="text-red-500 flex items-center gap-2">
                            <Trash2 className="w-4 h-4" /> ביטול התאמה
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => setShowBlockDialog(true)} className="text-red-600 flex items-center gap-2">
                            <UserX className="w-4 h-4" /> חסימה וביטול התאמה
                        </DropdownMenuItem>
                    </DropdownMenuContent>
                </DropdownMenu>
            </header>

            <main className="flex-1 overflow-y-auto p-4 space-y-4">
                {messages.map(msg => (
                    <div key={msg.id} className={`flex ${msg.sender_id === currentUser?.id ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-xs md:max-w-md p-3 rounded-2xl ${msg.sender_id === currentUser?.id ? 'bg-purple-600 text-white' : 'bg-white text-gray-800 shadow-sm'}`}>
                            <p className="whitespace-pre-wrap">{msg.content}</p>
                            <p className={`text-xs mt-1 text-right ${msg.sender_id === currentUser?.id ? 'text-purple-200' : 'text-gray-500'} ${msg.isOptimistic ? 'opacity-70' : ''}`}>
                                {msg.isOptimistic ? 'שולח...' : new Date(msg.sent_at).toLocaleTimeString('he-IL', { hour: '2-digit', minute: '2-digit' })}
                            </p>
                        </div>
                    </div>
                ))}
                <div ref={messagesEndRef} />
            </main>

            <footer className="bg-white border-t p-2 shrink-0 sticky bottom-0">
                <div className="flex gap-2 items-center max-w-2xl mx-auto">
                    <Input value={newMessage} onChange={(e) => setNewMessage(e.target.value)} placeholder="כתוב הודעה..." className="flex-1 rounded-full px-4" onKeyDown={(e) => e.key === 'Enter' && handleSendMessage()} />
                    <Button onClick={handleSendMessage} size="icon" className="bg-purple-600 hover:bg-purple-700 rounded-full w-10 h-10">
                        <Send className="w-4 h-4" />
                    </Button>
                </div>
            </footer>
            
            <AlertDialog open={showUnmatchDialog} onOpenChange={setShowUnmatchDialog}>
                <AlertDialogContent>
                    <AlertDialogHeader><AlertDialogTitle>לבטל את ההתאמה?</AlertDialogTitle><AlertDialogDescription>פעולה זו תמחק את השיחה לצמיתות. לא תוכלו לדבר יותר.</AlertDialogDescription></AlertDialogHeader>
                    <AlertDialogFooter><AlertDialogCancel>ביטול</AlertDialogCancel><AlertDialogAction onClick={handleUnmatch} className="bg-red-500 hover:bg-red-600">בטל התאמה</AlertDialogAction></AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
            <AlertDialog open={showBlockDialog} onOpenChange={setShowBlockDialog}>
                <AlertDialogContent>
                    <AlertDialogHeader><AlertDialogTitle>לחסום את {otherUser?.chosen_name}?</AlertDialogTitle><AlertDialogDescription>המשתמש ייחסם ולא יופיע עבורך יותר. השיחה תימחק.</AlertDialogDescription></AlertDialogHeader>
                    <AlertDialogFooter><AlertDialogCancel>ביטול</AlertDialogCancel><AlertDialogAction onClick={handleBlock} className="bg-red-600 hover:bg-red-700">חסום</AlertDialogAction></AlertDialogFooter>
                </AlertDialogContent>
            </AlertDialog>
        </div>
    );
}