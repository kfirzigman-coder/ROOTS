
import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { PublicProfile } from '@/api/entities'; // Import PublicProfile - keep this import for now, as it might be used elsewhere or in future features.
import { Match } from '@/api/entities'; // Import Match
import { Message } from '@/api/entities'; // Import Message
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Crown,
  MapPin,
  Heart,
  Shield,
  Bell,
  Globe,
  HelpCircle,
  LogOut,
  ChevronLeft,
  Wand2,
  Users,
  Eye,
  Calendar,
  Loader2,
  MessageCircle // Import MessageCircle icon
} from 'lucide-react';
import { motion } from 'framer-motion';
import { useLanguage } from '../components/language/LanguageContext';
import { t } from '../components/language/translations';
import LanguageSelector from '../components/language/LanguageSelector';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// Reusable Section Card (from Profile page)
const Section = React.forwardRef(({ title, icon: Icon, children, className }, ref) => (
  <motion.div
    ref={ref}
    className={`bg-white/90 backdrop-blur-lg rounded-3xl shadow-lg border border-purple-100/40 overflow-hidden ${className}`}
    initial={{ opacity: 0, y: 30 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, type: 'spring' }}
  >
    <div className="p-5 border-b border-purple-100/60">
      <div className="flex items-center gap-3">
        <Icon className="w-5 h-5 text-[#3F2044]" />
        <h2 className="text-lg font-bold text-[#3F2044]">{title}</h2>
      </div>
    </div>
    <div className="p-5">{children}</div>
  </motion.div>
));

export default function Settings() {
  const [user, setUser] = useState(null);
  const [settings, setSettings] = useState({
    distance_preference: 25,
    age_preference_min: 18,
    age_preference_max: 61,
    notifications_matches: true,
    notifications_messages: true,
    notifications_likes: true,
    show_age: true,
    show_distance: true,
    discovery_enabled: true
  });
  const [loading, setLoading] = useState(true);
  const { language } = useLanguage();
  const navigate = useNavigate();

  useEffect(() => {
    loadSettings();
  }, []);

  const loadSettings = async () => {
    setLoading(true);
    try {
      const currentUser = await User.me();
      setUser(currentUser);
      setSettings({
        distance_preference: currentUser.distance_preference || 25,
        age_preference_min: currentUser.age_preference_min || 18,
        age_preference_max: currentUser.age_preference_max || 61,
        notifications_matches: currentUser.notifications_matches ?? true,
        notifications_messages: currentUser.notifications_messages ?? true,
        notifications_likes: currentUser.notifications_likes ?? true,
        show_age: currentUser.show_age ?? true,
        show_distance: currentUser.show_distance ?? true,
        discovery_enabled: currentUser.discovery_enabled ?? true
      });
    } catch (error) {
      console.error('Error loading settings:', error);
      navigate(createPageUrl('Landing'));
    }
    setLoading(false);
  };

  const saveSettings = async () => {
    try {
      await User.updateMyUserData({
        distance_preference: settings.distance_preference,
        age_preference_min: settings.age_preference_min,
        age_preference_max: settings.age_preference_max,
        notifications_matches: settings.notifications_matches,
        notifications_messages: settings.notifications_messages,
        notifications_likes: settings.notifications_likes,
        show_age: settings.show_age,
        show_distance: settings.show_distance,
        discovery_enabled: settings.discovery_enabled
      });
      alert(language === 'he' ? 'ההגדרות נשמרו בהצלחה!' : 'ቅንብሮቹ በተሳካ ሁኔታ ተቀምጠዋል!');
    } catch (error) {
      console.error('Error saving settings:', error);
      alert(language === 'he' ? 'שגיאה בשמירת הגדרות. אנא נסה שוב.' : 'ቅንብሮችን ማስቀመጥ ላይ ስህተት። እባክዎ እንደገና ይሞክሩ።');
    }
  };

  const handleLogout = async () => {
    try {
      await User.logout();
      localStorage.clear(); // Clear all local storage to ensure a clean session
      window.location.href = createPageUrl('Welcome');
    } catch (error) {
      console.error('Error logging out:', error);
      localStorage.clear(); // Also clear on error
      window.location.href = createPageUrl('Welcome');
    }
  };

  const handleForceMatch = () => {
    localStorage.setItem('forceNextMatch', 'true');
    alert(language === 'he' ? 'ההתאמה הבאה מובטחת!' : 'Next match is guaranteed!');
  };

  const handleBoostEffect = () => {
    localStorage.setItem('hasBoostEffect', 'true');
    alert(language === 'he' ? 'אפקט בוסט הופעל! (למשך 10 דקות)' : 'Boost effect activated! (for 10 minutes)');
  };

  const createDemoMatches = async () => {
    try {
      const user = await User.me();
      
      // Get all real users from the system (excluding demo users)
      const allUsers = await User.list('', 100); 
      const realUsers = allUsers.filter(u => 
        u.id !== user.id && 
        u.onboarding_completed && 
        u.chosen_name
      );
      
      if (realUsers.length === 0) {
        alert('אין משתמשים אמיתיים זמינים להתאמה במערכת');
        return;
      }
      
      // Create matches with first available real user
      const targetUser = realUsers[0];
      
      // Check if match already exists - FIXED QUERY
      const existingMatch = await Match.filter({
        $or: [
          { user1_id: user.id, user2_id: targetUser.id },
          { user1_id: targetUser.id, user2_id: user.id }
        ]
      });

      if (existingMatch.length > 0) {
        alert(`כבר יש לך התאמה עם ${targetUser.chosen_name || targetUser.full_name}`);
        return;
      }

      // Create the match
      const newMatch = await Match.create({
        user1_id: user.id,
        user2_id: targetUser.id,
        status: 'matched',
        matched_at: new Date().toISOString(),
        is_super_like: Math.random() > 0.8 // 20% chance for super like
      });
      
      // Create a welcome message from the other user
      await Message.create({
        match_id: newMatch.id,
        sender_id: targetUser.id,
        content: 'היי! איך אתה? שמחתי שיש לנו התאמה! 😊',
        message_type: 'text',
        sent_at: new Date().toISOString(),
        read: false
      });
      
      alert(`נוצרה התאמה חדשה עם ${targetUser.chosen_name || targetUser.full_name}!`);
      
    } catch (error) {
      console.error('Error creating test match:', error);
      alert('שגיאה ביצירת התאמה לבדיקה');
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-[#F7F4FB] to-[#ECE3F5]">
        <Loader2 className="w-12 h-12 text-[#7B3FA3] animate-spin" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#F7F4FB] to-[#ECE3F5] pb-32">
      {/* Simple header with title and back button */}
      <div className="flex items-center justify-between p-4 pb-6">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="rounded-full bg-white shadow-sm hover:bg-gray-50">
          <ChevronLeft className="w-5 h-5 text-gray-700" />
        </Button>
        <h1 className="text-2xl font-bold text-[#3F2044]">הגדרות</h1>
        <div className="w-10"></div> {/* Spacer for centering */}
      </div>
      
      <main className="p-4 space-y-6">
        {/* Premium Upgrade Section */}
        <Section title={t('upgradeToPremium', language)} icon={Crown}>
          <div className="bg-gradient-to-r from-[#7B3FA3] to-[#E7B6E1] rounded-2xl p-6 text-white">
            <div className="flex items-center gap-3 mb-4">
              <Crown className="w-8 h-8" />
              <div>
                <h3 className="text-xl font-bold">{t('upgradeToPremium', language)}</h3>
                <p className="text-purple-100 text-sm">חוויה משופרת ללא הגבלות</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 mb-4 text-sm">
              <div className="flex items-center gap-2">
                <Heart className="w-4 h-4" />
                <span>{t('unlimitedLikes', language)}</span>
              </div>
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4" />
                <span>{t('incognitoMode', language)}</span>
              </div>
              <div className="flex items-center gap-2">
                <Eye className="w-4 h-4" />
                <span>ראה מי עשה לך לייק</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin className="w-4 h-4" />
                <span>5 סופר לייקים ביום</span>
              </div>
            </div>

            <Link to={createPageUrl('Premium')}>
              <Button className="w-full bg-white text-purple-600 hover:bg-gray-50 font-semibold rounded-xl">
                {language === 'he' ? 'שדרג לפרימיום - ₪19.98/חודש' : 'ወደ ፕሪሚየም ሻሽ - ₪19.98/ወር'}
              </Button>
            </Link>
          </div>
        </Section>

        {/* Discovery Preferences */}
        <Section title={t('discoveryPreferences', language)} icon={Heart}>
          <div className="space-y-6">
            {/* Distance Preference */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="font-bold text-gray-800 text-lg">{language === 'he' ? 'מרחק מקסימלי' : 'ከፍተኛ ርቀት'}</label>
                <span className="text-xl font-bold text-[#7B3FA3] bg-purple-100 px-4 py-2 rounded-full border border-purple-200">
                  {settings.distance_preference} {language === 'he' ? 'ק״מ' : 'ኪ.ሜ'}
                </span>
              </div>
              <Slider
                value={[settings.distance_preference]}
                onValueChange={([value]) => setSettings(prev => ({ ...prev, distance_preference: value }))}
                min={1}
                max={100}
                step={1}
                className="w-full"
                dir='ltr'
              />
              <div className="text-center p-4 bg-purple-50 rounded-xl border border-purple-200">
                <p className="text-sm text-purple-800 font-semibold">
                  {language === 'he'
                    ? `יוצגו לך אנשים במרחק של עד ${settings.distance_preference} ק"מ ממך`
                    : `እስከ ${settings.distance_preference} ኪ.ሜ ርቀት ያሉ ሰዎች ይታያሉ`
                  }
                </p>
              </div>
            </div>

            {/* Age Range */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <label className="font-bold text-gray-800 text-lg">{language === 'he' ? 'טווח גילאים' : 'የእድሜ ክልል'}</label>
                <span className="text-xl font-bold text-[#7B3FA3] bg-purple-100 px-4 py-2 rounded-full border border-purple-200">
                  {settings.age_preference_min} - {settings.age_preference_max}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-3">
                    {language === 'he' ? 'גיל מינימום' : 'ዝቅተኛ ዕድሜ'}
                  </label>
                  <Select
                    value={settings.age_preference_min?.toString()}
                    onValueChange={(value) => setSettings(prev => ({ ...prev, age_preference_min: parseInt(value) }))}
                  >
                    <SelectTrigger className="rounded-xl h-12 border-2 border-purple-200 bg-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({length: 44}, (_, i) => i + 18).map(age => (
                        <SelectItem key={age} value={age.toString()}>{age}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-bold text-gray-700 mb-3">
                    {language === 'he' ? 'גיל מקסימום' : 'ከፍተኛ ዕድሜ'}
                  </label>
                  <Select
                    value={settings.age_preference_max?.toString()}
                    onValueChange={(value) => setSettings(prev => ({ ...prev, age_preference_max: parseInt(value) }))}
                  >
                    <SelectTrigger className="rounded-xl h-12 border-2 border-purple-200 bg-white">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {Array.from({length: 44}, (_, i) => i + 18).map(age => (
                        <SelectItem key={age} value={age.toString()}>{age}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </div>
        </Section>

        {/* Notifications */}
        <Section title={t('notifications', language)} icon={Bell}>
          <div className="space-y-4">
            {[
              { key: 'notifications_matches', label: language === 'he' ? 'התאמות חדשות' : 'አዲስ ተዛማጆች', icon: '💕' },
              { key: 'notifications_messages', label: language === 'he' ? 'הודעות חדשות' : 'አዲስ መልእክቶች', icon: '💬' },
              { key: 'notifications_likes', label: language === 'he' ? 'לייקים חדשים' : 'አዲስ ወዳጅነቶች', icon: '❤️' }
            ].map((item) => (
              <div key={item.key} className="flex items-center justify-between gap-4 p-4 bg-purple-50/60 rounded-2xl border border-purple-100">
                <div className="flex items-center gap-3 min-w-0">
                  <span className="text-2xl shrink-0">{item.icon}</span>
                  <span className="font-bold text-gray-800 text-base">{item.label}</span>
                </div>
                <div className="w-20 shrink-0">
                  <Button
                    onClick={() => setSettings(prev => ({ ...prev, [item.key]: !settings[item.key] }))}
                    size="sm"
                    className={`w-full h-10 transition-all duration-300 rounded-full font-bold text-sm ${
                      settings[item.key]
                        ? 'bg-gradient-to-r from-[#7B3FA3] to-[#E7B6E1] text-white shadow-md'
                        : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`}
                  >
                    {settings[item.key] ? (language === 'he' ? 'מופעל' : 'On') : (language === 'he' ? 'כבוי' : 'Off')}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* Privacy */}
        <Section title={t('privacy', language)} icon={Shield}>
          <div className="space-y-4">
            {[
              { key: 'show_age', label: language === 'he' ? 'הצג גיל בפרופיל' : 'በመገለጫ ላይ ዕድሜ አሳይ', icon: '🎂' },
              { key: 'show_distance', label: language === 'he' ? 'הצג מרחק בפרופיל' : 'በመገለጫ ላይ ርቀት አሳይ', icon: '📍' },
              { key: 'discovery_enabled', label: language === 'he' ? 'אפשר גילוי על ידי אחרים' : 'በሌሎች እንዲገኝ ተፈቅድ', icon: '👁️' }
            ].map((item) => (
              <div key={item.key} className="flex items-center justify-between gap-4 p-4 bg-purple-50/60 rounded-2xl border border-purple-100">
                <div className="flex items-center gap-3 min-w-0">
                  <span className="text-2xl shrink-0">{item.icon}</span>
                  <span className="font-bold text-gray-800 text-base">{item.label}</span>
                </div>
                <div className="w-20 shrink-0">
                  <Button
                    onClick={() => setSettings(prev => ({ ...prev, [item.key]: !settings[item.key] }))}
                    size="sm"
                    className={`w-full h-10 transition-all duration-300 rounded-full font-bold text-sm ${
                      settings[item.key]
                        ? 'bg-gradient-to-r from-[#7B3FA3] to-[#E7B6E1] text-white shadow-md'
                        : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                    }`}
                  >
                    {settings[item.key] ? (language === 'he' ? 'מופעל' : 'On') : (language === 'he' ? 'כבוי' : 'Off')}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </Section>

        {/* Developer Tools - Only for Admins */}
        {user?.role === 'admin' && (
          <Section title={language === 'he' ? 'כלי מפתחים' : 'የገንቢ መሳሪያዎች'} icon={Wand2}>
            <div className="space-y-3">
              <Button
                variant="outline"
                className="w-full justify-start gap-3 rounded-xl border-2 border-purple-200 hover:bg-purple-50 h-12 text-base font-semibold bg-white"
                onClick={handleForceMatch}
              >
                <Heart className="w-5 h-5 text-red-500" />
                {language === 'he' ? 'צור התאמה לבדיקה (הלייק הבא יהיה מאץ\')' : 'የፈተና ግጥሚያ ፍጠር (ቀጣዩ ላይክ ግጥሚያ ይሆናል)'}
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start gap-3 rounded-xl border-2 border-purple-200 hover:bg-purple-50 h-12 text-base font-semibold bg-white"
                onClick={handleBoostEffect}
              >
                <Crown className="w-5 h-5 text-yellow-500" />
                {language === 'he' ? 'הפעל בוסט (לבדיקה)' : 'ማጎልበትን አንቃ (ለፈተና)'}
              </Button>
              <Button
                variant="outline"
                className="w-full justify-start gap-3 rounded-xl border-2 border-green-200 hover:bg-green-50 h-12 text-base font-semibold bg-white"
                onClick={createDemoMatches}
              >
                <MessageCircle className="w-5 h-5 text-green-500" />
                {language === 'he' ? 'צור התאמות וצ\'אט לבדיקה' : 'የፈተና ግጥሚያዎችና ቻት ፍጠር'}
              </Button>
            </div>
          </Section>
        )}

        {/* Other Options */}
        <Section title={language === 'he' ? 'אפשרויות נוספות' : 'ሌሎች አማራጮች'} icon={Globe}>
          <div className="space-y-3">
            <div className="flex items-center justify-between gap-4 p-4 hover:bg-purple-50 rounded-xl cursor-pointer transition-colors duration-200 border border-purple-100 bg-white">
              <div className="flex items-center gap-3 min-w-0">
                <Globe className="w-6 h-6 text-gray-600 shrink-0" />
                <span className="font-bold text-base text-gray-800">{t('language', language)}</span>
              </div>
              <div className="shrink-0">
                <LanguageSelector showLabel={false} />
              </div>
            </div>

            <Link to={createPageUrl('Help')}>
              <div className="flex items-center justify-between gap-4 p-4 hover:bg-purple-50 rounded-xl cursor-pointer transition-colors duration-200 border border-purple-100 bg-white">
                <div className="flex items-center gap-3 min-w-0">
                  <HelpCircle className="w-6 h-6 text-gray-600 shrink-0" />
                  <span className="font-bold text-base text-gray-800">{t('helpSupport', language)}</span>
                </div>
                <ChevronLeft className="text-gray-400 shrink-0 w-5 h-5" />
              </div>
            </Link>

            <Link to={createPageUrl('Terms')}>
              <div className="flex items-center justify-between gap-4 p-4 hover:bg-purple-50 rounded-xl cursor-pointer transition-colors duration-200 border border-purple-100 bg-white">
                <div className="flex items-center gap-3 min-w-0">
                  <Shield className="w-6 h-6 text-gray-600 shrink-0" />
                  <span className="font-bold text-base text-gray-800">{t('termsPrivacy', language)}</span>
                </div>
                <ChevronLeft className="text-gray-400 shrink-0 w-5 h-5" />
              </div>
            </Link>
          </div>
        </Section>

        {/* Save Settings and Logout */}
        <div className="space-y-4 pt-4">
          <Button
            onClick={saveSettings}
            className="w-full bg-gradient-to-r from-[#7B3FA3] to-[#E7B6E1] hover:from-[#7B3FA3]/90 hover:to-[#E7B6E1]/90 text-white font-bold py-4 text-lg shadow-xl rounded-2xl"
            size="lg"
          >
            {t('save', language)}
          </Button>

          <Button
            onClick={handleLogout}
            variant="outline"
            className="w-full border-2 border-red-300 text-red-600 hover:bg-red-50 hover:border-red-400 font-bold py-4 text-lg rounded-2xl bg-white"
            size="lg"
          >
            <LogOut className="ml-2 h-5 w-5" />
            {t('logout', language)}
          </Button>
        </div>

        {/* Bottom Spacing */}
        <div className="h-6"></div>
      </main>
    </div>
  );
}
