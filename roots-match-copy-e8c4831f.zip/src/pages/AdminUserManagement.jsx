
import React, { useState, useEffect } from 'react';
import { User, VerificationRequest } from '@/api/entities';
import { PublicProfile } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { RefreshCw, AlertCircle } from 'lucide-react'; // Add AlertCircle import
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import VerificationModal from '../components/admin/VerificationModal';
import { useLanguage } from '../components/language/LanguageContext';
import { ScrollArea } from '@/components/ui/scroll-area';

export default function AdminUserManagement() {
  const [users, setUsers] = useState([]);
  const [pendingVerifications, setPendingVerifications] = useState([]); // Added state for pending verification requests
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState(null); // Can be a User object or a VerificationRequest object
  const [isVerificationModalOpen, setIsVerificationModalOpen] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [syncLog, setSyncLog] = useState([]);
  const navigate = useNavigate();
  const { language } = useLanguage();

  useEffect(() => {
    const fetchUsersAndRequests = async () => {
      setLoading(true);
      setError(null);

      try {
        const currentUser = await User.me();
        if (currentUser.role !== 'admin') {
          navigate(createPageUrl('Discover'));
          return;
        }

        const allUsers = await User.list('', 1000);
        setUsers(allUsers);

        // Load pending verification requests
        const pendingRequests = await VerificationRequest.filter({ status: 'pending' }, '-created_date');
        const enrichedRequests = await Promise.all(
          pendingRequests.map(async (request) => {
            const user = allUsers.find(u => u.id === request.user_id);
            // Ensure user exists, otherwise skip this request
            if (!user) {
              console.warn(`User with ID ${request.user_id} not found for verification request ${request.id}. Skipping.`);
              return null;
            }
            return { ...request, user };
          })
        );
        // Filter out any requests where the user was not found
        setPendingVerifications(enrichedRequests.filter(Boolean));

      } catch (error) {
        console.error('Error fetching admin data:', error);
        setError('שגיאה בטעינת נתונים');
        if (error.message?.includes('403') || error.message?.includes('unauthorized')) {
          navigate(createPageUrl('Landing'));
        }
      } finally {
        setLoading(false);
      }
    };

    fetchUsersAndRequests();
  }, [navigate]);

  const filteredUsers = users.filter(user =>
    user.full_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
    user.email?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleCloseVerificationModal = () => {
    setSelectedUser(null);
    setIsVerificationModalOpen(false);
  };

  // Handles direct user verification/unverification from the main user table (admin manually changing user's verified status)
  const handleDirectUserVerification = async (user, status) => {
    try {
      const verifiedStatus = status === 'approved';
      await User.update(user.id, { verified: verifiedStatus });

      // Update local state for users
      setUsers(prevUsers => prevUsers.map(u =>
        u.id === user.id ? { ...u, verified: verifiedStatus } : u
      ));
      handleCloseVerificationModal();
      alert(`המשתמש ${user.full_name || user.email} ${verifiedStatus ? 'אומת' : 'בוטל אימותו'} בהצלחה.`);
    } catch (error) {
      console.error(`Error ${status === 'approved' ? 'verifying' : 'unverifying'} user directly:`, error);
      alert(`שגיאה ב${status === 'approved' ? 'אימות' : 'ביטול אימות'} המשתמש`);
    }
  };

  // Handles verification actions for explicit verification requests (from the pending requests section)
  const handleVerificationAction = async (request, status) => { // This function is designed to handle a VerificationRequest object
    try {
      const verifiedStatus = status === 'approved';

      // Update user verification status
      await User.update(request.user_id, { verified: verifiedStatus });

      // Update verification request status - FIXED: only pass the status field
      await VerificationRequest.update(request.id, { status: status });

      // Update local states for users and pending requests
      setUsers(prevUsers => prevUsers.map(u =>
        u.id === request.user_id ? { ...u, verified: verifiedStatus } : u
      ));

      setPendingVerifications(prev => prev.filter(r => r.id !== request.id));

      handleCloseVerificationModal();

      alert(`פרופיל ${verifiedStatus ? 'אומת' : 'נדחה'} בהצלחה!`);
    } catch (error) {
      console.error(`Error ${status === 'approved' ? 'verifying' : 'rejecting'} user verification request:`, error);
      alert(`שגיאה ב${status === 'approved' ? 'אימות' : 'דחיית'} הפרופיל`);
    }
  };

  // Opens modal for direct user verification (from main user table)
  const handleVerificationClick = (user) => {
    setSelectedUser(user); // selectedUser is a User object
    setIsVerificationModalOpen(true);
  };

  // Opens modal for quick verification from pending requests section (clicking on image)
  const handleQuickVerification = (request) => {
    setSelectedUser(request); // selectedUser is now a VerificationRequest object
    setIsVerificationModalOpen(true);
  };

  const handleSyncPublicProfiles = async () => {
    setSyncing(true);
    setSyncLog([]);
    const log = (message) => setSyncLog(prev => [...prev, message]);

    try {
      log('מתחיל סנכרון...');
      const allUsers = await User.list('', 1000);
      const publicProfiles = await PublicProfile.list('', 1000);
      const publicProfileMap = new Map(publicProfiles.map(p => [p.user_id, p]));

      log(`נמצאו ${allUsers.length} משתמשים ו-${publicProfiles.length} פרופילים ציבוריים.`);

      for (const user of allUsers) {
        if (!user.onboarding_completed) {
          log(`דילוג על משתמש ${user.email} (לא סיים הרשמה).`);
          continue;
        }

        // Ensure we have a chosen_name - use full_name as fallback
        const displayName = user.chosen_name || user.full_name || 'משתמש ללא שם';

        const publicProfileData = {
          user_id: user.id,
          chosen_name: displayName,
          age: user.age || 25, // Provide default age if missing
          bio: user.bio || '',
          photos: user.photos || [],
          location: user.location || '',
          interests: user.interests || [],
          latitude: user.latitude || null,
          longitude: user.longitude || null,
          generation_in_israel: user.generation_in_israel || '',
          religion: user.religion || '',
          shabbat_observance: user.shabbat_observance || '',
          kashrut_observance: user.kashrut_observance || '',
          family_plans: user.family_plans || '',
          verified: user.verified || false,
          is_premium: user.is_premium || false,
          last_active: user.last_active || new Date().toISOString(),
        };

        const existingProfile = publicProfileMap.get(user.id);
        if (existingProfile) {
          log(`מעדכן פרופיל ציבורי עבור ${user.email}...`);
          await PublicProfile.update(existingProfile.id, publicProfileData);
        } else {
          log(`יוצר פרופיל ציבורי חדש עבור ${user.email}...`);
          await PublicProfile.create(publicProfileData);
        }
      }
      log('✅ סנכרון הושלם בהצלחה!');
      alert('סנכרון הפרופילים הציבוריים הושלם בהצלחה!');
    } catch (error) {
      log(`❌ אירעה שגיאה במהלך הסנכרון: ${error.message}`);
      alert(`אירעה שגיאה במהלך הסנכרון: ${error.message}`);
    } finally {
      setSyncing(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-purple-500 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-gray-600">טוען נתוני ניהול...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <div className="text-red-500 text-xl mb-4">⚠️</div>
          <p className="text-gray-600 mb-4">{error}</p>
          <Button onClick={() => window.location.reload()}>
            נסה שוב
          </Button>
        </div>
      </div>
    );
  }

  // Determine if selectedUser is a VerificationRequest object or a User object
  // A VerificationRequest object is expected to have 'user_id', 'status', and 'photo_url'
  const isSelectedUserAVerificationRequest = selectedUser && selectedUser.user_id && selectedUser.status && selectedUser.photo_url;

  // Props to pass to VerificationModal based on the type of selectedUser
  const modalUserProp = isSelectedUserAVerificationRequest ? selectedUser.user : selectedUser;
  const modalRequestProp = isSelectedUserAVerificationRequest ? selectedUser : null;
  const modalOnActionProp = (status) => {
    if (isSelectedUserAVerificationRequest) {
      // If selectedUser is a request, use the request-specific handler
      handleVerificationAction(selectedUser, status);
    } else {
      // Otherwise, it's a direct user, use the direct user handler
      handleDirectUserVerification(selectedUser, status);
    }
  };


  return (
    <div className="p-6" dir={language === 'he' ? 'rtl' : 'ltr'}>
      <h1 className="text-2xl font-bold mb-6">ניהול משתמשים</h1>

      {/* Verification Requests Section */}
      {pendingVerifications.length > 0 && (
        <Card className="mb-6 border-orange-200 bg-orange-50">
          <CardHeader>
            <CardTitle className="text-lg text-orange-800 flex items-center gap-2">
              <AlertCircle className="w-5 h-5" />
              בקשות אימות ממתינות ({pendingVerifications.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {pendingVerifications.map(request => (
                <div key={request.id} className="bg-white rounded-lg border p-4 shadow-sm">
                  <div className="flex items-center gap-3 mb-3">
                    <img
                      src={request.user?.photos?.[0] || 'https://via.placeholder.com/50'}
                      alt="Profile"
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div>
                      <h4 className="font-semibold">{request.user?.full_name || request.user?.chosen_name || 'משתמש לא ידוע'}</h4>
                      <p className="text-sm text-gray-600">{request.user?.email || 'אימייל לא ידוע'}</p>
                    </div>
                  </div>

                  <div className="mb-3">
                    <img
                      src={request.photo_url}
                      alt="Verification"
                      className="w-full h-32 object-cover rounded-lg cursor-pointer hover:opacity-80"
                      onClick={() => handleQuickVerification(request)}
                    />
                  </div>

                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleVerificationAction(request, 'rejected')}
                      className="flex-1"
                    >
                      ❌ דחה
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleVerificationAction(request, 'approved')}
                      className="flex-1 bg-green-600 hover:bg-green-700"
                    >
                      ✅ אשר
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="mb-6 bg-white p-4 rounded-lg shadow-md border">
        <h2 className="text-lg font-semibold mb-3">פעולות מערכת</h2>
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
          <Button onClick={handleSyncPublicProfiles} disabled={syncing} className="bg-purple-600 hover:bg-purple-700">
            {syncing ? (
              <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <RefreshCw className="w-4 h-4 mr-2" />
            )}
            {syncing ? 'מסנכרן...' : 'סנכרן פרופילים ציבוריים'}
          </Button>
          <p className="text-sm text-gray-600">
            לחץ כאן כדי לוודא שלכל המשתמשים יש פרופיל ציבורי תקין.
          </p>
        </div>
        {syncLog.length > 0 && (
          <div className="mt-4 p-3 bg-gray-50 rounded-md border max-h-40 overflow-y-auto">
            <h3 className="font-semibold mb-2">יומן סנכרון:</h3>
            <div className="text-xs text-gray-700 space-y-1">
              {syncLog.map((entry, index) => (
                <p key={index}>{entry}</p>
              ))}
            </div>
          </div>
        )}
      </div>

      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="text-lg">רשימת משתמשים ({filteredUsers.length})</CardTitle>
            <Input
              placeholder="חפש משתמש..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-xs"
            />
          </div>
        </CardHeader>
        <CardContent>
          {users.length > 0 ? (
            <ScrollArea className="h-[calc(100vh-250px)]">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-[180px]">שם מלא</TableHead>
                    <TableHead>אימייל</TableHead>
                    <TableHead>תפקיד</TableHead>
                    <TableHead>סטטוס אימות</TableHead>
                    <TableHead className="text-right">פעולות</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map(user => (
                    <TableRow key={user.id}>
                      <TableCell className="font-medium">{user.full_name || 'שם לא זמין'}</TableCell>
                      <TableCell>{user.email || 'אימייל לא זמין'}</TableCell>
                      <TableCell>
                        {user.role === 'admin' ? (
                          <Badge variant="destructive" className="text-xs">מנהל</Badge>
                        ) : (
                          <Badge variant="secondary" className="text-xs">משתמש</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {user.verified ? (
                          <Badge variant="default" className="text-xs bg-green-500 hover:bg-green-600">מאומת</Badge>
                        ) : (
                          <Badge variant="outline" className="text-xs">לא מאומת</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleVerificationClick(user)}
                        >
                          {user.verified ? 'בטל אימות' : 'אמת'}
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </ScrollArea>
          ) : (
            <div className="text-center py-8">
              <div className="text-4xl mb-4">👥</div>
              <p className="text-gray-500">אין משתמשים רשומים במערכת.</p>
            </div>
          )}
        </CardContent>
      </Card>

      {selectedUser && (
        <VerificationModal
          isOpen={isVerificationModalOpen}
          onClose={handleCloseVerificationModal}
          // Pass props dynamically based on the type of selectedUser
          request={modalRequestProp}
          user={modalUserProp}
          onAction={modalOnActionProp}
        />
      )}
    </div>
  );
}
