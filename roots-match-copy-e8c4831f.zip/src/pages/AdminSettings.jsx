
import React, { useState, useEffect } from 'react';
import { User, Purchase } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ArrowRight, Users, Crown, PieChart as PieChartIcon, Loader2, DollarSign, Calendar, TrendingUp, Menu, X } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { useLanguage } from '../components/language/LanguageContext';

export default function AdminSettings() {
  const [stats, setStats] = useState({ 
    freeUsers: 0, 
    premiumUsers: 0,
    totalRevenue: 0,
    monthlyRevenue: 0,
    purchases: [],
    planStats: []
  });
  const [loading, setLoading] = useState(true);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const navigate = useNavigate();
  const { language } = useLanguage();

  useEffect(() => {
    const checkAdminAndFetchData = async () => {
      setLoading(true);
      try {
        const currentUser = await User.me();
        if (currentUser.role !== 'admin') {
          navigate(createPageUrl('Landing'));
          return;
        }
        
        const [allUsers, allPurchases] = await Promise.all([
          User.list('', 10000), // Get real data from database
          Purchase.list('-purchase_date', 1000)
        ]);

        const userStats = allUsers.reduce(
          (acc, user) => {
            if (user.is_premium) {
              acc.premiumUsers += 1;
            } else {
              acc.freeUsers += 1;
            }
            return acc;
          },
          { freeUsers: 0, premiumUsers: 0 }
        );

        // חישוב הכנסות
        const totalRevenue = allPurchases
          .filter(p => p.status === 'completed')
          .reduce((sum, p) => sum + p.amount, 0);

        // הכנסות החודש הנוכחי
        const currentMonth = new Date().getMonth();
        const currentYear = new Date().getFullYear();
        const monthlyRevenue = allPurchases
          .filter(p => {
            const purchaseDate = new Date(p.purchase_date);
            return p.status === 'completed' && 
                   purchaseDate.getMonth() === currentMonth && 
                   purchaseDate.getFullYear() === currentYear;
          })
          .reduce((sum, p) => sum + p.amount, 0);

        // סטטיסטיקות חבילות
        const planStats = allPurchases
          .filter(p => p.status === 'completed')
          .reduce((acc, purchase) => {
            const existing = acc.find(item => item.plan_type === purchase.plan_type);
            if (existing) {
              existing.count += 1;
              existing.revenue += purchase.amount;
            } else {
              acc.push({
                plan_type: purchase.plan_type,
                plan_name: purchase.plan_name,
                count: 1,
                revenue: purchase.amount
              });
            }
            return acc;
          }, []);

        setStats({
          // FIX: Ensure stats default to 0 if null/undefined
          freeUsers: userStats.freeUsers || 0,
          premiumUsers: userStats.premiumUsers || 0,
          totalRevenue: totalRevenue || 0,
          monthlyRevenue: monthlyRevenue || 0,
          purchases: allPurchases.slice(0, 10),
          planStats
        });
      } catch (error) {
        console.error('Error fetching admin data:', error);
        navigate(createPageUrl('Landing'));
      }
      setLoading(false);
    };

    // Remove the demo admin logic completely
    checkAdminAndFetchData();
  }, [navigate]);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-gray-50 to-purple-50">
        <div className="text-center p-8">
          <Loader2 className="w-16 h-16 text-purple-600 animate-spin mx-auto mb-6" />
          <p className="text-gray-700 font-medium text-lg">טוען סטטיסטיקות...</p>
          <p className="text-gray-500 text-sm mt-2">מעבד נתוני המערכת...</p>
        </div>
      </div>
    );
  }

  const pieData = [
    { name: 'משתמשים בחינם', value: stats.freeUsers },
    { name: 'משתמשי פרימיום', value: stats.premiumUsers },
  ];
  const COLORS = ['#94A3B8', '#8B5CF6'];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-purple-50" dir={language === 'he' ? 'rtl' : 'ltr'}>
      {/* Mobile Header */}
      <div className="lg:hidden bg-white shadow-sm border-b border-gray-200 px-4 py-3 sticky top-0 z-50">
        <div className="flex items-center justify-between">
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="p-2 rounded-lg hover:bg-gray-100 transition-colors"
          >
            {isMobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
          <h1 className="text-lg font-bold text-gray-800">הגדרות וסטטיסטיקה</h1>
          <Link to={createPageUrl('AdminDashboard')}>
            <Button size="sm" variant="outline" className="text-xs px-3">
              <ArrowRight className="w-4 h-4 mr-1" />
              חזור
            </Button>
          </Link>
        </div>
        
        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="absolute top-full left-0 right-0 bg-white border-b border-gray-200 p-4 space-y-2">
            <Link to={createPageUrl('AdminDashboard')} className="block p-2 text-gray-700 hover:bg-gray-100 rounded-lg">
              לוח בקרה ראשי
            </Link>
            <Link to={createPageUrl('AdminUserManagement')} className="block p-2 text-gray-700 hover:bg-gray-100 rounded-lg">
              ניהול משתמשים
            </Link>
          </div>
        )}
      </div>

      {/* Desktop Header */}
      <div className="hidden lg:block bg-white shadow-sm border-b border-gray-200 px-8 py-6">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-800 mb-2">הגדרות וסטטיסטיקה</h1>
            <p className="text-gray-600">מעקב אחר ביצועי האפליקציה והכנסות</p>
          </div>
          <Link to={createPageUrl('AdminDashboard')}>
            <Button variant="outline" className="px-6 py-3">
              <ArrowRight className="mr-2 h-5 w-5" />
              חזור ללוח הבקרה
            </Button>
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div className="p-4 lg:p-8 max-w-7xl mx-auto">
        {/* סטטיסטיקות עיקריות */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6 mb-6 lg:mb-8">
          <Card className="shadow-lg border-0 bg-gradient-to-br from-white to-gray-50 hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">משתמשים בחינם</CardTitle>
              <div className="p-2 bg-gray-100 rounded-full">
                <Users className="h-4 w-4 text-gray-600" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl lg:text-3xl font-bold text-gray-800">{stats.freeUsers.toLocaleString()}</div>
              <p className="text-xs text-gray-500 mt-1">
                משתמשים שלא שדרגו למנוי
              </p>
            </CardContent>
          </Card>
          
          <Card className="shadow-lg border-0 bg-gradient-to-br from-purple-50 to-purple-100 hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-purple-800">משתמשי פרימיום</CardTitle>
              <div className="p-2 bg-purple-200 rounded-full">
                <Crown className="h-4 w-4 text-purple-700" />
              </div>
            </CardHeader>
            <CardContent>
              {/* FIX: Use toLocaleString() for consistency, which works fine with 0 */}
              <div className="text-2xl lg:text-3xl font-bold text-purple-900">{stats.premiumUsers.toLocaleString()}</div>
              <p className="text-xs text-purple-700 mt-1">
                משתמשים עם מנוי פעיל
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg border-0 bg-gradient-to-br from-green-50 to-green-100 hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-green-800">הכנסות כוללות</CardTitle>
              <div className="p-2 bg-green-200 rounded-full">
                <DollarSign className="h-4 w-4 text-green-700" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl lg:text-3xl font-bold text-green-900">₪{stats.totalRevenue.toLocaleString()}</div>
              <p className="text-xs text-green-700 mt-1">
                הכנסות מכל הזמנים
              </p>
            </CardContent>
          </Card>

          <Card className="shadow-lg border-0 bg-gradient-to-br from-blue-50 to-blue-100 hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-blue-800">הכנסות החודש</CardTitle>
              <div className="p-2 bg-blue-200 rounded-full">
                <TrendingUp className="h-4 w-4 text-blue-700" />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-2xl lg:text-3xl font-bold text-blue-900">₪{stats.monthlyRevenue.toLocaleString()}</div>
              <p className="text-xs text-blue-700 mt-1">
                הכנסות החודש הנוכחי
              </p>
            </CardContent>
          </Card>
        </div>

        {/* גרפים */}
        <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 lg:gap-8 mb-6 lg:mb-8">
          {/* פילוח משתמשים */}
          <Card className="shadow-lg border-0 bg-white hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-lg lg:text-xl font-semibold text-gray-800">
                <div className="p-2 bg-purple-100 rounded-full">
                  <PieChartIcon className="w-5 h-5 lg:w-6 lg:h-6 text-purple-600" />
                </div>
                פילוח משתמשים
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px] lg:h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={pieData}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      outerRadius="80%"
                      fill="#8884d8"
                      dataKey="value"
                      label={({ name, percent }) => `${(percent * 100).toFixed(0)}%`}
                    >
                      {pieData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value, name) => [value, name]}
                      contentStyle={{
                          background: 'rgba(255, 255, 255, 0.95)',
                          backdropFilter: 'blur(10px)',
                          border: '1px solid rgba(0,0,0,0.1)',
                          borderRadius: '12px',
                          boxShadow: '0 8px 32px rgba(0,0,0,0.1)'
                      }}
                    />
                    <Legend 
                      iconType="circle" 
                      wrapperStyle={{ fontSize: '14px' }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>

          {/* סטטיסטיקות חבילות */}
          <Card className="shadow-lg border-0 bg-white hover:shadow-xl transition-shadow duration-300">
            <CardHeader className="pb-4">
              <CardTitle className="flex items-center gap-2 text-lg lg:text-xl font-semibold text-gray-800">
                <div className="p-2 bg-blue-100 rounded-full">
                  <Calendar className="w-5 h-5 lg:w-6 lg:h-6 text-blue-600" />
                </div>
                פופולריות חבילות
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[250px] lg:h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={stats.planStats} margin={{ top: 20, right: 30, left: 20, bottom: 60 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                    <XAxis 
                      dataKey="plan_name" 
                      tick={{ fontSize: 12 }}
                      angle={-45}
                      textAnchor="end"
                      height={80}
                      stroke="#666"
                    />
                    <YAxis stroke="#666" />
                    <Tooltip 
                      formatter={(value) => [`${value} רכישות`, 'מספר רכישות']}
                      contentStyle={{
                          background: 'rgba(255, 255, 255, 0.95)',
                          backdropFilter: 'blur(10px)',
                          border: '1px solid rgba(0,0,0,0.1)',
                          borderRadius: '12px',
                          boxShadow: '0 8px 32px rgba(0,0,0,0.1)'
                      }}
                    />
                    <Bar 
                      dataKey="count" 
                      fill="#8B5CF6" 
                      name="count" 
                      radius={[4, 4, 0, 0]}
                    />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* טבלת חבילות מפורטת */}
        <Card className="shadow-lg border-0 bg-white hover:shadow-xl transition-shadow duration-300">
          <CardHeader className="pb-4">
            <CardTitle className="text-lg lg:text-xl font-semibold text-gray-800">
              פירוט חבילות והכנסות
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b-2 border-gray-200 bg-gray-50">
                    <th className="text-right py-4 px-4 font-semibold text-gray-700">חבילה</th>
                    <th className="text-right py-4 px-4 font-semibold text-gray-700">רכישות</th>
                    <th className="text-right py-4 px-4 font-semibold text-gray-700">הכנסות כוללות</th>
                    <th className="text-right py-4 px-4 font-semibold text-gray-700">ממוצע לרכישה</th>
                  </tr>
                </thead>
                <tbody>
                  {stats.planStats.map((plan, index) => (
                    <tr key={index} className="border-b border-gray-100 hover:bg-gray-50/50 transition-colors">
                      <td className="py-4 px-4 font-medium text-gray-900">{plan.plan_name}</td>
                      <td className="py-4 px-4 text-gray-700">
                        <span className="bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium">
                          {plan.count}
                        </span>
                      </td>
                      <td className="py-4 px-4 text-green-600 font-semibold">
                        ₪{plan.revenue.toLocaleString()}
                      </td>
                      <td className="py-4 px-4 text-purple-600 font-medium">
                        ₪{(plan.revenue / plan.count).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                  {stats.planStats.length === 0 && (
                    <tr>
                      <td colSpan="4" className="py-12 text-center text-gray-500">
                        <div className="flex flex-col items-center gap-3">
                          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center">
                            <Calendar className="w-8 h-8 text-gray-400" />
                          </div>
                          <p className="text-lg font-medium">אין נתוני רכישות זמינים</p>
                          <p className="text-sm">כאשר משתמשים יבצעו רכישות, הנתונים יופיעו כאן</p>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
                {stats.planStats.length > 0 && (
                  <tfoot className="bg-gradient-to-r from-gray-50 to-gray-100 font-bold">
                    <tr className="border-t-2 border-gray-200">
                      <td className="py-4 px-4 text-gray-900">סה"כ</td>
                      <td className="py-4 px-4 text-blue-700">
                        {stats.planStats.reduce((sum, plan) => sum + plan.count, 0)}
                      </td>
                      <td className="py-4 px-4 text-green-700">
                        ₪{stats.planStats.reduce((sum, plan) => sum + plan.revenue, 0).toLocaleString()}
                      </td>
                      <td className="py-4 px-4 text-gray-500">-</td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
