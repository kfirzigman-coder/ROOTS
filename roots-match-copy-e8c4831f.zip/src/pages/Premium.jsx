
import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Star, Heart, Shield, RotateCcw, Zap, ArrowLeft, Gem, Eye, Users, Crown } from 'lucide-react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';

// Reusable Section Card (matching Profile page style)
const Section = React.forwardRef(({ title, icon: Icon, children, className }, ref) => (
  <motion.div
    ref={ref}
    className={`bg-white/80 backdrop-blur-lg rounded-3xl shadow-lg border border-purple-100/30 overflow-hidden ${className}`}
    initial={{ opacity: 0, y: 30 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ duration: 0.5, type: 'spring' }}
  >
    <div className="p-5 border-b border-purple-100/50">
      <div className="flex items-center gap-3">
        <Icon className="w-5 h-5 text-[#3F2044]" />
        <h2 className="text-lg font-bold text-[#3F2044]">{title}</h2>
      </div>
    </div>
    <div className="p-5">{children}</div>
  </motion.div>
));

export default function Premium() {
  const [selectedPlan, setSelectedPlan] = useState('plus_6_months'); // Default to most popular
  const [selectedSuperLikes, setSelectedSuperLikes] = useState(null);
  const navigate = useNavigate();

  // Added a language state for demonstration. In a real application, this would likely come from context or a global state management solution.
  const [language, setLanguage] = useState('he'); // 'he' for Hebrew, 'am' for Amharic

  const plans = {
    plus: [
      { id: 'plus_1_month', name: language === 'he' ? 'חודש' : 'አንድ ወር', price: 36.90, period: language === 'he' ? 'חודש' : 'ወር', popular: false, price_per_unit: language === 'he' ? '₪36.90 /לחודש' : '₪36.90 /በወር' },
      { id: 'plus_6_months', name: language === 'he' ? '6 חודשים' : '6 ወራት', price: 119.90, period: language === 'he' ? '6 חודשים' : '6 ወራት', popular: true, price_per_unit: language === 'he' ? '₪19.98 /לחודש' : '₪19.98 /በወር', discount: '45%' },
      { id: 'plus_12_months', name: language === 'he' ? 'שנה' : 'አንድ አመት', price: 179.90, period: language === 'he' ? 'שנה' : 'አንድ አመት', popular: false, price_per_unit: language === 'he' ? '₪14.99 /לחודש' : '₪14.99 /በወር', discount: '60%' },
    ],
    superLikes: [
      { id: 'sl_3', count: 3, total_price: 31.00, price_per: 10.33, popular: false, discount: null },
      { id: 'sl_15', count: 15, total_price: 99.90, price_per: 6.66, popular: true, discount: '11%' },
      { id: 'sl_30', count: 30, total_price: 159.90, price_per: 5.33, popular: false, discount: '32%' },
    ]
  };

  const features = [
    { icon: Heart, text: 'לייקים בלי הגבלה', description: 'החליקו ימינה כמה שתרצו' },
    { icon: RotateCcw, text: 'חזרות לאחור', description: 'בטלו את ההחלקה האחרונה שלכם' },
    { icon: Shield, text: 'גלישה בסתר', description: 'הופיעו רק לאנשים שעשיתם להם לייק' },
    { icon: Eye, text: 'מי עשה לי לייק', description: 'ראו מי אוהב אתכם לפני שתחליטו' },
    { icon: Zap, text: 'בוסט יומי', description: 'הופיעו בראש הרשימה למשך 30 דקות' },
    { icon: Users, text: 'חוויה ללא פרסומות', description: 'התרכזו במציאת התאמות' },
  ];
  
  const handleSelect = (type, id) => {
    if (type === 'plus') {
      setSelectedPlan(id);
      setSelectedSuperLikes(null);
    } else { // 'superLikes'
      setSelectedSuperLikes(id);
      setSelectedPlan(null);
    }
  };

  const handleContinue = () => {
    let planId = selectedSuperLikes || selectedPlan;
    if (!planId) return;

    let planData;
    if (planId.startsWith('sl_')) {
        planData = plans.superLikes.find(p => p.id === planId);
    } else {
        planData = plans.plus.find(p => p.id === planId);
    }

    if (!planData) return;
    
    const finalPrice = planData.total_price || planData.price;
    let planName;
    let finalPeriod;

    if (planId.startsWith('sl_')) {
        planName = language === 'he' ? `${planData.count} סופר לייקים` : `${planData.count} ሱፐር ላይኮች`;
        finalPeriod = language === 'he' ? 'רכישה חד פעמית' : 'አንድ ጊዜ ግዢ';
    } else {
        planName = language === 'he' ? `RootsMatch+ - ${planData.name}` : `RootsMatch+ - ${planData.name}`;
        finalPeriod = planData.period;
    }

    // Navigate to payment page with Israeli payment system
    if (planName && typeof finalPrice !== 'undefined' && finalPeriod) {
         const url = `Payment?planId=${planId}&planName=${encodeURIComponent(planName)}&price=${finalPrice}&period=${encodeURIComponent(finalPeriod)}&paymentType=israeli`;
         navigate(createPageUrl(url));
    }
  };
  
  const selectedDetails = selectedSuperLikes 
    ? plans.superLikes.find(p => p.id === selectedSuperLikes) 
    : plans.plus.find(p => p.id === selectedPlan);
  const totalPrice = selectedDetails ? (selectedDetails.total_price || selectedDetails.price).toFixed(2) : '0.00';

  return (
    <div className="min-h-full bg-gradient-to-br from-[#F7F4FB] to-[#ECE3F5] flex flex-col">
      {/* FIX: Header is now part of the scrollable content, not fixed */}
      <header className="p-4 flex items-center justify-between sticky top-0 bg-[#F7F4FB]/80 backdrop-blur-sm z-10">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={() => navigate(-1)} 
          className="rounded-full bg-white shadow-sm hover:bg-gray-50"
        >
          <ArrowLeft className="w-5 h-5 text-gray-700" />
        </Button>
        <h1 className="text-xl sm:text-2xl font-bold text-[#3F2044]">RootsMatch+</h1>
        <div className="w-10 h-10"></div> {/* Spacer to balance layout */}
      </header>

      {/* FIX: main content area is now the primary scroll container */}
      <main className="flex-1 overflow-y-auto p-4 space-y-6">
        <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-6">
            {/* Hero Section */}
            <Section title="שדרג לפרימיום" icon={Crown}>
              <div className="text-center">
                <div className="inline-flex items-center justify-center gap-2 mb-4">
                  <Gem className="w-8 h-8 text-purple-600" />
                  <h2 className="text-2xl font-bold bg-gradient-to-r from-purple-600 to-pink-500 bg-clip-text text-transparent">
                    RootsMatch+
                  </h2>
                </div>
                <p className="text-gray-600 text-lg px-4 font-medium">
                  {language === 'he' ? 'שדרגו את החוויה וקבלו גישה לתכונות בלעדיות' : 'ተሞክሮውን ያሻሽሉ እና ልዩ ባህሪያት ይደርሱባቸው'}
                </p>
              </div>
            </Section>
            
            {/* Subscription Plans */}
            <Section title="תוכניות מנוי" icon={Crown}>
              <div className="space-y-3 sm:space-y-4">
                {plans.plus.map((plan, index) => (
                  <motion.div 
                    key={plan.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    whileTap={{ scale: 0.98 }}
                    className={`relative p-3 sm:p-4 rounded-2xl border-2 cursor-pointer transition-all duration-300 ${
                      selectedPlan === plan.id 
                        ? 'border-purple-500 bg-purple-50 shadow-lg' 
                        : 'border-gray-200 bg-white hover:border-purple-300 hover:shadow-md'
                    }`}
                    onClick={() => handleSelect('plus', plan.id)}
                  >
                    {plan.popular && (
                      <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-purple-500 to-pink-500 text-white px-3 py-0.5 text-xs font-bold">
                        {language === 'he' ? 'הכי פופולרי' : 'በጣም ታዋቂ'}
                      </Badge>
                    )}
                    
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-1">{plan.name}</h3>
                        <p className="text-xs sm:text-sm text-purple-600 font-semibold">{plan.price_per_unit}</p>
                      </div>
                      <div className="text-left">
                        <p className="text-lg sm:text-xl font-bold text-gray-900">₪{plan.price.toFixed(2)}</p>
                        {plan.discount && (
                          <Badge className="bg-green-100 text-green-700 text-xs font-bold mt-1">
                            {language === 'he' ? `חסכו ${plan.discount}` : `${plan.discount} ቆጥብ`}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </Section>
          </div>

          <div className="space-y-6">
            {/* Features Section */}
            <Section title="מה כלול בפרימיום?" icon={Gem}>
              <div className="space-y-4">
                {features.map((feature, index) => (
                  <motion.div 
                    key={index}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.3 + index * 0.1 }}
                    className="flex items-center gap-4 p-4 bg-purple-50/50 rounded-2xl border border-purple-100"
                  >
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-100 to-pink-100 rounded-full flex items-center justify-center shrink-0">
                      <feature.icon className="w-6 h-6 text-purple-600" />
                    </div>
                    <div>
                      <p className="font-bold text-gray-900 text-base md:text-lg">{feature.text}</p>
                      <p className="text-sm text-gray-600 leading-relaxed font-medium">{feature.description}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </Section>

            {/* Super Likes Section */}
            <Section title="רכישת סופר לייקים" icon={Star}>
              <div className="mb-4 text-center">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Star className="w-6 h-6 text-blue-500 fill-current" />
                  <p className="text-lg font-bold text-blue-700">
                    {language === 'he' ? 'הגדילו את הסיכוי למאץ\' פי 3!' : 'የግጥሚያ እድሉን በ3 ጨምር!'}
                  </p>
                </div>
                <p className="text-gray-600 text-sm font-medium">
                  {language === 'he' ? 'סופר לייק מבטיח שהפרופיל שלכם יופיע בראש הרשימה' : 'ሱፐር ላይክ የእርስዎን መገለጫ በዝርዝሩ ጫፍ ላይ እንዲያሳይ ያረጋግጣል'}
                </p>
              </div>
              <div className="space-y-3">
                {plans.superLikes.map((plan, index) => (
                  <motion.div
                    key={plan.id}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.4 + index * 0.1 }}
                    className={`p-3 sm:p-4 rounded-2xl border-2 cursor-pointer transition-all duration-300 ${
                      selectedSuperLikes === plan.id
                        ? 'border-blue-500 bg-blue-50 shadow-lg'
                        : 'border-gray-200 bg-white hover:border-blue-300 hover:shadow-md'
                    }`}
                    onClick={() => handleSelect('superLikes', plan.id)}
                  >
                    {/* Tags */}
                    <div className="flex justify-between items-start mb-2 sm:mb-3">
                      {plan.popular && (
                        <Badge className="bg-blue-500 text-white text-xs px-2 py-0.5 sm:px-3 sm:py-1 font-bold">
                          {language === 'he' ? 'מומלץ' : 'ይመከራል'}
                        </Badge>
                      )}
                      {plan.discount && (
                        <Badge className="border-green-500 text-green-700 bg-green-100 text-xs px-2 py-0.5 sm:px-3 sm:py-1 font-bold">
                          {language === 'he' ? `חיסכון ${plan.discount}` : `${plan.discount} ቁጠባ`}
                        </Badge>
                      )}
                      {!plan.popular && !plan.discount && <div></div>}
                    </div>
                    
                    {/* Main Content */}
                    <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 sm:gap-3">
                            <Star className="w-6 h-6 sm:w-8 sm:h-8 text-blue-500 fill-current" />
                            <div>
                                <p className="font-bold text-lg sm:text-xl text-gray-900">{plan.count}</p>
                                <p className="text-blue-600 text-sm sm:text-base font-semibold">
                                {language === 'he' 
                                    ? (plan.count === 1 ? 'סופר לייק' : 'סופר לייקים')
                                    : (plan.count === 1 ? 'ሱፐር ላይክ' : 'ሱፐር ላይኮች')
                                }
                                </p>
                            </div>
                        </div>
                        <p className="text-xl sm:text-2xl font-bold text-gray-900">₪{plan.total_price.toFixed(2)}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </Section>
          </div>
        </div>
      </main>
      
      {/* FIX: Sticky Continue Button at the bottom of the viewport */}
      <footer className="sticky bottom-0 p-4 bg-white/90 backdrop-blur-sm border-t border-gray-200/80 z-20">
        <div className="max-w-md mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <Button
                onClick={handleContinue}
                className="w-full text-lg font-bold py-4 h-14 rounded-2xl bg-gradient-to-r from-[#7B3FA3] to-[#E7B6E1] text-white shadow-xl hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1"
                disabled={!selectedPlan && !selectedSuperLikes}
                size="lg"
              >
                {language === 'he' ? `המשך לתשלום - ₪${totalPrice}` : `ወደ ክፍያ ይቀጥሉ - ₪${totalPrice}`}
              </Button>
            </motion.div>
        </div>
      </footer>
    </div>
  );
}
