import { createClient } from '@base44/sdk';
// import { getAccessToken } from '@base44/sdk/utils/auth-utils';

// Create a client with authentication required
export const base44 = createClient({
  appId: "68a1111af0e7d019e8c4831f", 
  requiresAuth: true // Ensure authentication is required for all operations
});
